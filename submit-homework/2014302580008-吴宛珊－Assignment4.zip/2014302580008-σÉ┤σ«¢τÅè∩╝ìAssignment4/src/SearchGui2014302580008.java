import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class SearchGui2014302580008 extends JFrame{
	
	
    private JPanel inpanel;
    private JTextField infield;
    private JButton inbutton;
    private JPanel outpanel;
    private JScrollPane outscroll;
    private JTextArea outarea;

    
    
    public SearchGui2014302580008(){
        setSize(500, 500);
        setTitle("Professors of WPI");
        setLocation(100, 100);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        creatInput();
        creatOutput();
        AddListeners();

        setVisible(true);
    }
    private void creatInput(){
        inpanel = new JPanel();
        inpanel.setLayout(new FlowLayout());

        infield = new JTextField("", 25);
        infield.setMargin(new Insets(0, 0, 0, 0));
        inbutton = new JButton("Search");
        inbutton.setMargin(new Insets(0, 10, 0, 10));

        inpanel.add(infield);
        inpanel.add(inbutton);

        inpanel.setBorder(new EmptyBorder(5, 0, 5, 0));

        add(inpanel, BorderLayout.NORTH);
    }

    
    private void creatOutput(){
        outpanel = new JPanel();
        outpanel.setLayout(new BorderLayout());

        outarea = new JTextArea("");
        outarea.setLineWrap(true);
        outarea.setEditable(false);
        outscroll = new JScrollPane(outarea);

        outpanel.add(outscroll, BorderLayout.CENTER);
        outpanel.setBorder(new EmptyBorder(10, 500 / 7, 10 , 500 / 7));

        add(outpanel, BorderLayout.CENTER);
    }

    
    private void AddListeners(){
        inbutton.addActionListener(e -> {
            String search = infield.getText();
            if(!SearchMachine2014302580008.getInstance().connectedOrNot()){
                JOptionPane.showMessageDialog(this, "Failed!");
                return;
            }
            outarea.setText(SearchMachine2014302580008.getInstance().searchInfo(search));
            outarea.setCaretPosition(0);
        });
    }

    

}
