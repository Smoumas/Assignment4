
import java.util.Vector;

public class SearchMachine2014302580008 {
	private static SearchMachine2014302580008 singleInstance = new SearchMachine2014302580008();//单例模式
	
	private String user = "root";                 
    private String password= "123456";           
    private String database = "teacher"; 
    private boolean connect;                    
    private Vector<Professor2014302580008> professors; 
     
    public static SearchMachine2014302580008 getInstance() {
        return singleInstance;//单例模式
    }
    private double[] weight = {0.3,0.25, 0.25,0.05, 0.1};//各项数据的权值，用于词频计算
    
    private void getInfo() {
        MysqlConnector2014302580008.getInstance().ReadInfo(professors);
    }//获取信息
    public String searchInfo(String search) {
        try {
            Frequency(search);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return Result();
    }//信息查找
    private void Frequency(String string) throws Exception{
        string = string.replace(" ", "");
        for(Professor2014302580008 professor : professors) {
            proFrequency(string, professor);
        }
    }
    private double Division(int a, int b){
        if(b == 0){
            return 0;
        }
        else {
            return a * 1.0 / b;
        }
    }//除法计算
    private void proFrequency(String string, Professor2014302580008 professor) throws Exception{
        double current = 0.0;//目前频数
        int times = 0;//出现次数
        int sum = 0;//总数
        String[] name = professor.getName().split(" ");
        for(String n:name){
        	if(n.contains(string)){
            	times = 1;
            }
            sum +=1;
            
        }
        current += Division(times, sum) * weight[0];
        times = 0;
        sum = 0;//姓名
        
        String tel = professor.gettel().replace(" ", "");
        if(tel.contains(string)){
            times = 1;
        }
        sum += 1;
        current += Division(times, sum) * weight[1];//电话

        
        String email = professor.getEmail().replace(" ", "");
        if(email.contains(string)){
            times = 1;
        }
        sum += 1;
        current += Division(times, sum) * weight[2];//email


        
        String[] breif = professor.getName().split(" ");
        for(String b:breif){
        	if(b.contains(string)){
            	times = 1;
            }
            sum +=1;
            
        }
        current += Division(times, sum) * weight[3];
        times = 0;
        sum = 0;//介绍

        
        String[] field = professor.getName().split(" ");
        for(String f:field){
        	if(f.contains(string)){
            	times = 1;
            }
            sum +=1;
            
        }
        current += Division(times, sum) * weight[4];
        times = 0;
        sum = 0;//领域
        professor.setfrequency(current);
    }//计算各项词频
    
    private String Result() {
        professors.sort(((o1, o2) -> (o1.getfrequency() < o2.getfrequency()) ? 1 : -1));
        String result = new String("");
        for (Professor2014302580008 professor : professors){
            if(professor.getfrequency() <= 0){
                break;
            }
            else{
            	result += professorInfo(professor);
            }
        }
        return result;
        
    }//计算结果
    
    //database
    private boolean ConnectSQL() {
        return MysqlConnector2014302580008.getInstance().ConnectSQL(user, password, database);
    }//连接数据库
    public boolean connectedOrNot() {
        return connect ;
    }//是否连接

    private SearchMachine2014302580008() {
        if (!ConnectSQL()) {
            connect = false;
            return;
        }
        else if(ConnectSQL()){
        	connect = true;
        }
        professors = new Vector<>();
        getInfo();
        
    }//连接检验
    private String professorInfo(Professor2014302580008 professor){
        String result = new String("\n");
        result += "name: " + professor.getName() + "\n"
        		+"tel: " + professor.gettel() + "\n"
                +"email: " + professor.getEmail() + "\n"
                +"breif: " + professor.getbreif() + "\n"
                +"field: " + professor.getfield() + "\n";
                
        result += "\n\n";

        return result;
    }
    
    

}
