import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class MysqlConnector2014302580008 {
	private static MysqlConnector2014302580008 singleInstance = new MysqlConnector2014302580008();
	private Connection conn = null;
    private MysqlConnector2014302580008() {
    }
    public static MysqlConnector2014302580008 getInstance() {
        return singleInstance;
    }//单例模式
    public boolean ConnectSQL(String user, String password, String database){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
            conn = DriverManager.getConnection(url);
        }
        catch (Exception e){
            return false;
        }

        return true;
    }//是否连接成功
    public void ReadInfo(Vector<Professor2014302580008> professors){
        try {
            Statement statement = conn.createStatement();
            ResultSet set = statement.executeQuery("SELECT* FROM 2014302580008_professor_info;");
            Professor2014302580008 professor;
            while (set.next()) {
                professor = new Professor2014302580008();
                professor.setName(set.getString(1));
                professor.settel(set.getString(2));
                professor.setEmail(set.getString(3));
                professor.setfield(set.getString(4));
                professor.setbreif(set.getString(5));
                
                professors.add(professor);
            }

            System.out.println(professors.size());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }//信息读入


}
