import java.awt.*;

public class MainWindow2014302580008 {
	public static void main(String[] args){
        EventQueue.invokeLater(() -> {
            new SearchGui2014302580008();   //GUI初始化,用于创建窗口
        });
        
        
        
     
	}


}
