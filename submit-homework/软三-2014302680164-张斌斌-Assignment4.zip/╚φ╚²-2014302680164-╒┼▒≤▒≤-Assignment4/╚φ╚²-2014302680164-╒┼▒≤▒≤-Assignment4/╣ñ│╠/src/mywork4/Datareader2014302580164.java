package mywork4;

import java.sql.*;
import java.util.ArrayList;

public class Datareader2014302580164 {

	//private String url = "jdbc:mysql://localhost:3306/professor_info?user=root&password=root&useUnicode=true&characterEncoding=UTF8";
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	public ArrayList<ProfessorInfo2014302580164> read() throws Exception{
		Connection con = null;
		try{
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			con = DriverManager.getConnection(url);
		}catch(Exception e){
			e.printStackTrace();
		}

		
		
		ArrayList infoList = new ArrayList();
		Statement stmt = con.createStatement();
		String sql = "select * from professor_info";
		ResultSet rs = stmt.executeQuery(sql);
		
		String r_name;
		String r_email;
		String r_phone;
		String r_educationBackground;
		String r_researchInterests;
		
		while (rs.next()){
			r_name = rs.getString(1);
			r_educationBackground = rs.getString(2);
			r_researchInterests = rs.getString(3);
			r_email = rs.getString(4);
			r_phone = rs.getString(5);
			
			ProfessorInfo2014302580164 pI = new ProfessorInfo2014302580164(r_name,r_phone,r_email,r_educationBackground,r_researchInterests);
			infoList.add(pI);
		}
		return infoList;
		
	}
}
