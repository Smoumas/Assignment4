package mywork4;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MainWindow2014302580164 {
	private JFrame pIframe;
	private JTextField textField;
	private JTextArea textArea;
	private Button button;
	public MainWindow2014302580164(){
		
		
		textField = new JTextField(10);
		textArea = new JTextArea(20,40);
		textArea.setEditable(false);
		button = new Button("Search");
		ButtonHandler handler = new ButtonHandler();
		button.addActionListener(handler);

		
	}
	
	private class ButtonHandler implements ActionListener{
		public void actionPerformed(ActionEvent event){
			String s = textField.getText();
			String result = "null";
			ArrayList<ProfessorInfo2014302580164> info = new ArrayList<ProfessorInfo2014302580164>();
			Datareader2014302580164 reader = new Datareader2014302580164();
			try {
				info = reader.read();
			} catch (Exception e) {
				e.printStackTrace();
			}
			for(ProfessorInfo2014302580164 i:info){
				if(s.equals(i.getName()) ){
					result = i.getName()+"\n"+i.getEducationBackground()+"\n"+i.getResearchInterests()+"\n"+i.getEmail()+"\n"+i.getPhone();
					
				}
			}
			textArea.setText(result);
			System.out.println("end");
		}
		
	}
	public void show(){
		pIframe = new JFrame("Search");
		pIframe.setSize(576, 286);
		
		pIframe.setLayout(new FlowLayout());
		pIframe.add(textField);
		pIframe.add(button);
		pIframe.add(textArea);
		pIframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pIframe.setVisible(true);
	}
	
	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		MainWindow2014302580164 mainWindow = new MainWindow2014302580164();
		mainWindow.show();
	}

}
