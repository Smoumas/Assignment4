package mywork4;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class ProfessorInfo2014302580164 {

	private String name;
	//private Map<String,String> contactInfo;//key:email value:phone
	private String phone;
	private String email;
	private String educationBackground;
	private String researchInterests;
	
	
	public ProfessorInfo2014302580164(String name,String phone,String email,String eduBackground,String researchInterests){
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.educationBackground = eduBackground;
		this.researchInterests = researchInterests;
	}
	
	public String getEmail(){
		return email;
	}
	
	public String getPhone(){
		return phone;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getEducationBackground(){
		return educationBackground;
	}
	
	public void setEducationBackground(String edu){
		this.educationBackground = edu;
	}
	
	public String getResearchInterests() {
		return researchInterests;
	}

	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}

}
