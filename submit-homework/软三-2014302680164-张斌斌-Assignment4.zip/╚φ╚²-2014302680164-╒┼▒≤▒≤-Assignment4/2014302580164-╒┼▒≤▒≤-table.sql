CREATE TABLE `2014302580164_professor_info` (
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `researchInterests` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
