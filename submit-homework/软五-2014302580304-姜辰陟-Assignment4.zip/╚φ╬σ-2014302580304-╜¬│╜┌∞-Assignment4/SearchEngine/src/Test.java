import java.io.File;
import java.io.IOException;  

import org.apache.lucene.analysis.Analyzer;  
import org.apache.lucene.analysis.standard.StandardAnalyzer;  
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.ParseException;  
import org.apache.lucene.queryParser.QueryParser;  
import org.apache.lucene.search.IndexSearcher;  
import org.apache.lucene.search.Query;  
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
  
public class Test {  
    public static void main(String[] args) throws IOException, ParseException {  
    	String index = "C:/Users/Frank/workspace/SearchEngine/teacher.txt";         //����������·��
        IndexReader reader = IndexReader.open(FSDirectory.open(new File(index)));
        IndexSearcher searcher = new IndexSearcher(reader);  
        
    	ScoreDoc[] hits = null;  
        String queryString = "��Դ����";   //�����Ĺؼ���
        Query query = null;  
        
  
        Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_36);  
        try {  
            QueryParser qp = new QueryParser(Version.LUCENE_36,"body", analyzer);  
            query = qp.parse(queryString);  
        } catch (ParseException e) {  
        }  
        if (searcher != null) {  
            TopDocs results = searcher.search(query,10);    //�������Ϊ10����¼
            hits = results.scoreDocs;
            if (hits.length > 0) {  
                System.out.println("�ҵ�:" + hits.length + " �����!");  
            }  
            searcher.close();
        } 
       
    }  
}  