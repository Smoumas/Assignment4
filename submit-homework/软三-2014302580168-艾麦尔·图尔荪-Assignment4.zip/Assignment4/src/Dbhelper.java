
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Dbhelper {
	
	private	List<Map<String,String>> selectList=new ArrayList<Map<String,String>>();
	private	String keyString=null;
	public Dbhelper(String KeyString){
		this.keyString =KeyString;
	}
	/**
	 * @return
	 * @throws Exception 
	 */
	public static  Connection getConnection() throws Exception{
		String url="jdbc:mysql://localhost/my_schema?user=root&password=123456";
		Connection conn;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
				conn = (Connection)DriverManager.getConnection(url);
				//System.out.println("get!!");
			return conn;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//System.err.println("connection fail!");
				return null;
			}
		
		}
	//
	public ResultSet selectFromDtabase(String Sql_select_formal){
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet resultset=null;
		try {
			conn=getConnection();
			pstmt=(PreparedStatement)conn.prepareStatement(Sql_select_formal);
			 resultset=pstmt.executeQuery();
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		if(resultset== null)
	 		return null;
		else return resultset;
	}
	public List<Map<String,String>> getSelectInformations(){
		AnalyseKeyString analysekeystring=new AnalyseKeyString(keyString);
		ArrayList<String> eachString=analysekeystring.analyse();
		String sql_select_formal=null;
		for(String element:eachString){
			 sql_select_formal="select distinct * from my_schema.2014302580168_professor_info where name collate utf8_general_ci like \"%"+element
			+"%\" or educationBackground collate utf8_general_ci like \"%"+element+
			"%\" or researchInterests collate utf8_general_ci like \"%"+element+
			"%\" or email collate utf8_general_ci like \"%"+element+
			"%\" or phone collate utf8_general_ci like \"%"+element+"%\";";
		ResultSet resultset=selectFromDtabase( sql_select_formal);
		
		try {
			while(resultset.next()){
			
				Map<String,String> afterselect=new HashMap<String,String>();
				afterselect.put("name", resultset.getString(1));
				afterselect.put("educationBackground",resultset.getString(2));
				afterselect.put("researchInterests",resultset.getString(3));
				afterselect.put("email ",resultset.getString(4));
				afterselect.put("phone ",resultset.getString(5));
				selectList.add(afterselect);
								}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
									}
						}	
		return selectList;
	}
}

	
	
