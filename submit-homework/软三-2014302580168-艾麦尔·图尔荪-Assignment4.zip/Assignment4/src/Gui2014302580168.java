
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.TextArea;
public class Gui2014302580168 extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7074854850356407349L;
	private JTextField Searchtext;
	Dbhelper dbhelper=null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui2014302580168 frame = new Gui2014302580168();
					frame.setSize(440, 300);
					//frame.setLocation(500, 500);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui2014302580168() {
		setTitle("Professor Searcher");
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.NORTH);
		Searchtext = new JTextField();
	//	Searchtext.setText("Type some words to search");
		Searchtext.setColumns(10);
		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		TextArea textArea = new TextArea();
		scrollPane.setViewportView(textArea);
		JButton searchBtn = new JButton("Search");
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String keyString;
		      keyString=Searchtext.getText();
		     
		    if(keyString.trim()==""){
		    	 // showResult.setText("Please input the keywords!");
		    	  
		     }
		    else {
		    	Dbhelper dbhelper=new Dbhelper(keyString);
		    	List<Map<String,String>> selectList=dbhelper.getSelectInformations();
		  for( int i=0;i<selectList .size();i++){
			  String input="";
				input="Professor Name: \n"+selectList.get(i).get("name")+"\nEducationBackground: \n"+selectList.get(i).get("educationBackground")
						+ "\nResearchInterest: \n"+selectList.get(i).get("researchInterest")+"\nemail: "+selectList.get(i).get("email")
						+"\nphone: "+selectList.get(i).get("phone")+"\n****************************************************************\n";
				textArea.append(input);
			 
		  }	 	
		    }
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(2)
					.addComponent(Searchtext, GroupLayout.PREFERRED_SIZE, 269, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(searchBtn, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(39, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(searchBtn)
						.addComponent(Searchtext, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
		);
		panel.setLayout(gl_panel);
		
		
		
		
	}
}
