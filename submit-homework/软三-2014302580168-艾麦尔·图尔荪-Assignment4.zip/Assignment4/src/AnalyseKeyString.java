import java.util.ArrayList;

public class AnalyseKeyString {
private String keystring=null;
	public AnalyseKeyString(String keystring) {
		// TODO Auto-generated constructor stub
		this.keystring=keystring;
	}
public ArrayList<String> analyse(){
	
	ArrayList<String> result=new ArrayList<String>();
	String[] afterSplit=keystring.split("&");
	for(String element:afterSplit){
		result.add(element.trim());
		
	}
	return result;
}
	
	
}
