import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.PreparedStatement;

public class Read2014302580382 {

	ArrayList<String> Key = null;
	List<Map<String, String>> listItems = null;
	String keywords = null;
	String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";

	// Execute the query sentence
	public ResultSet selectFormDatabase(String sql_language) {

		Connection con = null;
		PreparedStatement pre = null;
		ResultSet resultSet = null;
		try {
			con = getConnection(url);
			pre = (PreparedStatement) con.prepareStatement(sql_language);
			resultSet = pre.executeQuery();
			System.out.println("1");
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("return query result fail");
			return null;
		}
		System.out.println("return result");
		if (resultSet == null) {
			System.err.println("result fail to get");
		}
		return resultSet;
	}

	// this method is to get the connection
	private Connection getConnection(String url) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			return connection;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error!Can not connect to Sql!");
			return null;
		}
	}

	// get selected statics from database
	public List<Map<String, String>> GetSelectedInformation()
			throws SQLException {
		String sql_language = null;
		ResultSet resultSet = selectFormDatabase(sql_language);
		for (String ele : Key) {
			sql_language = "select distinct * from my_schema.2014302580222_professor_info where name collate utf8_general_ci like \"%"
					+ ele
					+ "%\" or researchInterests collate utf8_general_ci like \"%"
					+ ele
					+ "%\" or educationBackground collate utf8_general_ci like \"%"
					+ ele
					+ "%\" or phone collate utf8_general_ci like \"%"
					+ ele
					+ "%\" or email collate utf8_general_ci like \"%"
					+ ele + "%\";";

			System.out.println("The sql_Query sentence is:" + sql_language
					+ "\n");

			boolean whilecondition = (resultSet.next());
			while (whilecondition) {
				Map<String, String> professor = new HashMap<String, String>();
				try {

					if (true) {
						// resultSet.absolute(--rowCount);
						professor.put("name", resultSet.getString(1));
						System.out.println(resultSet.getString(1));
						professor.put("researchInterest",
								resultSet.getString(2));
						System.out.println(resultSet.getString(2));
						professor.put("educationBackground",
								resultSet.getString(3));
						System.out.println(resultSet.getString(3));
						professor.put("phone", resultSet.getString(4));
						System.out.println(resultSet.getString(4));
						professor.put("email", resultSet.getString(5));
						System.out.println(resultSet.getString(5));
					}
					boolean ifcondition = (listItems.contains(professor) == false);
					if (ifcondition) {
						listItems.add(professor);
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println("get result fail");
				}
			}
		}
		System.out
				.println("Database finds " + listItems.size() + " records.\n");
		return listItems;
	}

}