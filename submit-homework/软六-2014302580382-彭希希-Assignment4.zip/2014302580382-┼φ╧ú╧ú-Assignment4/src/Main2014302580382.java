import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main2014302580382 {

	private CalTF2014302580382 cal = null;
	private int[] allNum = null;
	private JFrame Frame;
	private JTextField TextField;
	private JTextArea TextArea;
	private JScrollPane ScrollPane;
	private String Keywords = null;

	public static void main(String[] args)

	// Launch the application.
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main2014302580382 window = new Main2014302580382();
					window.Frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Main2014302580382()

	// Create the application.

	{
		initialize();
	}

	private void initialize()

	// Initialize the contents of the frame.

	{
		Frame = new JFrame();
		Frame.setBounds(200, 200, 595, 842);
		Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Frame.setVisible(true);
		Frame.getContentPane().setLayout(null);

		TextField = new JTextField();
		TextField.setBounds(32, 34, 360, 25);
		Frame.getContentPane().add(TextField);
		TextField.setColumns(10);

		JLabel lblPleaseInputThe = new JLabel(
				"Please enter the keywords:(Attend the Size of Write!��");
		lblPleaseInputThe.setBounds(32, 9, 343, 25);
		Frame.getContentPane().add(lblPleaseInputThe);

		TextArea = new JTextArea();
		TextArea.setEditable(false);
		TextArea.setWrapStyleWord(true);
		TextArea.setLineWrap(true);
		TextArea.setBounds(32, 74, 479, 326);
		Frame.getContentPane().add(TextArea);

		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String keywords = TextField.getText();
				boolean if1 = (keywords.trim() == "");
				if (if1) {
					System.err.println("Please input the keywords!");
				} else {
					Read2014302580382 readFromDatabase = new Read2014302580382();
					try {
						List<Map<String, String>> list = readFromDatabase
								.GetSelectedInformation();
						cal = new CalTF2014302580382(readFromDatabase.Key, list);
						cal.CalTf(cal.Key, cal.listItems);
						allNum = new int[cal.listScore.size()];
						for (int i = 0; i < cal.listScore.size(); i++) {
							allNum[i] = i;
						}
						showResult(cal);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			}
		});

		btnSearch.setBounds(408, 33, 100, 23);
		Frame.getContentPane().add(btnSearch);

		ScrollPane = new JScrollPane(TextArea);
		@SuppressWarnings("unused")
		JScrollPane scrollBar = new JScrollPane(TextArea);
		ScrollPane.setBounds(32, 74, 500, 700);
		Frame.getContentPane().add(ScrollPane);

	}

	public void setkeyword2014302580382(String key) {
		Keywords = key;
	}

	public ArrayList<String> Analyse() {
		ArrayList<String> result = new ArrayList<String>();
		String[] afterSplit = Keywords.split("&");
		for (String ele : afterSplit) {
			result.add(ele.trim());
		}
		return result;
	}

	// Show Result

	public void showResult(CalTF2014302580382 cal) {
		TextArea.setText("");
		String input = "";

		boolean signal = true;
		while (signal) {
			int num = Max(cal);
			boolean ifcondition = (num == -1);
			if (ifcondition) {
				signal = false;
				continue;
			} else {

				input = "Professor Name: \n"
						+ cal.listItems.get(num).get("name")
						+ "\nemail: "
						+ cal.listItems.get(num).get("email")
						+ "\nEducationBackground: \n"
						+ cal.listItems.get(num).get("educationBackground")
						+ "\nResearchInterest: \n"
						+ cal.listItems.get(num).get("researchInterest")
						+ "\nphone: "
						+ cal.listItems.get(num).get("phone")
						+ "\n--------------------------------------------------------------------------------------\n";
				TextArea.append(input);
			}
		}

		boolean if2 = (TextArea.getText() == "");
		if (if2) {
			TextArea.setText("No result has been found!");
		}

	}

	public int Max(CalTF2014302580382 cal) {
		boolean ifcondition = (allNum.length != 0);
		if (ifcondition) {
			int maxNum = -1;
			int size = allNum.length;
			@SuppressWarnings("unused")
			double max = 0;
			for (int i = 0; i < size; i++) {
				boolean if1 = (allNum[i] != -1);
				if (if1) {
					double num = cal.listScore.get("" + allNum[i]);
					boolean if2 = (allNum[i] != -1);
					if (if2) {
						maxNum = allNum[i];
						allNum[i] = -1;
						max = num;
						break;
					}
				}
			}
			return maxNum;
		}
		return -1;
	}

}