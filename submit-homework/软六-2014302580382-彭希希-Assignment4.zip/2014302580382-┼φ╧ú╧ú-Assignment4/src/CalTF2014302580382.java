import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class CalTF2014302580382 {

	private String[] uselessWords = { "the", "with" };
	List<Map<String, String>> listItems = new ArrayList<Map<String, String>>();
	Map<String, Double> listScore = new HashMap<String, Double>();
	ArrayList<String> Key = new ArrayList<String>();

	public CalTF2014302580382(ArrayList<String> key1,
			List<Map<String, String>> listItems) {
		this.listItems = listItems;
		this.Key = key1;
		System.out.println(key1);

	}

	public void CalTf(ArrayList<String> eachkey,
			List<Map<String, String>> listItems) {
		boolean ifcondition = (eachkey != null);
		if (ifcondition) {

			for (String ele : eachkey) {
				int i = 0;
				Map<String, String> item = new HashMap<String, String>();
				new HashMap<String, String>();

				boolean whilecondition = ((i + 1) <= listItems.size());
				while (whilecondition) {
					System.out.println("start calculate the value of tf");
					item = listItems.get(i);
					double[] tfAndNum = new double[2];
					tfAndNum[0] = 0;
					tfAndNum[1] = 0;
					SpliteStringArrayToCal(item.get("name"), ele, tfAndNum);
					SpliteStringArrayToCal(item.get("researchInterest"), ele,
							tfAndNum);
					SpliteStringArrayToCal(item.get("educationBackground"),
							ele, tfAndNum);
					SpliteStringArrayToCal(item.get("phone"), ele, tfAndNum);
					SpliteStringArrayToCal(item.get("email"), ele, tfAndNum);

					listScore.put(String.valueOf(i),
							(tfAndNum[0] / tfAndNum[1]));
					i++;
				}
			}
		}
		System.out.println("Calculate TF is over!");
	}

	public void SpliteStringArrayToCal(String in, String key, double[] tfAndNum) {
		String[] afterSplite = in.split("\\s");
		Pattern pattern = Pattern.compile("\\w*" + key.toLowerCase() + "\\w*");
		Matcher matcher = pattern.matcher("");
		for (String ele : afterSplite) {
			boolean useless = false;
			for (String eString : uselessWords) {
				boolean if1 = (ele.equals(eString));
				if (if1) {
					useless = true;
				}
			}
			boolean if2 = (!useless);
			if (if2) {
				tfAndNum[1] += 1;
			}
			matcher = pattern.matcher(ele.toLowerCase());
			boolean if3 = (matcher.find());
			if (if3) {
				tfAndNum[0] += 1;
			}
		}
	}
}
