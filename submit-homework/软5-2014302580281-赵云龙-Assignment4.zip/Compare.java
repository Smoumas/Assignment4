package Zyl2014302580281;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.*;
public class Compare {
	public class info implements Comparable<info>{
		private String things;
		private int value;
		private info(String mthings)
		{
			things=mthings;
			value=0;
		}
		public int getValue()
		{
			return value;
		}
		public void setValue(int i)
		{
			value=i;
		}
		public String getThings()
		{
			return things;
		}
		@Override
		public int compareTo(info o) {
			// TODO Auto-generated method stub
			return Double.compare(o.value, this.value);
		}
	}
	private static info[] data=new info[217];
	public Compare()
	{
		try {
			Search mSearch=new Search();
			//System.out.println(mSearch.getlists().size());
			for(int i=0;i<mSearch.getlists().size();i++){
				data[i]=new info(mSearch.getlists().get(i));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public info[] getData()
	{
		return data;
	}
	public void find(String input)
	{
		for(int i=0;i<217;i++){			
			match(input,i);
		System.out.println(data[i].getValue()+"is the value of"+i);
		
		}
		Arrays.sort(data);	
	}
	private static void match(String input,int i)
	{
		
		Pattern pattern = Pattern.compile(input);
	    Matcher matcher = pattern.matcher(data[i].getThings());
	    while(matcher.find()){
	    	data[i].setValue(data[i].getValue()+1);
	    }
	    return; 
	}
}
