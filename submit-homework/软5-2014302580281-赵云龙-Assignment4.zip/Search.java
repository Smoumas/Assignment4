package Zyl2014302580281;
import java.sql.*;
import java.util.*;
public class Search {
	private List<String>lists=new ArrayList<>();
	public Search() throws SQLException
	{
		//connect to databasses
		Connection conn = null;
		String sql;
		String url = "jdbc:mysql://localhost:3306/test?user=root&password=123456,&useUnicode=true&characterEncoding=UTF8";	 
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url);
			Statement stmt = conn.createStatement();
			System.out.println("连接数据表成功");
			//get data
			sql="select * from 2014302580281_professor_info;";
			ResultSet results=stmt.executeQuery(sql);
			while(results.next()){
				lists.add(results.getString("name") + "\n" + results.getString("email") +results.getString("phone_number") + results.getString("major") + "\n" + results.getString("intorduction"));
			}
			//System.out.println(lists);
		} catch (SQLException e) {
			System.out.println("MySQL操作错误");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}
	public List<String> getlists()
	{
		return lists;
	}
}

