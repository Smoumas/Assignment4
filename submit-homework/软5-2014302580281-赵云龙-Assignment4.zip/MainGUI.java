package Zyl2014302580281;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import Zyl2014302580281.Compare.info;
public class MainGUI {
public static void main(String[]args) throws SQLException{
	Compare mcompare=new Compare();
	JFrame window=new JFrame("search engine");
	window.setSize(500, 500);	
	window.setVisible(true);
	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	window.setLayout(null);
	//window.getContentPane().setBackground(Color.blue);
	//search
	JTextArea search=new JTextArea();
	JScrollPane sps=new JScrollPane(search);
	window.add(sps);
	sps.setBounds(20, 20, 300, 50);
	sps.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS); 
	//search button
	JButton searchButton=new JButton();
	window.add(searchButton);
	searchButton.setText("SEARCH");
	searchButton.setBounds(350, 20, 100, 50);
	//result
	JTextArea result=new JTextArea();
	result.setLineWrap(true);//激活自动换行功能 
	result.setWrapStyleWord(true);//激活不断字 
	JScrollPane spr=new JScrollPane(result);
	window.add(spr);
	spr.setBounds(20, 100, 300, 300);
	spr.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	//button's action
	searchButton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent event) {
			//System.out.println("SEARCHBUTTON");
            String text=search.getText();
            if(text.equals("")){
            	result.setText("no enterence");
            }
            else{
            	result.setText("");
            	mcompare.find(search.getText());
            	result.append("找到以下结果\n");
            	for(info in:mcompare.getData()){
        			if(in.getValue()>0){
        				//System.out.print(in.getValue());
        				result.append("出现"+in.getValue()+"次"+in.getThings()+"\n\n\n");
        				in.setValue(0);
        			}
            	}
            }
        }
	});
}
}
