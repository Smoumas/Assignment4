import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 * Created by inksmallfrog on 11/9/15.
 */

//Mysql链接
public class MysqlConnector2014302580136 {
    private static MysqlConnector2014302580136 ourInstance = new MysqlConnector2014302580136();

    public static MysqlConnector2014302580136 getInstance() {
        return ourInstance;
    }

    private String driver = "com.mysql.jdbc.Driver";                //驱动名
    private String baseUrl = "jdbc:mysql://localhost:3306/";        //mysql地址
    private String table = "2014302580136_professor_info";          //表名
    private Connection conn = null;

    private MysqlConnector2014302580136() {
    }

    //测试链接
    public boolean ConnectMysql(String user, String password, String database){
        try{
            Class.forName(driver);
            String url = baseUrl + database + "?user=" + user + "&password=" + password;
            conn = DriverManager.getConnection(url);
        }
        catch (Exception e){
            return false;
        }

        return true;
    }

    //将数据库信息读入程序
    public void ReadToVector(Vector<Professor2014302580136> professors){
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM " + table + ";");
            Professor2014302580136 professor;
            while (rs.next()) {
                professor = new Professor2014302580136();
                professor.setName(rs.getString(1));
                professor.setMaster(rs.getString(2));
                professor.setLevel(rs.getString(3));
                professor.setBrief(rs.getString(4));
                professor.setField(rs.getString(5));
                professor.setPhone(rs.getString(6));
                professor.setEmail(rs.getString(7));
                professors.add(professor);
            }

            System.out.println(professors.size());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
