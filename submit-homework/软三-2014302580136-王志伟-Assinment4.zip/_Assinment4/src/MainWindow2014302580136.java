import java.awt.*;

/**
 * Created by inksmallfrog on 11/9/15.
 */
public class MainWindow2014302580136 {
    public static void main(String[] args){
        EventQueue.invokeLater(() -> {
            new SearchGui2014302580136();   //创建窗口
        });
    }
}
