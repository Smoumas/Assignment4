import org.lionsoul.jcseg.core.*;

import java.io.StringReader;
import java.util.Vector;

/**
 * Created by inksmallfrog on 11/9/15.
 */
//搜索引擎
public class SearchMachine2014302580136 {
    private static SearchMachine2014302580136 ourInstance = new SearchMachine2014302580136();

    public static SearchMachine2014302580136 getInstance() {
        return ourInstance;
    }

    private boolean mysql_connected;                    //检测mysql链接
    private Vector<Professor2014302580136> professors;  //存储教授信息

    ISegment seg;                                       //用于分词处理

    private String mysql_user = "root";                 //数据库用户名
    private String mysql_password = "123456";           //数据库密码
    private String mysql_database = "my_schema";        //数据库名

    private float[] weight = {0.3f, 0.05f, 0.05f, 0.1f, 0.25f, 0.25f};

    //从数据库取回数据并初始化分词工具
    private SearchMachine2014302580136() {
        if (!ConnectToMysql()) {
            mysql_connected = false;
            return;
        }
        mysql_connected = true;

        professors = new Vector<>();
        LoadInformation();
        CreateJcsegTask();
    }

    //尝试链接数据库
    private boolean ConnectToMysql() {
        return MysqlConnector2014302580136.getInstance().ConnectMysql(mysql_user, mysql_password, mysql_database);
    }

    //检查链接是否成功
    public boolean isMysql_connected() {
        return mysql_connected;
    }

    //读取数据库信息
    private void LoadInformation() {
        MysqlConnector2014302580136.getInstance().ReadToVector(professors);
    }

    //初始化中文分词包
    private void CreateJcsegTask(){
        JcsegTaskConfig config = new JcsegTaskConfig();
        ADictionary dic = DictionaryFactory.createDefaultDictionary(config);
        try {
            seg = SegmentFactory.createJcseg(JcsegTaskConfig.COMPLEX_MODE, new Object[]{config, dic});
        }
        catch (org.lionsoul.jcseg.core.JcsegException e){
            e.printStackTrace();
        }
    }

    //处理搜索内容
    public String SearchFor(String search) {
        try {
            CalculateTF(search);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return GenerateResult();
    }

    //计算所有信息的tf值
    private void CalculateTF(String string) throws Exception{
        string = string.replace(" ", "");

        for(Professor2014302580136 professor : professors) {
            CalculateProcessorTF(string, professor);
        }
    }

    //计算每个教授的tf值
    private void CalculateProcessorTF(String string, Professor2014302580136 processor) throws Exception{
        IWord word = null;
        double currentTf = 0.0;
        int termShowTimes = 0;
        int allTermsNumber = 0;

        seg.reset(new StringReader(processor.getName()));
        while((word = seg.next()) != null){
            if(word.getValue().contains(string)){
                termShowTimes += 1;
            }
            allTermsNumber += 1;
        }
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[0];
        termShowTimes = 0;
        allTermsNumber = 0;

        seg.reset(new StringReader(processor.getMaster()));
        while((word = seg.next()) != null){
            if(word.getValue().contains(string)){
                termShowTimes += 1;
            }
            allTermsNumber += 1;
        }
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[1];
        termShowTimes = 0;
        allTermsNumber = 0;

        seg.reset(new StringReader(processor.getBrief()));
        while((word = seg.next()) != null){
            if(word.getValue().contains(string)){
                termShowTimes += 1;
            }
            allTermsNumber += 1;
        }
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[2];
        termShowTimes = 0;
        allTermsNumber = 0;

        seg.reset(new StringReader(processor.getField()));
        while((word = seg.next()) != null){
            if(word.getValue().contains(string)){
                termShowTimes += 1;
            }
            allTermsNumber += 1;
        }
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[3];
        termShowTimes = 0;
        allTermsNumber = 0;

        String phone = processor.getPhone().replace(" ", "");
        if(phone.contains(string)){
            termShowTimes = 1;
        }
        allTermsNumber += 1;
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[4];

        String email = processor.getEmail().replace(" ", "");
        if(email.contains(string)){
            termShowTimes = 1;
        }
        allTermsNumber += 1;
        currentTf += Divide(termShowTimes, allTermsNumber) * weight[5];

        processor.setTf_idf(currentTf);
    }

    //防止除0错误
    private double Divide(int a, int b){
        if(b == 0){
            return 0;
        }
        else{
            return a * 1.0 / b;
        }
    }

    //根据tf排序，产生结果
    private String GenerateResult() {
        professors.sort(((o1, o2) -> (o1.getTf_idf() < o2.getTf_idf()) ? 1 : -1));

        String result = new String("");
        for (Professor2014302580136 professor : professors){
            if(professor.getTf_idf() <= 0){
                break;
            }
            result += EachProfessorInfo(professor);
        }
        return result;
    }

    //每个教授信息的显示规则
    private String EachProfessorInfo(Professor2014302580136 professor){
        String result = new String("------------------------------------------------\n");
        result += "姓名: " + professor.getName() + "\n"
                +"专业: " + professor.getMaster() + "\n"
                +"职称: " + professor.getLevel() + "\n"
                +"简介: " + professor.getBrief() + "\n"
                +"研究领域: " + professor.getField() + "\n"
                +"电话: " + professor.getPhone() + "\n"
                +"邮箱: " + professor.getEmail() + "\n";
        result += "------------------------------------------------\n\n";

        return result;
    }
}