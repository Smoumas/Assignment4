/**
 * Created by inksmallfrog on 11/9/15.
 */
//教授信息
public class Professor2014302580136 {
    private String name;        //姓名
    private String master;      //专业
    private String level;       //职称
    private String brief;       //简介
    private String field;       //领域
    private String phone;       //电话
    private String email;       //邮箱

    private double tf_idf;      //tf值

    public void setName(String name) {
        this.name = name;
    }

    public void setMaster(String master) {
        this.master = master;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public void setField(String field) {
        this.field = field;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTf_idf(double tf_idf) {
        this.tf_idf = tf_idf;
    }

    public String getName() {
        return name;
    }

    public String getMaster() {
        return master;
    }

    public String getLevel() {
        return level;
    }

    public String getBrief() {
        return brief;
    }

    public String getField() {
        return field;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public double getTf_idf() {
        return tf_idf;
    }
}
