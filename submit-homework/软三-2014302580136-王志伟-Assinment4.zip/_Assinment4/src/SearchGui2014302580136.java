import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.security.MessageDigest;

/**
 * Created by inksmallfrog on 11/9/15.
 */
public class SearchGui2014302580136 extends JFrame{
    //输入组件
    private JPanel inputPanel;
    private JTextField inputField;
    private JButton inputButton;

    //输出组件
    private JPanel resultPanel;
    private JScrollPane resultScroll;
    private JTextArea resultArea;

    //窗口属性
    private final int WINDOW_WIDTH = 500;
    private final int WINDOW_HEIGHT = 400;
    private final String WINDOW_NAME = "浙江大学教授信息检索";

    public SearchGui2014302580136(){
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setTitle(WINDOW_NAME);
        setLocation(100, 100);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        CreateInputPanel();
        CreateResultPanel();

        AddListeners();

        setVisible(true);
    }

    //创建输入组件
    private void CreateInputPanel(){
        inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        inputField = new JTextField("", 24);
        inputField.setMargin(new Insets(1, 0, 1, 0));
        inputButton = new JButton("搜索");
        inputButton.setMargin(new Insets(0, 20, 0, 20));

        inputPanel.add(inputField);
        inputPanel.add(inputButton);

        inputPanel.setBorder(new EmptyBorder(10, 0, 5, 0));

        add(inputPanel, BorderLayout.NORTH);
    }

    //创建输出组件
    private void CreateResultPanel(){
        resultPanel = new JPanel();
        resultPanel.setLayout(new BorderLayout());

        resultArea = new JTextArea("");
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);
        resultScroll = new JScrollPane(resultArea);

        resultPanel.add(resultScroll, BorderLayout.CENTER);
        resultPanel.setBorder(new EmptyBorder(5, WINDOW_WIDTH / 7, 10 , WINDOW_WIDTH / 7));

        add(resultPanel, BorderLayout.CENTER);
    }

    //添加监听事件
    private void AddListeners(){
        inputButton.addActionListener(e -> {
            String search = inputField.getText();
            if(!SearchMachine2014302580136.getInstance().isMysql_connected()){
                JOptionPane.showMessageDialog(this, "数据库连接失败！");
                return;
            }
            resultArea.setText(SearchMachine2014302580136.getInstance().SearchFor(search));
            resultArea.setCaretPosition(0);
        });
    }
}
