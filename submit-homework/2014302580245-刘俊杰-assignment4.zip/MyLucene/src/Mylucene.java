import java.util.*;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Mylucene extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static Vector<message> all_message=new Vector<message>();
	static String message_show="";
	public static void main(String[] args) throws SQLException, ClassNotFoundException{
		String driver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?seUnicode=true&characterEncoding=UTF-8";
		String user="root";
		String password="123456";
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url, user, password);
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM my_schema.my_table";
		ResultSet selectRes=st.executeQuery(selectSql);
		while(selectRes.next()){
			message m=new message();
			m.name=selectRes.getString("name");
			m.research=selectRes.getString("research");
			m.award=selectRes.getString("award");
			m.index=0;
			all_message.add(m);
		}
		//System.out.println(Find("�о���"));
		Mylucene m=new Mylucene();
		m.setVisible(true);
	}
	public static String Find(String str){
		String result="";
		for(message m:all_message){
			m.index=getCount(m,str);
		}
		for(int i=100;i>0;i--){
			for(message m:all_message){
				if(m.index==i){
					result+="����:"+m.name+"\n"+"�о�����:"+m.research+"\n"+"�ɾ�:"+m.award+"\n\n";
				}
			}
		}
		return result;
		
	}
	public static int getCount(message m,String str){
		int count=0;
		String all_str=m.name+m.research+m.award;
		Pattern pattern=Pattern.compile(str);
		Matcher matcher=pattern.matcher(all_str);
		while(matcher.find()){
			count++;
		}
		return count;
		
	}
	public Mylucene(){
		JPanel panel=new JPanel();
		JButton research=new JButton("����");
		JTextField input=new JTextField("",10);
		panel.setLayout(new GridLayout(1,2));
		panel.add(input);
		panel.add(research);
		add(panel,BorderLayout.NORTH);
		JTextArea out=new JTextArea(10,40);
		JScrollPane sc=new JScrollPane(out);
		add(sc,BorderLayout.CENTER);
		research.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				out.setText(Find(input.getText()));
			}
		});
		pack();
	}
}

class message{
	public String name;
	public String research;
	public String award;
	public int index;
	public message(){
	}
}
