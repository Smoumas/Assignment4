import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Professor {
	private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	private static final String DATABASE_URL = " jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private static final String DATABASE_USER = "xiaohao";
	private static final String DATABASE_PASSWORD = "123456";
	private static Connection conn = null;
	private static Statement stmt = null;
	   try{
	      Class.forName("com.mysql.jdbc.Driver");

	      System.out.println("Connecting to database...");
	      conn = DriverManager.getConnection(DATABASE_URL,DATABASE_USER,DATABASE_PASSWORD);

	      
	      System.out.println("Creating statement...");
	      stmt = conn.createStatement();
	      String sql;
	      sql = "name,educationBackground,researchInterests,email,phone";
	      ResultSet rs = stmt.executeQuery(sql);

	      
	      while(rs.next()){
	         
	         String name  = rs.getString("name");
	         String educationBackground = rs.getString("educationBackground");
	         String researchInterests = rs.getString("researchInterests");
	         String email = rs.getString("email");
	         String phone = rs.getString("phone");

	         
	         System.out.print("ID: " + name);
	         System.out.print(", Age: " + educationBackground);
	         System.out.print(", First: " + researchInterests);
	         System.out.println(", Last: " + email);
	         System.out.println(", Last: " + phone);
	      }
	      rs.close();
	      stmt.close();
	      conn.close();
	   }catch(SQLException se){
	      se.printStackTrace();
	   }catch(Exception e){
	      e.printStackTrace();
	   }finally{
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }catch(SQLException se2){
	      }try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }
	   }System.out.println("null");
    
}
}
