import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class SearshEngine {
	private static List<String> fileList = new ArrayList<String>();
	private static HashMap<String, HashMap<String, Float>> allTheTf = new HashMap<String, HashMap<String, Float>>();
	private static HashMap<String, HashMap<String, Integer>> allTheNormalTF = new HashMap<String, HashMap<String, Integer>>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
