package ����;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;

import javax.swing.JTextArea;

public class MainGui {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try {
		new Gui();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
class Gui extends Frame{
	public Gui()throws InterruptedException{
	setTitle("Search");
	setLayout(new GridLayout(2,1));
	setLocation(200,200);
	setSize(450, 400);
	setResizable(false);
	setBackground(new Color(204,204,255));
	Panel p1=new Panel(new GridLayout(1,2));
	JTextArea t1=new JTextArea();
	Button b1=new Button();
	p1.add(t1);
	p1.add(b1);
    JTextArea p2 = new JTextArea() ;
    p2.setEditable(false);
    add(p1);
    add(p2);
    
    setVisible(true);
	}

}