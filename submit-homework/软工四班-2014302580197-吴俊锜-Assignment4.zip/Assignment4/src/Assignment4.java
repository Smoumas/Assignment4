
public class Assignment4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI gui=new GUI();
	}

}
