import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class GUI {
	private JFrame jf;
	private JTextField jtf;
	private JButton jb;
	private JTextArea jta;
	private JScrollPane jsp;
	
	public GUI(){
		frameInit();
		textFieldInit();
		buttonInit();
		textAreaInit();
		jf.setVisible(true);
	}
	
	//�����ʼ��
	public void frameInit(){
		jf=new JFrame("Professor Searcher");
		jf.setBounds(400,200,500,400);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	//TextField��ʼ��
	public void textFieldInit(){
		jtf=new JTextField();
		jtf.setSize(280,20);
		jtf.setLocation(30, 40);
		jf.add(jtf);
		//ΪTextField���Ӽ��̻س��¼�
		jtf.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				int code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER){
					long start=System.currentTimeMillis();
					jta.setText("");
					String str=jtf.getText();
					Process p=new Process(str);
					str=p.getText();
					Info info=new Info(str,jta);
					info.getInfo();
					long end=System.currentTimeMillis();
					double time=((double)(end-start)/1000);
					jta.append("����ʱ:"+time+"s");
				}
			}
		});
	}
	
	//��ť��ʼ��
	public void buttonInit(){
		jb=new JButton("Search");
		jb.setSize(100,20);
		jb.setLocation(350,40);
		jf.add(jb);
		//ΪButton���Ӱ�ť����¼�
		jb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				long start=System.currentTimeMillis();
				jta.setText("");
				String str=jtf.getText();
				Process p=new Process(str);
				str=p.getText();
				Info info=new Info(str,jta);
				info.getInfo();
				long end=System.currentTimeMillis();
				double time=((double)(end-start)/1000);
				jta.append("����ʱ:"+time+"s");
			}
		});
	}
	
	//TextArea��ʼ��
	public void textAreaInit(){
		jta=new JTextArea();
		jta.setEditable(false);
		jsp=new JScrollPane(jta);
		jsp.setLocation(30,100);
		jsp.setSize(420,200);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		jf.add(jsp);
	}
	
	/**
	 * Process���Ƕ�TextField�е����ֽ��д�����ȥ�����ּ�ո��Լ��ֶ���λ�ո�
	 * @author user1
	 *
	 */
	class Process{
		private String text;
		
		public Process(String text){
			this.text=text;
			text=text.trim();
			text=text.replaceAll(" ","");
			this.text=text;
		}

		public String getText() {
			return text;
		}
	}
}
