import javax.swing.JTextArea;

/**
 * 
 * Professor���װ�˽��ڶ����Լ���ѯ�ؼ��ֵ�tfֵ
 * @author user1
 *
 */
public class Professor implements Comparable<Professor>{
	private String name;
	private String title;
	private String direction;
	private String phone;
	private String email;
	private double tf;
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getTf() {
		return tf;
	}

	public void setTf(double tf) {
		this.tf = tf;
	}

	//ʵ��Comparable�ӿڣ����ڶ���ͨ��tfֵ�Ĵ�С�Ӵ�С����
	@Override
	public int compareTo(Professor pro) {
		// TODO Auto-generated method stub
		int temp=0;
		if(this.tf>pro.getTf())
			temp=1;
		else if(this.tf<pro.getTf())
			temp=-1;
		else	//��tfֵ��ͬ����ͨ��������������
			temp=this.name.compareTo(pro.getName());
		return temp;
	}
	
	//�����ڵ�������ͷ�Σ��о����򣬵绰��Email���ӵ�TextArea��
	public void show(JTextArea jta){
		jta.append(name);
		jta.append(System.lineSeparator());
		jta.append(title);
		jta.append(System.lineSeparator());
		jta.append(direction);
		jta.append(System.lineSeparator());
		jta.append(phone);
		jta.append(System.lineSeparator());
		jta.append(email);
		jta.append(System.lineSeparator());
		jta.append(System.lineSeparator());
		
		return;
	}
}
