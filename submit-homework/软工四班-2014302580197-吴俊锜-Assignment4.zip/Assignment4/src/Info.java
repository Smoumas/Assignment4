import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextArea;

import com.mysql.jdbc.Connection;

/**
 * Info��ʵ�ִ����ݿ���ɸѡ������Ҫ��Ľ��ڶ���
 * @author user1
 *
 */
public class Info {
	private String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private String key=null;
	private Professor[] professors=new Professor[100];
	private Professor pro;
	private JTextArea jta;
	private int index=0;
	private double tf[]=new double[100];
	
	public Info(String key,JTextArea jta){
		this.key=key;
		for(int i=0;i<100;i++){
			professors[i]=new Professor();
		}
		this.jta=jta;
	}
	
	//���ݿ�����
	public Connection getConnection(){
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn=(Connection) DriverManager.getConnection(url);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public void getInfo(){
		Connection conn=null;
		Statement state=null;
		try{
			conn=getConnection();
			state=conn.createStatement();
			//ͨ����������ɸѡ
			ResultSet rs=state.executeQuery("select * from 2014302580197_professor_info where name like '%"+key+"%'");
			while(rs.next()){
				selectExceptDirection(rs);
				index++;
			}
			
			//ͨ��ͷ�ν���ɸѡ
			rs=state.executeQuery("select * from 2014302580197_professor_info where title like '%"+key+"%'");
			index=0;
			while(rs.next()){
				selectExceptDirection(rs);
				index++;
			}
			
			//ͨ���о��������ɸѡ
			rs=state.executeQuery("select * from 2014302580197_professor_info where direction like '�о�����%"+key+"%'");
			index=0;
			while(rs.next()){
				selectByDirection(rs);
				index++;
			}
			
			//ͨ����ϵ�绰����ɸѡ
			rs=state.executeQuery("select * from 2014302580197_professor_info where phone like '��ϵ�绰%"+key+"%'");
			index=0;
			while(rs.next()){
				selectExceptDirection(rs);
				index++;
			}
			
			//ͨ��Email����ɸѡ
			rs=state.executeQuery("select * from 2014302580197_professor_info where email like 'Email%"+key+"%'");
			index=0;
			while(rs.next()){
				selectExceptDirection(rs);
				index++;
			}
			index=0;
			
			getCount();
			sort();
			printToTextArea();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				state.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//ͨ��������ͷ�Σ��绰����Email�Խ��ڶ������ɸѡ
	public void selectExceptDirection(ResultSet rs){
		try {
			String name = rs.getString(1);
			String title=rs.getString(2);
			String direction=rs.getString(3);
			//�еĽ�ʦ�о�����һ��ֱ�ӿ���..�Ը��н��д���
			if(direction.equals(""))
				direction="�о�����:";
			String phone=rs.getString(4);
			String email=rs.getString(5);
			//��ֹ���������е����ж��󣬲���֮ǰ�Ƚ����ж�
			if(professors[index].getName()==null||professors[index].getName().equals(name)){
				professors[index].setName(name);
				professors[index].setTitle(title);
				professors[index].setDirection(direction);
				professors[index].setPhone(phone);
				professors[index].setEmail(email);
				//��ϵ�绰��Email�����֪�����㼸����..�����ķִ��㷨Ҳд���е㲻���⣩..ֻ���ó��ȱ������tfֵ
				tf[index]=tf[index]+(double)(key.length())/(name.length()+title.length()+direction.length()+phone.length()+email.length());
				professors[index].setTf(tf[index]);
			}else{
				do{
					index++;
				}while(professors[index].getName()!=null&&!(professors[index].getName().equals(name)));
				professors[index].setName(name);
				professors[index].setTitle(title);
				professors[index].setDirection(direction);
				professors[index].setPhone(phone);
				professors[index].setEmail(email);
				tf[index]=tf[index]+(double)(key.length())/(name.length()+title.length()+direction.length()+phone.length()+email.length());
				professors[index].setTf(tf[index]);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//��������Direction��ɸѡ��������Ϊ�о������п��ܺ��ж���ؼ���
	public void selectByDirection(ResultSet rs){
		try {
			String name = rs.getString(1);
			String title=rs.getString(2);
			String direction=rs.getString(3);
			if(direction.equals(""))
				direction="�о�����:";
			String tempDirection=direction.replaceAll(key,"");
			int count=(direction.length()-tempDirection.length())/key.length();		//��ȡ�о������йؼ��ֵĸ���
			String phone=rs.getString(4);
			String email=rs.getString(5);
			tf[index]=tf[index]+(double)(key.length()*count)/(name.length()+title.length()+direction.length()+phone.length()+email.length());
			if(professors[index].getName()==null||professors[index].getName().equals(name)){
				professors[index].setName(name);
				professors[index].setTitle(title);
				professors[index].setDirection(direction);
				professors[index].setPhone(phone);
				professors[index].setEmail(email);
				tf[index]=tf[index]+(double)(key.length()*count)/(name.length()+title.length()+direction.length()+phone.length()+email.length());
				professors[index].setTf(tf[index]);
			}else{
				do{
					index++;
				}while(professors[index].getName()!=null&&!(professors[index].getName().equals(name)));
				professors[index].setName(name);
				professors[index].setTitle(title);
				professors[index].setDirection(direction);
				professors[index].setPhone(phone);
				professors[index].setEmail(email);
				tf[index]=tf[index]+(double)(key.length()*count)/(name.length()+title.length()+direction.length()+phone.length()+email.length());
				professors[index].setTf(tf[index]);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//��ȡ�����еĽ��ڶ������
	public void getCount(){
		for(double d:tf){
			if(d!=0.0)
				index++;
		}
	}
	
	//����tfֵ�Ӵ�С��˳��Խ��ڶ����������
	public void sort(){
		for(int i=0;i<index;i++){
			for(int j=0;j<index-i-1;j++){
				if((professors[j].compareTo(professors[j+1]))==-1){
					Professor temp=new Professor();
					temp=professors[j];
					professors[j]=professors[j+1];
					professors[j+1]=temp;
				}
			}
		}
	}
	
	//��ɸѡ������Ϣ��ӡ��TextArea��
	public void printToTextArea(){
		for(int i=0;i<index;i++){
			pro=professors[i];
			pro.show(jta);
		}
		jta.append("����"+index+"���������");
		jta.append(System.lineSeparator());
	}
}
