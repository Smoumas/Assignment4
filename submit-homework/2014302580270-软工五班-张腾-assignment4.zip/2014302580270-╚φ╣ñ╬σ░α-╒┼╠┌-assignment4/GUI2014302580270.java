import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GUI2014302580270 {
    public static void main(String[] args) {
        JFrame bg = new JFrame("Search");
        bg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bg.setSize(500,500);
        bg.setVisible(true);
        bg.setLayout(null);
        bg.setResizable(false);

        JTextArea input = new JTextArea();
        input.setBounds(10,10,360,60);
        bg.add(input);

        JButton jb = new JButton("search");
        jb.setBounds(380,10,100,60);
        bg.add(jb);

        JTextArea info1 = new JTextArea();
        info1.setBounds(10, 100, 470, 350);
        bg.add(info1);

        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String keyword = input.getText().toLowerCase();
                DBHelper2014302580270 dbHelper = new DBHelper();
                try {
                    ArrayList<String> result = dbHelper.getInfo();
                    int times = 0;
                    Pattern pattern = Pattern.compile(keyword);
                    for (String info : result)
                    {
                        Matcher matcher = pattern.matcher(info.toLowerCase());
                        int count=0;
                        while(matcher.find()) {
                            count++;
                            info1.append(info);
                        }
                    }

                } catch (SQLException e1) {
                    e1.printStackTrace();
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
            }
        });

        bg.repaint();
    }
}
