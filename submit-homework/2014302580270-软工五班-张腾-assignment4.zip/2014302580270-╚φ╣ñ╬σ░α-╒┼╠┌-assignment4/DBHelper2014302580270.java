import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBHelper2014302580270 {
    private Connection register() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/assignment4?user=root&password=002899");
        return connection;
    }

    public ArrayList<String> getInfo() throws SQLException, ClassNotFoundException {
        Connection connection = register();

        ResultSet rs;
        rs = connection.createStatement().executeQuery("select * from 2014302580270_professor_info");

        ArrayList<String> infos = new ArrayList<>();
        while (rs.next()) {
            String info = "";
            for (int i = 1; i<=5; i++) {
                info += rs.getString(i) + "\n";
            }
            infos.add(info);
        }
        return infos;
    }
}
