import java.util.Comparator;

public class TfComparator implements Comparator<Result_Info>
{

	@Override
	public int compare(Result_Info o1, Result_Info o2) {
		// TODO Auto-generated method stub
		if (o1.getTf() > o2.getTf())
			   return -1;
			else if (o1.getTf() < o2.getTf())
			   return 1;
			else	   
			   return 0;

	}


     
}
