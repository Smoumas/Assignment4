import java.util.ArrayList;

public class KeywordsMatcher {     
	private String[] list={"a","an","the","and","of"};
	
	public boolean Stop(String s)
	{
		for(int i=0;i<list.length;i++)
		{
			if(s.contains(list[i]))
				return false;
		}
		return true;
	}
	
	public void getResult(String s, ArrayList<Result_Info> list1,ArrayList<Teacher_Info> list2)
	{
		s=s.toLowerCase();
		for(int i=0;i<list2.size();i++)
		{
			String info=list2.get(i).getName()+" "+list2.get(i).getEducationBackground()+" "+list2.get(i).getResearchInterests();
			info=info.toLowerCase();
			if(info.contains(s))
			{
				Result_Info result=new Result_Info(list2.get(i),s);
				list1.add(result);
			}
		}
	}
}
