import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Result_Info {

	private String name;
	private String educationBackground;
	private String researchInterests;
	private String phone;
	private String email;
	private String keywords;
	private double tf;
	
	public Result_Info(Teacher_Info teacher,String s)
	{
		this.name=teacher.getName();
		this.educationBackground=teacher.getEducationBackground();
		this.researchInterests=teacher.getResearchInterests();
		this.email=teacher.getEmail();
		this.phone=teacher.getPhone();
		this.keywords=s;
		this.tf=0;
		calTF();
	}
	
	public void calTF()
	{
		String s2=name+educationBackground+researchInterests;
		Pattern pattern = Pattern.compile(keywords);
	    Matcher matcher = pattern.matcher(s2);
	    while (matcher.find())
	    	tf++;
	    String[] s=s2.split(" ");
	    tf=tf/(s.length);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getTf() {
		return tf;
	}
	public void setTf(double tf) {
		this.tf = tf;
	}
	
	
}
