import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class SearchEngine {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
	
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	    ArrayList<Teacher_Info> arraylist_teacher=new ArrayList<Teacher_Info>();
	    DataReader reader=new DataReader(url);
	    reader.getData(arraylist_teacher);

	    JFrame frame=new JFrame("SearchEngine");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);
        frame.setLayout(null);
        frame.setVisible(true);
     
        JTextField InputField = new JTextField();
        frame.add(InputField);
        InputField.setBounds(10, 30, 350, 40);
     
        JTextArea OutputField=new JTextArea();
        JScrollPane scroll = new JScrollPane(OutputField);
        frame.add(scroll);
        scroll.setBounds(30, 100, 525, 430);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
     
        JButton button_search=new JButton();
        button_search.setText("Search");
        frame.add(button_search);
        button_search.setBounds(370, 30, 100, 40);
        button_search.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent event) {
        	 String keywords=InputField.getText();
        	 KeywordsMatcher matcher=new KeywordsMatcher();
        	 ArrayList<Result_Info> result=new ArrayList<Result_Info>();
        	 if(keywords.equals(""))
        		 OutputField.setText("Please input a valid keywords");
        	 else
        	 {
        		 if(!matcher.Stop(keywords))
        			 OutputField.setText("Please dont input \"a\",\"an\",\"the\",\"and\"and\"of\"");
        		 else
        		 {
        			 OutputField.setText("");
        			 matcher.getResult(keywords, result, arraylist_teacher);
        			 Collections.sort(result,new TfComparator());
        			 String Info="";
        			 for(int i=0;i<result.size();i++)
        			 {
        				 Info="Name:"+result.get(i).getName()+"\n"+"EducationBackground:"+result.get(i).getEducationBackground()
        						 +"\nReseatchInterests:"+result.get(i).getResearchInterests()+"Email:"+result.get(i).getEmail()+"\n"
        						 +"Phone:"+result.get(i).getPhone()+"\n";
        				 OutputField.setText(OutputField.getText()+"\n"+Info);
        			 }
        		 }
        	 }
         }
     });
          
        JButton button_clear=new JButton();
        button_clear.setText("Clear");
        frame.add(button_clear);
        button_clear.setBounds(480, 30, 100, 40);
        button_clear.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent event) {
        	 OutputField.setText("");
        	 InputField.setText("");
         }
     });
	}

}