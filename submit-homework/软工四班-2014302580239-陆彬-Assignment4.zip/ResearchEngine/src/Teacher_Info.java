
public class Teacher_Info {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String phone;
	private String email;
	
	public Teacher_Info(String s1,String s2,String s3,String s4,String s5)
	{
	    this.name=s1;
	    this.educationBackground=s2;
	    this.researchInterests=s3;
	    this.email=s4;
	    this.phone=s5;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
