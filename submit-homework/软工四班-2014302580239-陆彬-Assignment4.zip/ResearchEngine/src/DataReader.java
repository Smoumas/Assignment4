import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class DataReader {

	private String url;
	
	public DataReader(String s)
	{
		this.url=s;
	}
	
	public void getData(ArrayList<Teacher_Info> arraylist) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");

        Connection connection = DriverManager.getConnection(url);

        Statement sql=connection.createStatement();
        ResultSet results = sql.executeQuery("select * from 2014302580239_professor_info");

        while (results.next())
        {
        	arraylist.add(new Teacher_Info(results.getString("name"),results.getString("educationBackground"),results.getString("researchInterests"),results.getString("email"),results.getString("phone")));
        }
	}
}
