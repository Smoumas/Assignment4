
public class teacher {
	private String name;
	private String introduction;
	private String major;
	private String email;
	private String telephoneNumber;
	
		
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	
	public String getEmail(){
		return email;
	}
	public void setEmail(String email){
		this.email=email;
	}
	
	public String getTelephoneNumber(){
		return telephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber){
		this.telephoneNumber=telephoneNumber;
	}
	
	public String getIntroduction(){
		return introduction;
	}
	public void setIntroduction(String introduction){
		this.introduction=introduction;
	}
	
	public String getMajor(){
		return major;
	}
	public void setMajor(String major){
		this.major=major;
	}

}
