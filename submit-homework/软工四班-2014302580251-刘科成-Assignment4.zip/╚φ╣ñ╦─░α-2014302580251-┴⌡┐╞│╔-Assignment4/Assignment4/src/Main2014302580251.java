import javax.swing.JFrame;

public class Main2014302580251 {
	public static void main(String[] args){
		
		GUI gui=new GUI();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(400,300);
		gui.setVisible(true);
		
		}
}
