import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class GUI extends JFrame{
	public JTextField textField;
	private JButton button;
	private JTextArea textArea;
	
	public GUI()
	{
		super("Search Professor");
		setLayout(new FlowLayout());
		
		JTextField textField=new JTextField(25);
		add(textField);
		
		JButton button=new JButton("��Ҫ���ң�ֱ���ûس���");
		add(button);
		
		JTextArea textArea=new JTextArea(10,25);
		add(new JScrollPane(textArea));
		
		MyPrintStream myPrintStream=new MyPrintStream(System.out,textArea);
		System.setOut(myPrintStream);
		System.setErr(myPrintStream);
		
		Handler handler=new Handler();
		textField.addActionListener(handler);
		
	}
	private class Handler implements ActionListener
	{

		
		public void actionPerformed(ActionEvent event) {
			SqlReader sr=new SqlReader();
			String str="";
			str=event.getActionCommand();
			for(int i=0;i<sr.list.size();i++){
				if(sr.list.get(i).getName().contains(str)||
				   sr.list.get(i).getIntroduction().contains(str)||
				   sr.list.get(i).getMajor().contains(str)||
				   sr.list.get(i).getEmail().contains(str)||
				   sr.list.get(i).getTelephoneNumber().contains(str)){
					System.out.println(sr.list.get(i).getName());
					System.out.println(sr.list.get(i).getIntroduction());
					System.out.println(sr.list.get(i).getMajor());
					System.out.println(sr.list.get(i).getEmail());
					System.out.println(sr.list.get(i).getTelephoneNumber());
					System.out.println();
				}
			}
			
		
		}
		
	}
}
