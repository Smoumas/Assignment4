import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class SqlReader {
	public ArrayList<teacher> list;
	public SqlReader(){this.list=read();}
	
	public static ArrayList<teacher> read(){
	ArrayList<teacher> list=new ArrayList();

	String className="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	String userName="root";
	String userPassword="123456";
	String tableName="2014302580251_professor_info";
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	try{
	Class.forName(className);
	con=DriverManager.getConnection(url, userName, userPassword);
	ps=con.prepareStatement("select * FROM "+tableName);
	rs=ps.executeQuery();
	while(rs.next())
	{
		teacher t=new teacher();
		for(int i=0;i<rs.getMetaData().getColumnCount();++i){
			if(i==0)
				t.setName(rs.getString(i+1));
			if(i==1)
				t.setIntroduction(rs.getString(i+1));
			if(i==2)
				t.setMajor(rs.getString(i+1));
			if(i==3)
				t.setEmail(rs.getString(i+1));
			if(i==4)
				t.setTelephoneNumber(rs.getString(i+1));
		}
		list.add(t);
		System.out.println();
	}
	}catch(Exception e){
		System.out.println(e.toString());
	}finally{
		try{rs.close();}catch(Exception e){}
		try{con.close();}catch(Exception e){}
	}
	return list;
	}
	
}
