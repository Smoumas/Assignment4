import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class GUI {
	private static JFrame mainJF;
	private static JTextArea areaInput;		
	private static JTextArea areaOutput;
	private static JButton btn;
	private static JScrollPane jsp;
	
	public static void main(String[] args) {
		GUI gui = new GUI() ;
	}
	
	public GUI(){
		final Search sear = new Search();				//新建Search对象
		init();
		JOptionPane.showMessageDialog(mainJF.getContentPane(),
				"可以用空格隔开多个关键词！", "提示", JOptionPane.INFORMATION_MESSAGE);
		btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent actionEvent)
            {
            	areaOutput.setText("");
                String a = "" ;
                for(int i = 0; i < sear.calcTF(areaInput.getText()).size(); i++)
                a += "\n\n" + sear.calcTF(areaInput.getText()).get(i);
                areaOutput.setText(a);

        		areaOutput.setCaretPosition(0);			//使滚动条保持在开头处
            }
        });
	}
	public void init(){
		mainJF = new JFrame("计院教授搜索引擎");
		mainJF.setBounds(300, 100, 700, 600);
		mainJF.setLayout(null);
		mainJF.setResizable(false);
		mainJF.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainJF.setVisible(true);

		areaInput = new JTextArea();
		mainJF.add(areaInput);
		areaInput.setBounds(50, 50, 390, 40);
		areaInput.requestFocusInWindow();
		areaInput.setText("");
		
		btn = new JButton("搜索");
		mainJF.add(btn);
		btn.setBounds(450, 50, 100, 40);
		
		jsp = new JScrollPane();
		jsp.setBounds(50, 100, 500, 400);
		areaOutput = new JTextArea();
		areaOutput.setText("");
		areaOutput.setEditable(false);
		jsp.setViewportView(areaOutput);
		mainJF.add(jsp);
	}
}