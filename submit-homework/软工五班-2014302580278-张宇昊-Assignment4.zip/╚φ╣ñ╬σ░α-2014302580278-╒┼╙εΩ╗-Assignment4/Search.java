﻿import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search {
	ArrayList<String> teachers = new ArrayList<String>();
	
	
	//构造函数
	public Search(){
		Database dtb = new Database();
	}
	
	//数据库
	public class Database{
		private String url;
		public Connection conn = null;
		public Database(){
			url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
			connect();	
			query();
		}

		
		/**
		 * @return
		 * Open Connection
		 */
		public void connect(){
			
				try {
					Class.forName("com.mysql.jdbc.Driver");
					try {
						conn = DriverManager.getConnection(url);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					System.out.println("加载MySQL驱动程序成功");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
		}
		
		// 查询
	    public void query()
	    {
	        try
	        {
	            Statement sm = conn.createStatement();
	            ResultSet rs = sm.executeQuery("select * from 2014302580278_professor_info");
	            
	            while (rs.next())
	            {
	            	String tea = "姓名：" 
	            			+ rs.getString(1)
	            			+"\n" + rs.getString(2)
	            			+"\n" + rs.getString(3)
	            			+"\n" + "研究方向：" + rs.getString(4)  ;
	                teachers.add(tea);
	            }
	        }
	        catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	    }
	}
	
	//计算TF值并排序
	public ArrayList<String> calcTF(String keywords){
		
		//建立包含TF值变量的教师类
		class Teacher{
			String description;
			double tf;
			Teacher(String d, double t){
				description = d;
				tf = t;
			}
		}
		
		ArrayList<String> teacherResult = new ArrayList<String>();
		ArrayList<Teacher> TFBoys = new ArrayList<Teacher>();
		
		//计算每个老师的TF值并导入到老师数组里
		for(int i = 0; i < teachers.size(); i++){
			String str = teachers.get(i);
			String[] kws = keywords.split(" ");
			double foundWords = 0;
			for(int x = 0; x < kws.length;x++){
				Pattern p = Pattern.compile(kws[x].toLowerCase());
		        Matcher m = p.matcher(teachers.get(i).toLowerCase());
		        int appearTime = 0;
		        while(m.find())
		        {
		        	appearTime++;
		        }
		        foundWords += appearTime * kws[x].length();
			}
			double tf = foundWords / teachers.get(i).length();	//计算TF值
			Teacher t = new Teacher(teachers.get(i), tf);
			TFBoys.add(t);			//导入
		}
		
		//冒泡排序
		for(int i = TFBoys.size() - 1; i > 0; --i){
			for(int j = 0; j < i; ++j){
				if(TFBoys.get(j).tf < TFBoys.get(j+1).tf){
					Teacher temp;
					temp = TFBoys.get(j);
					TFBoys.set(j, TFBoys.get(j+1));
					TFBoys.set(j + 1, temp);
				}
			}
		}
		//将tf值不为0的描述按顺序添加进字符串数组tfBoys
		ArrayList<String> tfBoys = new ArrayList<String>();
		for(int i = 0; i < TFBoys.size() ; i++){
			if(TFBoys.get(i).tf != 0)
				tfBoys.add(TFBoys.get(i).description);
		}
		return tfBoys;		
	}
}
