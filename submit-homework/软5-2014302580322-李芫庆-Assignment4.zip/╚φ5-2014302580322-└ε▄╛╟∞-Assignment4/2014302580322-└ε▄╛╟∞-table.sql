/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580322_professor_info` (
	`name` varchar (135),
	`educationBackground` varchar (3000),
	`researchInterests` varchar (3000),
	`email` varchar (135),
	`phone` varchar (135)
); 
