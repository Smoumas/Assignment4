package engine;
//2014302580322-��ܾ��
public class Main {

	public static void main(String[] args) {
		GUIEngine appEngine=new GUIEngine();// TODO Auto-generated method stub

	}

}
