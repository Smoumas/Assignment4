package com.search;

public class KeywordsMatcher {
private String keywords;
public void setKeywords(String keywords)//��ȡkeywords
{
	this.keywords=keywords;
	
}
public  double fetchKeywords(String text)//����tf
{           
	text=text.toLowerCase();//��text�ļ�ȫСд
	keywords=keywords.toLowerCase();//���ؼ���Сд
         String[] v=text.split(" ");
         int ncount=0;
         for(int i=0;i<v.length;i++){
        	 if(v[i].compareTo(keywords)==0)//������ؼ���ƥ��
        	 {
        		 ncount++;
        	 }
         }
         double tf=ncount/v.length;
         return tf;
	/*Pattern pattern = Pattern.compile( keywords);
    Matcher matcher = pattern.matcher(text);
    double tf=0.0;
    ArrayList<SearchResult> searchResultLists=new ArrayList<SearchResult>();
    
    while (matcher.find()) {
    	add(searchResultLists,matcher.group().trim());
        
    }*/
		
}



}


