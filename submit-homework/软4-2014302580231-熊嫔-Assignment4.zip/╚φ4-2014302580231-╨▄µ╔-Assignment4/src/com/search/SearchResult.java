package com.search;

public class SearchResult {
	private ProfessorInfo pi =new ProfessorInfo();
	public SearchResult(ProfessorInfo pi)//���캯��
	{
		
	}
    public SearchResult(ProfessorInfo pi,double tf)
    {
    	
    }
    public ProfessorInfo getPi(){
		return pi;
    	
    }
    public void setPi(ProfessorInfo pi){
    	this.pi=pi;
    }

}

