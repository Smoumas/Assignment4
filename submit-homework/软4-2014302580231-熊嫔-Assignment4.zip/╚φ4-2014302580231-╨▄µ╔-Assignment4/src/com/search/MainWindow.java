package com.search;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class MainWindow{
	private JFrame frmProfessorSearcher=new JFrame();
	private JTextField textField =new JTextField();
	private JTextArea textArea =new JTextArea();
	private JButton button =new JButton("Search");
	private JScrollPane scrollPane=new JScrollPane(textArea);
    private ArrayList<ProfessorInfo> d=new ArrayList<ProfessorInfo>();
	private DataReader data=new DataReader();
	public MainWindow(){
		data.getConnection();
	}
	
public static void main(String args[]){
	MainWindow b=new MainWindow();//����
	b.initialize();
}
public void initialize(){
	Container container = frmProfessorSearcher.getContentPane();//��ȡһ������
	container.setLayout(null);
	container.setBackground(Color.yellow);
	frmProfessorSearcher.setVisible(true);
	frmProfessorSearcher.setSize(500, 400);
	frmProfessorSearcher.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	
	button.setBounds(350, 10, 100,50 );
	button.setVisible(true);
	container.add(button);
	button.addActionListener(new ActionListener(){//Ϊ��ť������굥���¼�
		public void actionPerformed(ActionEvent e){
			d.clear();//��ն�̬����
			textArea.setText("");
          try {
        	  String pi5=String.valueOf(textField.getText().charAt(0)).toUpperCase()+textField.getText().substring(1);//�ò�ѯ������ĸ���ִ�д
        	String pi4="select*from professor_info where  educationBackground regexp \""+pi5+"\"";
			ResultSet a=data.getProfessorInfo(pi4);
			KeywordsMatcher pi2=new KeywordsMatcher();
			while(a.next()){
				ProfessorInfo pi1=new ProfessorInfo();
				pi1.setName(a.getString(1));//����õ����ݽ��д���
				pi1.setEducationBackground(a.getString(2));
				pi1.setResearchInterests(a.getString(3));
				pi1.setEmail(a.getString(4));
				pi1.setPhone(a.getString(5));
				pi2.setKeywords(textField.getText());
				pi1.setTf(pi2.fetchKeywords(pi1.toString()));
				d.add(pi1);
			}
			output();
			sort();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			}
			
	});

	textField.setVisible(true);
	textField.setEditable(true);
	textField.setBounds(20, 10, 300, 50);
	textField.setColumns(8);
	container.add(textField);
	
	
	textArea.setVisible(true);
	textArea.setEditable(false);
	textArea.setBounds(0, 0, 400,300);
	textArea.setLineWrap(true);//�����Զ�����
	textArea.setWrapStyleWord(true);//���в�����
	scrollPane.setBounds(40, 100, 400, 300);
	scrollPane.setVisible(true);
	 scrollPane.setViewportView(textArea);
	container.add(scrollPane);	
	}

	public void output(){
		for(ProfessorInfo pi3:d){
				textArea.append(pi3.getName()+" \n"+pi3.getEducationBackground()+"\n"+pi3.getResearchInterests()+"\n"+pi3.getEmail()+"\n"+pi3.getPhone()+"\n");
		}
	}
	public void sort()//������
	{
		ProfessorInfo temp=new ProfessorInfo();
        for(int i=0;i<d.size()-1;i++){
            for(int j=i+1;j<d.size();j++){
                if(d.get(i).getTf()<d.get(j).getTf()){
                    temp=d.get(i);
                    d.set(i, d.get(j));
                    d.set(j,temp);
                }
            }

	}
	}
}
