package com.search;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




public class DataReader  {
	Connection con;
	Statement sql;
	public Connection getConnection(){
		try{
			Class.forName("net.sourceforge.jtds.jdbc.Driver");
			System.out.println("���ݿ��������سɹ�");
		}catch(ClassNotFoundException e){
               e.printStackTrace();			
		}
		try{
			con =DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/xp?user=root&password=19960608");
			System.out.println("���ݿ����ӳɹ�");
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return con;
	}
	public ResultSet getProfessorInfo(String order) throws SQLException{
		try{
		    sql=con.createStatement();
		}catch(SQLException e){
			e.printStackTrace();
		}
		ResultSet resultSet =sql.executeQuery(order);
		return resultSet;
		
	}
		
  

    
}
