package serch;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetsIn {
	private static int r1;
	private static String r5,r2,r3,r4;
	//public static String strArr[];
	public static double n=0;
	public static String StrArr[];
	public static int m=0;
	public static Gui Gui;
	public static String sr;
	public static String r;
	public static String clear(String st){
		
		 Pattern p = Pattern.compile("[^a-zA-Z]");
		 Matcher m = p.matcher(st);
		 
		 sr= m.replaceAll(" ").trim();
		
		 return sr;
	}
	
	public static void getinfo(String key,int index){
		 //   ArrayList<GetsIn> an=new  ArrayList<GetsIn>();
		     GetInfo info=new GetInfo();
			//System.out.println(in.getName());
			 ArrayList<GetS> array1=info.getData(index);
			 for(GetS in:array1){
				r1=in.getId();
				r2=in.getName();
				// r=clear(r2);
				//System.out.println(r);
				r3=in.getMailbox();
				r4=in.getTel();
				r5=in.getIntrest();
				}
			    String strArr1[]=r2.split(" ");
			    strArr1[0]=strArr1[0].substring(0,strArr1[0].length()-1);
				String strArr2[]=r3.split(" ");
				String strArr3[]=r4.split(" ");
				String strArr4[]=r5.split(" ");
			
				for(int i=0;i<strArr1.length;i++){
					if(strArr1[i].equals(key)){
					 m++;
					 }
					}
				for(int i=0;i<strArr2.length;i++){
					if(strArr2[i].equals(key)){
					 m++;
					 }
				}
				for(int i=0;i<strArr3.length;i++){
					if(strArr3[i].equals(key)){
					 m++;
					 }
					}
				for(int i=0;i<strArr4.length;i++){
					if(strArr4[i].equals(key)){
					 m++;
					 }
					}
				
				n=(double)m/(strArr1.length+strArr2.length+strArr3.length+strArr4.length);
				//System.out.println(n);
				if(n>0){
					System.out.println(r2);
					System.out.println(r3);
					System.out.println(r4);
					System.out.println(r5);
					
					Gui.textArea.append(r2+"\n");
					Gui.textArea.append(r3+"\n");
					Gui.textArea.append(r4+"\n");
					Gui.textArea.append(r5+"\n");
					}
				m=0;
			   // return n;
	}

}
