package serch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class GetInfo {

	//private static int r1;
	//private static String r5,r2,r3,r4;
	
	
	public static ArrayList<GetS> getData(int index){
		ArrayList<GetS> array1=new ArrayList<>();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		 conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		 
		  String sql="select id, name,mailbox,tel,intrest from mytable where id=?";
			
		  ps=conn.prepareStatement(sql);
		  
		  ps.setObject(1, index);
		  
		 rs= ps.executeQuery();
		// r1= rs.getString(2);
		  while(rs.next()){
			  GetS  in=new GetS();
			/*  r1=rs.getInt(1);
		      r2=rs.getString(2);
		      r3=rs.getString(3);
		      r4=rs.getString(4);
		      r5=rs.getString(5);
		      */
			  in.setId(rs.getInt(1));
			  in.setName(rs.getString(2));
			  in.setMailbox(rs.getString(3));
			  in.setTel(rs.getString(4));
			  in.setIntrest(rs.getString(5));
			  array1.add(in);
		 }
		 
	} catch (ClassNotFoundException e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
	}finally{
		
		
			try {
				if(rs!=null){
				rs.close();
				}
				if(ps!=null){
					ps.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		
	}
	return array1;
	}
	
}
