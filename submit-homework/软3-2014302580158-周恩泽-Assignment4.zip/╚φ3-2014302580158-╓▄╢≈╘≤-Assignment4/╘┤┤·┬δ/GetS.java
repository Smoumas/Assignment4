package serch;

public class GetS {
	private int Id;
	private String Name;
	private String Mailbox;
	private String Tel;
	private String Intrest;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getMailbox() {
		return Mailbox;
	}
	public void setMailbox(String mailbox) {
		Mailbox = mailbox;
	}
	public String getTel() {
		return Tel;
	}
	public void setTel(String tel) {
		Tel = tel;
	}
	public String getIntrest() {
		return Intrest;
	}
	public void setIntrest(String intrest) {
		Intrest = intrest;
	}
	
	

}
