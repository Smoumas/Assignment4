package serch;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Gui extends JFrame {
	private JTextField textField;
	public static JTextArea textArea;
    private static String str;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui frame = new Gui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 */
	
	 public static boolean isEmptyString(String str)
	 {
	 return str == null || str.trim().length() == 0;
	 }
	 
	public Gui() {
	    
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setTitle("searcher");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		getContentPane().add(textField, BorderLayout.NORTH);
		textField.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBackground(Color.ORANGE);
		getContentPane().add(textArea, BorderLayout.CENTER);
		
		JButton button = new JButton("\u641C\u7D22");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				GetsIn in=new GetsIn();
				str=textField.getText();
				for(int i=1;i<12;i++){
				in.getinfo(str,i);
				}
				String str1=textArea.getText();
				boolean sign=isEmptyString(str1);
				if(sign){
					textArea.setText("û��ƥ����");
				}
				
			}
		});
		
		getContentPane().add(button, BorderLayout.SOUTH);
	}

}
