-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mytable`
--

DROP TABLE IF EXISTS `mytable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mytable` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `mailbox` varchar(30) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `intrest` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mytable`
--

LOCK TABLES `mytable` WRITE;
/*!40000 ALTER TABLE `mytable` DISABLE KEYS */;
INSERT INTO `mytable` VALUES (1,'Berenson, Dmitry - WPI','dberenson@wpi.edu','+1-508-831-5587','Motion planning Robotic manipulation Medical robotics'),(2,'Brown, David - WPI','dcb@wpi.edu','+1-508-831-5618','AI in Design Human Computer Interaction Artificial Intelligence Intelligent Interfaces'),(3,'Chernova, Sonia - WPI','soniac@wpi.edu','+1-508-831-6547','autonomous robots interactive robot learning human computation crowdsourcing machine learning'),(4,'Gennert, Michael - WPI','michaelg@wpi.edu','+1-508-831-5476','Robotics Medical Imaging Autionomous Navigation'),(5,'Heffernan, Neil - WPI','nth@wpi.edu','+1-508-831-5569','null'),(6,'Ruiz, Carolina - WPI','ruiz@wpi.edu','+1-508-831-5640','Data Mining Machine Learning Artificial Intelligence Genomics Clinical Medicine'),(7,'Rich, Charles - WPI','rich@wpi.edu','+1-508-831-5945','Artificial intelligence Human-robot interaction Intelligent user interfaces Serious games'),(8,'Sidner, Candace L. - WPI','sidner@wpi.edu','+1-508-831-6637','Natural Language Processing AI Intelligent User Interfaces Collaboration Human Robot Interaction'),(9,'Brown, David - WPI','dcb@wpi.edu','+1-508-831-5618','AI in Design Human Computer Interaction Artificial Intelligence Intelligent Interfaces'),(10,'Dougherty, Daniel - WPI','dd@wpi.edu','+1-508-831-5621','Logic Security Software'),(11,'Guttman, Joshua - WPI','guttman@wpi.edu','+1-508-831-6054','Information Security Theoretical Computer Science Logic Formal Methods Programming Languages');
/*!40000 ALTER TABLE `mytable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-13 16:59:45
