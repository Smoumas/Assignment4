import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Read {
	
	public String[] Get() throws SQLException{
	
		String []s = null;
		try {
			dbc.Connect();
			Statement st = null;
			st = (Statement) dbc.conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM professor_info");
			s = new String[j];
			s[0]="Name:"+rs.getString("name")+"\n\rEducation Background:"+rs.getString("educationBackground")+"\n\rResearch Interests:"+rs.getString("researchInterests")+"\n\rEmail: "+rs.getString("email")+"\n\rPhone:"+rs.getString("phone");
			
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			
		
	}
	
	
}
