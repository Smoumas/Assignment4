import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;


public class Match
{
	private ArrayList<String> keywordsList;
	private ArrayList<Search> SearchResultList;
	private ArrayList<String> stopWords;
	public Match()
	{
		
		Read dataReader=new Read();
		SearchResultList=new ArrayList<Search>();
		
		
	}
	public void Tf()
	{
			
		for(Search:SearchList)
		{
				
			String[] tempSplitWords;
			double tf=0;
			for(String tempKey:keywordsList)
			{
				Boolean isStopWord=false;
				for(String tempStopWord:stopWords)
				{
					if(tempStopWord.equals(tempKey))
						isStopWord=true;
				}
					
				if(isStopWord==true) continue;

				tempSplitWords=Search.getPi().getResearchInterests().split("\\s");
				for(String tempResearchInterests:tempSplitWords)
				{
					if(tempResearchInterests.equals(tempKey))
						tf+=0.5;			
				}
					    Search.setTf(tf);		
			}
		}
			
	}
}
	

	
	
