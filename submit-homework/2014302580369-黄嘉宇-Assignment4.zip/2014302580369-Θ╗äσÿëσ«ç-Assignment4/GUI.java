import java.awt.Color;
import java.awt.Font;
import java.awt.List;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;
class connect{
	 private static Connection conn; 
		static String sql;
	    public static void throws SQLException {  
	        try {  
	            Class.forName("com.mysql.jdbc.Driver").newInstance();  
	            System.out.println("成功创建数据表");  
	        } catch (InstantiationException e) {    
	            e.printStackTrace();  
	        } catch (IllegalAccessException e) {  
	            e.printStackTrace();  
	        } catch (ClassNotFoundException e) {            
	            e.printStackTrace();  
	        }  
	          
	        try {  
	            conn=DriverManager.getConnection("jdbc:mysql://localhost/beyondyushen", "root", "z"); 
	        } catch (SQLException e) {    
	            e.printStackTrace();  
	        }  
	    }
}
public class GUI {
	JFrame frame = new JFrame();
	JButton button = new JButton();
	JTextArea search = new JTextArea();
	JScrollPane scp = new JScrollPane();
	JPanel panel = new JPanel();
	String temp;
	Boolean btmp;
	static JTextArea result = new JTextArea();
	JTextArea txt = new JTextArea();
	static String str;
	public static void main(String[] args)
	{
		
			
				JFrame frame=new GUIFrame();
				frame.setVisible(true);
				frame.setTitle("搜索引擎");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
    public void go(){
		txt.setVisible(false);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Professor Searcher");
		frame.setSize(400, 300);;

		Font font = new Font("Comic Sans MS",Font.PLAIN,15);
		
		panel.setLayout(null);
		panel.setBounds(10, 10, 400, 22);
		frame.add(panel);

		button.setFont(font);
		button.setBounds(260, 0, 100, 22);
		button.setText("Search");
    
    }
}
			
				

		




	


