
import java.io.OutputStream;  
	import java.io.PrintStream;  
	import javax.swing.SwingUtilities;  
	import javax.swing.text.JTextComponent;  
	  

	public class Search extends PrintStream{  
	      
	    private JTextComponent component;  
	    private Str sb = new Str();
		
	      
	    public Search(OutputStream out, JTextComponent component){  
	        super(out);  
	        this.component = component;  
	    }  
	   
 
	    public void write(byte[] buf, int off, int len) {  
	        final String message = new String(buf, off, len);   
	  
	        SwingUtilities.invokeLater(new Runnable(){  
	            public void run(){  
	                append(message);  
	                component.setText(toString());  
	            }  
	        });  
	    }  
	    
	    
	}  

