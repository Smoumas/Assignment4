package assignment4_2014302580024;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Comparator;

import javax.swing.JTextArea;

public class ProcessDatas_2014302580024 {
	
	private String searchContent; 
	private Connection connection;//����
	private Statement statement;
	public final static String url="jdbc:mysql://localhost:3306//my_schema?characterEncoding=UTF-8";//����,ͬʱ��������Ϊutf8
	public static final String driver = "com.mysql.jdbc.Driver";//���ڼ�������  
	public static final String user = "root";  //�û���
	public static final String password = "123456";  //����
	public static final String tableName = "2014302580024_professor_info";	
	private String keyword;
	private String[] teacherName;
	private String[] educationBackground;
	private String[] researchInterests;
	private String[] email;
	private String[] phone;
	private String[] selected;
	private double[] tfs;
	private String[]stopWords={"of","in","on","that"};
	
	public ProcessDatas_2014302580024(){}
	
	public void Searchs(String keyword,JTextArea textArea) {
		
		teacherName=new String[200];
		educationBackground=new String[200];
		researchInterests=new String[200];
		email=new String[200];
		phone=new String[200];
		tfs=new double[200];
		selected=new String[200]; 
		String select="select * from 2014302580024_professor_info where Name like '%%"+keyword+"%%' or Introduction like '%"+keyword+"%' or Research like '%"+keyword+"%' or Email like'%"+keyword+"%' or Tel like '%"+keyword+"%'";
			
	try {
			Class.forName(driver);//��������
			connection = DriverManager.getConnection(url, user, password);
			statement = connection.createStatement();//����
			
		} catch (ClassNotFoundException e) {				
			System.out.println("�������ݿ�����ʧ��");
			e.printStackTrace();
			
		} catch (SQLException e) {				
			System.out.println("�������ݿ�ʧ��");
			e.printStackTrace();
		}
		
	try {
//			ResultSet rs  = connection.getMetaData().getTables(null, null, tableName, null );
			ResultSet rs=statement.executeQuery(select);
			int i=0;
			
			//����name��educationBackground��researchInterests��email��phone����Ϣ,������Щ��Ϣ������selected������
			while(rs.next())
			
			{
				teacherName[i]=rs.getString(2);
				System.out.println(rs.getString("Name"));
				educationBackground[i]=rs.getString(6);
				System.out.println(rs.getString("Introduction"));
				researchInterests[i]=rs.getString(5);
				System.out.println(rs.getString("Research"));
				email[i]=rs.getString(4);
				System.out.println(rs.getString("Email"));
				phone[i]=rs.getString(3);
				System.out.println(rs.getString("Tel"));
				selected[i]=rs.getString("Name")+rs.getString("Introduction")+rs.getString("Research")+rs.getString("Email")+rs.getString("Tel");
				i++;
			}
			
			for(int j=0;j<i;j++){
				//��selected�е����ݺ�keyword��TF�����н�������
				tfs[j]=CalTF(keyword,selected[j]);
				sortByTF(i);
				{
					displayResults(textArea,"\nname:"+teacherName[j]+"\neducationBackground:"+educationBackground[j]+"\nresearchInterests:"+researchInterests[j]+"\nemail:"+email[j]+"\nphone:"+phone[j]+"\nKeyword:"+keyword+"\nTF:"+tfs[j]+"\n****************************************************************************************************************************");
					
					}

				connection.close();
			}
		}catch (SQLException e) 
			{
				System.out.println("��ʾʧ��");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	//���ַ����зֶ�
	private  String[] cutWord(String str){
		String[]s=str.split("\\W+");
		return s;
	}
	//�����Ǵ�һ�������м���tfֵ
	private double CalTF(String keyWord,String List) {
		if(keyWord.equals(List)){
			return 1;
		}
		String[] keyWordList = cutWord(keyWord);// ��ȡ�ؼ���
		String[] nameList = cutWord(List);//�Ƕλ�
		int sameWord = 0;
		a:
		for (String s : keyWordList) {// �������еĹؼ���
			for (String stopWord : stopWords) {
				if (s.equals(stopWord)) {
					break a;
				}
			}
			for (String k : nameList) {// �Թؼ���Ϊ���������б�
				if (s.equals(k)) {
					sameWord++;
				}

			}
		}
		if(nameList.length==0){
			return 0;
		}
		double tf=(double)sameWord/nameList.length;
		return tf;
		
	}
	
	public void clearResults(JTextArea textArea)
	{
		textArea.setText(null);
	}
			
	

	private void displayResults(JTextArea textArea, String string) {
		// TODO �Զ����ɵķ������
		textArea.append(string);
	}

	//ð���㷨����
	private void sortByTF(int i) {
		// TODO �Զ����ɵķ������
		String temp1,temp2,temp3,temp4,temp5;
		for(int m=0;m<i;m++)
		{
			for(int n=m+1;n<i;n++)
			{
				if(tfs[m]<tfs[n])
				{
					double tmp=tfs[m];
					tfs[m]=tfs[n];
					tfs[n]=tmp;
					
					temp1=teacherName[m];
					teacherName[m]=teacherName[n];
					teacherName[n]=temp1;
					
					temp2=educationBackground[m];
					educationBackground[m]=educationBackground[n];
					educationBackground[n]=temp2;
					
					temp3=researchInterests[m];
					researchInterests[m]=researchInterests[n];
					researchInterests[n]=temp3;
					
					temp4=email[m];
					email[m]=email[n];
					email[n]=temp4;
					
				    temp5=phone[m];
					phone[m]=phone[n];
					phone[n]=temp5;
				}
			}
		}
	}

}
