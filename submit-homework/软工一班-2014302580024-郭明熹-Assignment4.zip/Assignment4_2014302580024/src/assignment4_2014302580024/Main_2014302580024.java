package assignment4_2014302580024;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;


import javax.swing.JTextArea;

public class Main_2014302580024 extends JFrame{
	
	private JTextField textField;
	private JButton search;
	private JButton clear;
	private JTextArea textArea;
	private JMenuBar bar = null;
    private ProcessDatas_2014302580024 pd =null;
	private String outputText = "";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Main_2014302580024 frame = new Main_2014302580024();
					
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_2014302580024() {
		final ProcessDatas_2014302580024 dr=new ProcessDatas_2014302580024();
    	//���ڵ�����
		this.getContentPane().setLayout(null);
		this.getTitle();
		this.setTitle("��������");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setBounds(100, 100, 500, 450);
		this.setVisible(true);
		
		
       //���������������� 
		textField = new JTextField();
		textField.setFont(new Font("Consolas", Font.PLAIN, 14));
		textField.setBounds(0, 0, 300, 35);
		this.getContentPane().add(textField);
		textField.setColumns(10);
		
		//������ť������
		search = new JButton("����");
		search.setBackground(new Color(192, 192, 192));
		search.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		search.setBounds(310, 0, 80, 30);
		this.getContentPane().add(search);
		
		//�����ť������
		clear=new JButton("���");
		clear.setBackground(new Color(192, 192, 192));
		clear.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		clear.setBounds(400, 0, 80, 30);
		this.getContentPane().add(clear);
		
		//��ʾ���ݵĴ����ʾ�������
		textArea = new JTextArea();
		textArea.setBounds(5, 200, 429, 500);

		JScrollPane scroll = new JScrollPane(textArea);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		textArea.setAutoscrolls(true);
		textArea.setLineWrap(true);
		scroll.setBounds(0, 48, 480, 350);
		textArea.setRows(5);
		this.setJMenuBar(bar);
		this.getContentPane().add(scroll);
		
		
		
		//search�ļ����¼������ú�clear�ļ����¼�������
		search.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String input = textField.getText();
				
				dr.Searchs(input,textArea);
			
			}
		});
		 clear.addActionListener(new ActionListener(){//��ť�¼���Ӧ�������
				public void actionPerformed(ActionEvent w) {
	
				dr.clearResults(textArea);
				textField.setText(null);
				}
			});
	}
}
