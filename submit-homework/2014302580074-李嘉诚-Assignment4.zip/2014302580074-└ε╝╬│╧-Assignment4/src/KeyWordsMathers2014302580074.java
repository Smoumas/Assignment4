/*���������������KeyWordsMather
 *�����һ��s
 *ǿ��֢�е㲻����
 */
import java.util.ArrayList;

public class KeyWordsMathers2014302580074
{
	private String keywords;
	private String[] noneSenseWords=new String[]{"the","to","this","that","there","I","of"};
	static final private ArrayList<Result2014302580074> searchResult=new ArrayList<Result2014302580074>();
	private getTeacherInfo2014302580074 info=new getTeacherInfo2014302580074();
	private ArrayList<ProfessorInfo2014302580074> list=info.read();
	public ArrayList<Result2014302580074> getSearchResult()
	{
		return searchResult;
	}
	public void calTF(String text)
	{
		for(ProfessorInfo2014302580074 pro:list)
		{
			Result2014302580074 result=new Result2014302580074();
			result.setPi(pro);
			searchResult.add(result);
		}
		for(int i=0;i<7;i++){
		text=text.replace(noneSenseWords[i]," ");
		}
		keywords=text;
		for(Result2014302580074 result:searchResult)
		{
			double value = 0;
			int count = 0;
			double tf;
			ProfessorInfo2014302580074 professorInfo=result.getInfo();
			String [] tempName=professorInfo.getName().split(" ");
			String [] tempEmail=professorInfo.getEmail().split(" ");
			String [] tempPhone=professorInfo.getPhone().split(" ");
			String [] tempResearchInterests= professorInfo.getResearchInterests().split(" ");
			String [] tempEducationBackground=professorInfo.getEducationBackground().split(" ");
			for(String temp:tempName)
			{
					if(temp.contains(keywords))
					{
						value+=1.5;
					}
				count++;
			}
			for(String temp:tempEmail)
			{
					if(temp.contains(keywords))
					{
						value+=1.0;
					}
				count++;
			}
			for(String temp:tempPhone)
			{
					if(temp.contains(keywords))
					{
						value+=1.0;
					}
				count++;
			}
			for(String temp:tempResearchInterests)
			{
					if(temp.contains(keywords))
					{
						value+=0.5;
					}
				count++;
			}
			for(String temp:tempEducationBackground)
			{
					if(temp.contains(keywords))
					{
						value+=0.5;
					}
				count++;
			}
			tf=value/count;
			result.setTf(tf);
		}
	}
	public ArrayList<Result2014302580074> Sort(ArrayList<Result2014302580074> search)
	{
		ArrayList<Result2014302580074> temp=new ArrayList<Result2014302580074>();
		Comparator comparator = new Comparator();
		for (int i = 0; i<search.size(); i++)
		 {
			 int max = 0;
			 double tf=search.get(i).getTf();
			 if(tf !=0.0)
			 {
				 for(int j=i+1;j<search.size();j++)
					{
						if(comparator.compare(search.get(i), search.get(j))==1)
						{
							max=i;
						}
						else
						{
							max=j;
						}
					}
				 temp.add(search.get(max)); 
			 }
		 }
		return temp;		
	}
	class Comparator
	{
		public int compare(Result2014302580074 searchResult1,Result2014302580074 searchResult2)
		{
			if(searchResult1.getTf()>=searchResult2.getTf())
				return 1;
			else
				return 0;
		}
		
	}

}
