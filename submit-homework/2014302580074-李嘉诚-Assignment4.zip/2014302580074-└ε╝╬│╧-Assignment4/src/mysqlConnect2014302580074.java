import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class mysqlConnect2014302580074 {
	public String url ;
	public String username; 
	public String password ; 
	public mysqlConnect2014302580074()
	{
		url ="jdbc:mysql://127.0.0.1:3306/my_schema";//localhost
		username = "root"; 
		password = "5078101823"; 
		//url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	}
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,username,password);
			//Connection conn=DriverManager.getConnection(url);
			//System.out.println("���������ɹ�");
	        return conn;
	}catch(ClassNotFoundException e)
	{
		//System.out.println("�Ҳ������������� ����������ʧ�ܣ�");   
	    e.printStackTrace() ; 
	    return null;
	}catch(SQLException e)
	{
		//System.out.println("MySQL��������");
        e.printStackTrace();
        return null;
	}
	}
}
