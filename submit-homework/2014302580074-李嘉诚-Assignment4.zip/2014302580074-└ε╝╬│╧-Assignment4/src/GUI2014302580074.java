/**
 _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                          ���汣��       ����BUG
*@author Vintony.Lee
*@version 1.2
*note��
*1�ڽ���nonesensewords�Ĵ����ϲ�������
*2�Ժ���ʱ���ٸ��
*3�������Ͽ��ļ�ģ�� ���绹Ҫȥ�˶��� 
*4(>_<)������java�β���ȥ�˶���
*/
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JScrollBar;

public class GUI2014302580074 extends JFrame { 
	private static final long serialVersionUID = 1;
	private JPanel contentPane;
	private JTextField textField;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI2014302580074 frame = new GUI2014302580074();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI2014302580074() {
		setTitle("Teacher Imformation Searcher V1.2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 665, 535);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final JTextArea textArea = new JTextArea();
		textArea.setBounds(1, 69, 609, 247);
		contentPane.add(textArea);
		textField = new JTextField();
		textField.setBounds(10, 437, 462, 49);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Start Search");
		btnNewButton.setBounds(503, 453, 125, 33);
		btnNewButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				KeyWordsMathers2014302580074 kw=new KeyWordsMathers2014302580074();
				String text=textField.getText().trim();
				kw.calTF(text);
				ArrayList<Result2014302580074> result=kw.Sort(kw.getSearchResult());
				for(int i=0;i<result.size();i++)
				{
					ProfessorInfo2014302580074 pi=result.get(i).getInfo();
				    textArea.setText(pi.getName()+pi.getEducationBackground()+pi.getResearchInterests()+pi.getEmail()+pi.getPhone());
				}
			}
		});
		contentPane.add(btnNewButton);
		
		JLabel lblTeacherImformationSearcher = new JLabel("Teacher Imformation Searcher");
		lblTeacherImformationSearcher.setBounds(127, 10, 445, 76);
		lblTeacherImformationSearcher.setFont(new Font("Segoe Script", Font.BOLD | Font.ITALIC, 21));
		contentPane.add(lblTeacherImformationSearcher);
		
		JLabel lblWriteYourKeywords = new JLabel("Write Your Keywords down there");
		lblWriteYourKeywords.setBounds(10, 400, 398, 27);
		lblWriteYourKeywords.setFont(new Font("Segoe UI Symbol", Font.BOLD, 15));
		lblWriteYourKeywords.setForeground(Color.RED);
		contentPane.add(lblWriteYourKeywords);
		
		scrollPane = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(0, 69, 628, 334);
		contentPane.add(scrollPane);
		
	}
}
