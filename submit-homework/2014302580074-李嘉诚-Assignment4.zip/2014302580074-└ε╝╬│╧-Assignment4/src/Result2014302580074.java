
public class Result2014302580074
{
	private ProfessorInfo2014302580074 tempInfo;
	private double tf;
	public void setPi(ProfessorInfo2014302580074 Info)
	{
		tempInfo=Info;
	}
	
	public void setTf(double tf)
	{
		this.tf=tf;
	}
	public ProfessorInfo2014302580074 getInfo()
	{
		return tempInfo;
	}
	public double getTf()
	{
		return tf;
	}
}
