public class ProfessorInfo2014302580074 {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;

	
	public ProfessorInfo2014302580074(String name,String educationBackground, String researchInterests,String email,String phone) 
	{
		super();
		this.name=name;
		this.email=email;
		this.phone=phone;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public void setPhone(String phone){
		this.phone = phone;
	}
	
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}

	public void setResearchInterests(String researchInterests){
		this.researchInterests = researchInterests;
	}
	
	public String getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}
	
	public String getEducationBackground() {
		return educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}
}
