import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class getTeacherInfo2014302580074 
{
	public ArrayList<ProfessorInfo2014302580074> read()
	{
		ArrayList<ProfessorInfo2014302580074> list=new ArrayList<ProfessorInfo2014302580074>();
		try 
		{
			mysqlConnect2014302580074 con=new mysqlConnect2014302580074();
			Connection connection = null;
			try {
				connection = con.getConnection();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			PreparedStatement ps= connection.prepareStatement("select * from 2014302580074_professor_info");//mysqlѡ�����
			ResultSet rs  =  ps.executeQuery();
			while(rs.next())
			{
			  ProfessorInfo2014302580074 data=null;
			  data = new ProfessorInfo2014302580074(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			  list.add(data);
			}
			
			connection.close();
			return list;
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}
}
