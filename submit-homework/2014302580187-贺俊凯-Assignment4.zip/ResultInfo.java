package assignment4;



//��ȡ�������
public class ResultInfo {

	private ProfessorInfo professorInfo;
	private double tf;
	
	public ResultInfo(ProfessorInfo professorInfo,double tf) {
		// TODO Auto-generated constructor stub
		setTf(tf);
		setProfessorInfo(professorInfo);
	}

	public ProfessorInfo getProfessorInfo() {
		return professorInfo;
	}

	public void setProfessorInfo(ProfessorInfo professorInfo) {
		this.professorInfo = professorInfo;
	}

	public double getTf() {
		return tf;
	}

	public void setTf(double tf) {
		this.tf = tf;
	}
}
