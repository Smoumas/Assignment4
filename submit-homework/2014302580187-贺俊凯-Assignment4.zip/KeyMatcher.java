package assignment4;

import java.util.ArrayList;

import javax.sound.midi.MidiDevice.Info;

public class KeyMatcher {
	public static ArrayList<ResultInfo> resultInfoList; //����������
	private String key;  //��������
	
	public KeyMatcher()
	{
		resultInfoList = new ArrayList<ResultInfo>();
	}
	
	public void SelectResult() //ɸѡ��Ϣ
	{
		for(int i=0;i<InfoReader.getProfessorInfoList().size();i++)
		{

			System.out.println(InfoReader.getProfessorInfoList().get(i).getName());
			System.out.println(InfoReader.getProfessorInfoList().get(i).calTF(key));
			if(InfoReader.getProfessorInfoList().get(i).calTF(key)>0) //�ж�TFֵ�Ƿ����0
			{
				Add2ResultInfoList(InfoReader.getProfessorInfoList().get(i),InfoReader.getProfessorInfoList().get(i).calTF(key));
				System.out.println("hey");
			}
		}
	}
	
	public void Add2ResultInfoList(ProfessorInfo professorInfo,double TF)  //�����ϵ����������������
	{
		resultInfoList.add(new ResultInfo(professorInfo, TF));
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void QuickSort(ArrayList<ResultInfo> ri,int p,int r)  //�����ݽ�������
	{
		 if(p<r)
			 {
			 int q = Partition(ri,p,r);
			 QuickSort(ri, q+1, r);
			 QuickSort(ri, p, q-1);
			 }
	}
	
	public int Partition(ArrayList<ResultInfo> ri,int p,int r)
	{
		int i = p-1;
		for(int j=p;j<r;j++)
		{
			if(ri.get(j).getTf()<ri.get(r).getTf())
		{
			i++;
			ResultInfo tmp = ri.get(j);
			ri.set(j, ri.get(i));
			ri.set(i, tmp);
		}
		}
		ResultInfo tmp = ri.get(r);
		ri.set(r, ri.get(i+1));
		ri.set(i+1, tmp);
		return i+1;
	}
	
}
