package assignment4;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.DropMode;

public class GUI extends JFrame {

	private JPanel contentPane;
	public static JScrollPane scrollPane;
	public static JTextField textField;
	public static JTextArea resultArea;
	public static InfoReader infoReader; 
	 /* Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(textField);
		textField.setColumns(30);
		
		JButton enterButton = new JButton("Enter");
		enterButton.addActionListener(new ButtonController());
		panel.add(enterButton);
		
		resultArea = new JTextArea();
		resultArea.setColumns(10);
		resultArea.setEditable(false);
		scrollPane = new JScrollPane(resultArea);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		infoReader = new InfoReader("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
	
	}

	public static void ShowResult()
	{
		for(ResultInfo resultInfo:KeyMatcher.resultInfoList)
		{
			String info = resultInfo.getProfessorInfo().GetInfo();
			System.out.println(info);
			resultArea.append(info);
		}
	}
}

class ButtonController implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		GUI.resultArea.setText(new String(""));
		KeyMatcher keyMatcher = new KeyMatcher();
		keyMatcher.setKey(GUI.textField.getText());
		keyMatcher.SelectResult();
		keyMatcher.QuickSort(keyMatcher.resultInfoList, 0,keyMatcher.resultInfoList.size()-1);
		GUI.ShowResult();
	}
	
}
