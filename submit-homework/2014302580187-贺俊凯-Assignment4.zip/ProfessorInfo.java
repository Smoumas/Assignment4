package assignment4;

import java.util.HashMap;
import java.util.Map;

import javax.print.attribute.standard.RequestingUserName;

public class ProfessorInfo {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private Map<String, String> contactInfo = new HashMap<String,String>();
    //private String email;
    //private String phone;
    
    
    public ProfessorInfo(String professorinfo[])
    {
    	setName(professorinfo[0]);
    	setEducationBackground(professorinfo[1]);
    	setResearchInterests(professorinfo[2]);
    	setContactInfo(professorinfo[3], professorinfo[4]);
    }
    
    public void setName(String name)
    {
    	this.name = name;
    }
	
	public void setEducationBackground(String educationBackground)
	{
		this.educationBackground = educationBackground;
	}
	
	public void setResearchInterests(String researchinterests)
	{
		this.researchInterests = researchinterests;
	}
	

	public String getName() {
		return name;
	}

	public String getEducationBackground() {
		return educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}


	public String getContactInfo() {
		String str = new String();
		for(String tmp : this.contactInfo.keySet())
		{
			str += tmp;
			str += "\n";
			str += this.contactInfo.get(tmp);
		}
		return str;
	}

	public void setContactInfo(String phone,String email) {
		this.contactInfo.put(phone, email);
	}

	public String GetInfo() //��ý���������Ϣ�������ӽ�textarea
	{
		String str = getName()+getEducationBackground()+getResearchInterests()+getContactInfo();
		return str;
	}

	//����TFֵ
	public double calTF(String key) {
		// TODO Auto-generated method stub
		double TF = 0;
		if(name.contains(key))
		{
			TF+=0.5;
		}
		if(educationBackground.contains(key))
		{
			TF+=0.4;
		}
		if(researchInterests.contains(key))
		{
			TF+=0.4;
		}
		if(contactInfo.containsKey(key))
		{
			TF+=0.2;
		}
		if(contactInfo.containsValue(key))
		{
			TF+=0.2;
		}
		return TF;
	}
	
	
}
