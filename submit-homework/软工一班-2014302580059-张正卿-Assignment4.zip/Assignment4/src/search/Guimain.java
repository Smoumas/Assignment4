package search;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.security.auth.callback.TextInputCallback;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Guimain{
	final static JFrame jf = new JFrame("Professor Searcher");
	final static Container jfCon = jf.getContentPane();
	final static JTextField textIn = new JTextField(40);
	final static JButton search = new JButton("search");
	final static JTextArea result = new JTextArea();
	final static JScrollPane resultPa = new JScrollPane(result);
	
	public static String keyWords;
	public static Read readWord = new Read();
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		readWord.read();
		
		jf.setLayout(null);
		jf.setBounds(0,0,400,300);

		textIn.setBounds(10,10,260,30);
		search.setBounds(290,10,80,30);
		resultPa.setBounds(10,50,360,200);
		
		jfCon.add(textIn);
		jfCon.add(search);
		jfCon.add(resultPa);
		
		search.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				keyWords = textIn.getText();
				new Search().run();
			}
		});
		
		jf.setVisible(true);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
}
