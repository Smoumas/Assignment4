package search;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Read extends Guimain {
	static final String USER = "root";
	static final String PASS = "123456";//Ϊ������˽��ȥ����
	static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/my_schema";
	public List<String> word = new ArrayList<String>();

	void read () throws ClassNotFoundException, SQLException{
		Connection conn = null;
		Statement stmt = null;
		
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(DB_URL,USER,PASS);//���ݿ�������ʼ��
		
        stmt = conn.createStatement(); //����Statement����

        String sql = "select * from professor_info";    //Ҫִ�е�SQL
        ResultSet rs = stmt.executeQuery(sql);//�������ݶ���
        
        while (rs.next()){
        	word.add(rs.getString(1)+rs.getString(2)+rs.getString(3)+rs.getString(4)+rs.getString(5));
        }

        rs.close();
        stmt.close();
        conn.close();
	}
}
