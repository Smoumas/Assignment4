package search;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search extends Read{
	private double temp3 = 0;
	private double temp1 = 0;
	private double temp2 = 0;
	private String temp4 = "";
	
	void run (){
		double[] tf = new double[readWord.word.size()];
		for(int i = 0;i<readWord.word.size();i++)
			tf[i] = 0;
		Pattern keyWordsPat = Pattern.compile("(?i)"+keyWords);
		for(int i = 0;i<readWord.word.size();i++){
			temp1 = 0;
			temp2 = 0;
			
			Matcher keyWordsMat = keyWordsPat.matcher(readWord.word.get(i));
			while(keyWordsMat.find()){
				temp1++;
			}
	        temp2 = readWord.word.get(i).split("\\s+").length;
	        tf[i] = temp1 / temp2;
		}
		for (int m = tf.length - 1;m>0;--m){
			for (int n = 0;n<m;++n){
				if(tf[n+1]<tf[n]){
					temp3 = tf[n];
					tf[n] = tf[n+1];
					tf[n+1] = temp3;
					temp4 = readWord.word.get(n);
					readWord.word.set(n,readWord.word.get(n+1));
					readWord.word.set(n+1,temp4);
				}
			}
		}
		result.setText("���������ʾ���\n"+ readWord.word.get(readWord.word.size()-1) + "\n_____________\n" + readWord.word.get(readWord.word.size()-2)+"\n_____________\n" + readWord.word.get(readWord.word.size()-3));
	}
}
