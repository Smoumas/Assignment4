-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: samp_db
-- ------------------------------------------------------
-- Server version	5.7.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `2014302580314_professor_info`
--

LOCK TABLES `2014302580314_professor_info` WRITE;
/*!40000 ALTER TABLE `2014302580314_professor_info` DISABLE KEYS */;
INSERT INTO `2014302580314_professor_info` VALUES (1,'Joseph Beck','Computer Science Learning Sciences and Technologies','josephbeck@wpi.edu','BS, Carnegie Mellon University PhD, University of Massachusetts, Amherst'),(2,'Dmitry Berenson','Computer Science Robotics Engineering','dberenson@wpi.edu','BS, Cornell University, 2005 MS, Carnegie Mellon University, 2009 PhD, Carnegie Mellon University, 2011'),(3,'David C. Brown','Computer Science Learning Sciences and Technologies Mechanical Engineering','dcb@wpi.edu','B.Sc. (Honors), 1st Class, Computer Science, North Staffordshire Polytechnic, 1970. M.Sc., Computing, University of Kent, 1975. M.S., Computer & Information Science, The Ohio State University,1977. Ph.D., Computer & Information Science, The Ohio State University, 1984.'),(4,'Sonia Chernova','Computer Science','soniac@wpi.edu','BS, Carnegie Mellon University, 2003 PhD, Carnegie Mellon University, 2009'),(5,'Michael A. Gennert','Robotics Engineering Computer Science Electrical & Computer Engineering','michaelg@wpi.edu','BS, CS, Massachusetts Institute of Technology, 1980 BS, EE, Massachusetts Institute of Technology, 1980 MS, EECS, Massachusetts Institute of Technology, 1980 PhD, EECS, Massachusetts Institute of Technology, 1987'),(6,'Neil T. Heffernan','Computer Science Interactive Media & Game Development Learning Sciences and Technologies','nth@wpi.edu','B.A., Amherst College, 1993 M.S., Carnegie Mellon University, 1998 Ph.D., Carnegie Mellon University, 2001'),(7,'Carolina Ruiz','Computer Science Bioinformatics and Computational Biology Data Science Learning Sciences and Technologies','ruiz@wpi.edu','BS, Computer Science, Universidad de Los Andes, 1988 BS, Mathematics, Universidad de Los Andes, 1989 MS, Computer Science, Universidad de Los Andes, 1990 Ph.D., Computer Science, University of Maryland College Park, 1996'),(8,'Charles Rich','Computer Science Interactive Media & Game Development Learning Sciences and Technologies Robotics Engineering','rich@wpi.edu','B.A.Sc., University of Toronto, 1973 S.M., Massachusetts Institute of Technology, 1975 Ph.D., Massachusetts Institute of Technology, 1980'),(9,'Candace L. Sidner','Computer Science Robotics Engineering','sidner@wpi.edu','B.A. Math, Kalamazoo College 1971 M.S. Computer Science, Univ of Pittsburgh, 1975 Ph.D. Computer Science, MIT, 1979'),(10,'David C. Brown','Computer Science Learning Sciences and Technologies Mechanical Engineering','dcb@wpi.edu','B.Sc. (Honors), 1st Class, Computer Science, North Staffordshire Polytechnic, 1970. M.Sc., Computing, University of Kent, 1975. M.S., Computer & Information Science, The Ohio State University,1977. Ph.D., Computer & Information Science, The Ohio State University, 1984.'),(11,'Daniel J. Dougherty','Computer Science Cybersecurity','dd@wpi.edu','BS University of Maryland 1974 PhD University of Maryland 1982'),(12,'Joshua D. Guttman','Computer Science Cybersecurity','guttman@wpi.edu','A.B., Princeton University, 1975 M.A., University of Chicago, 1976 Ph.D., University of Chicago, 1984'),(13,'Carolina Ruiz','Computer Science Bioinformatics and Computational Biology Data Science Learning Sciences and Technologies','ruiz@wpi.edu','BS, Computer Science, Universidad de Los Andes, 1988 BS, Mathematics, Universidad de Los Andes, 1989 MS, Computer Science, Universidad de Los Andes, 1990 Ph.D., Computer Science, University of Maryland College Park, 1996'),(14,'David C. Brown','Computer Science Learning Sciences and Technologies Mechanical Engineering','dcb@wpi.edu','B.Sc. (Honors), 1st Class, Computer Science, North Staffordshire Polytechnic, 1970. M.Sc., Computing, University of Kent, 1975. M.S., Computer & Information Science, The Ohio State University,1977. Ph.D., Computer & Information Science, The Ohio State University, 1984.'),(15,'Mark Claypool','Computer Science Interactive Media & Game Development','claypool@wpi.edu','BA, Mathematics, Colorado College MS, Computer Science, University of Minnesota PhD, Computer Science, University of Minnesota');
/*!40000 ALTER TABLE `2014302580314_professor_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-20  3:46:20
