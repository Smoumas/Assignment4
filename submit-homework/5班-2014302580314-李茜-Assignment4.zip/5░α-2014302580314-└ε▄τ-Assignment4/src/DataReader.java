import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DataReader {
	private static String jdbcDriver="";
	private static String dbUrl="";
	private static String user="";
	private static String pass="";
	private Connection conn=null;
	private Statement stmt=null;
	private ResultSet rs=null;
	private ArrayList<ProfessorInfo> ProfessorInfoList=new ArrayList<ProfessorInfo>();
	
	public DataReader(){
		jdbcDriver="com.mysql.jdbc.Driver";
		dbUrl="jdbc:mysql://127.0.0.1:3306/my_schema";
		user="root";
		pass="123456";
		try {
			getConnection();
			read();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void getConnection() throws ClassNotFoundException, SQLException{
		Class.forName(jdbcDriver);
		conn=DriverManager.getConnection(dbUrl,user,pass);
	}
	
	public ArrayList<ProfessorInfo> read() throws SQLException{
		stmt=conn.createStatement();
		String sql="select* from 2014302580314_professor_info";
		rs=stmt.executeQuery(sql);
		while(rs.next()){
			ProfessorInfo pi=new ProfessorInfo();
			pi.setName(rs.getString("name"));
			pi.setEmail(rs.getString("email"));
			pi.setField(rs.getString("field"));
			pi.setEducation(rs.getString("education"));
			ProfessorInfoList.add(pi);
		}
		return ProfessorInfoList;
	}

	public static void main(String[] args) {
		DataReader dr=new DataReader();
		ArrayList<ProfessorInfo> PIList=new ArrayList<ProfessorInfo>();
		try {
			PIList=dr.read();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(ProfessorInfo pi:PIList){
			System.out.println(pi.getName()+"\n"+pi.getEmail()+"\n"+
					pi.getField()+"\n"+pi.getEducation());
		}
	}

}
