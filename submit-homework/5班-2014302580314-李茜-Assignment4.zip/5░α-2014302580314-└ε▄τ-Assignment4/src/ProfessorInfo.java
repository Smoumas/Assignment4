
public class ProfessorInfo {
	private String name;
	private String field;
	private String email;
	private String education;
	
	public ProfessorInfo(){
	}
	
	public ProfessorInfo(String name, String field, String email,
			String education) {
		super();
		this.name = name;
		this.field = field;
		this.email = email;
		this.education = education;
	}

	public void setName(String name){
		this.name=name;
	}
	
	public String getName(){
		return name;
	}
	
	public void setEmail(String email){
		this.email=email;
	}
	
	public String getEmail(){
		return email;
	}
	
	public void setField(String field){
		this.field=field;
	}
	
	public String getField(){
		return field;
	}
	
	public void setEducation(String education){
		this.education=education;
	}
	
	public String getEducation(){
		return education;
	}

	public static void main(String[] args) {
		ProfessorInfo p1=new ProfessorInfo();
		p1.setName("sdddd");
		ProfessorInfo p2=new ProfessorInfo();
		p2.setField("woaizhangwenyang");
		ProfessorInfo a=p2;
		p2=p1;
		p1=a;
		System.out.println(p1.getName()+" "+p1.getField());
		System.out.println(p2.getName()+" "+p2.getField());
	}

}
