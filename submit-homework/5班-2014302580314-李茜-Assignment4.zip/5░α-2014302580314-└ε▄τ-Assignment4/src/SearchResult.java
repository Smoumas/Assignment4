
public class SearchResult {
	ProfessorInfo pi=new ProfessorInfo();
	double tf=0.0;

	public SearchResult(ProfessorInfo pi){
		this.pi=pi;
	}
	
	public SearchResult(ProfessorInfo pi, double tf) {
		super();
		this.pi = pi;
		this.tf = tf;
	}



	public void setProfessorInfo(ProfessorInfo pi){
		this.pi=pi;
	}
	
	public ProfessorInfo getProfessorInfo(){
		return pi;
	}
	
	public void setTf(double tf){
		this.tf=tf;
	}
	
	public double getTf(){
		return tf;
	}
	
	
	
	
	
	
	

	public static void main(String[] args) {
		
	}

}
