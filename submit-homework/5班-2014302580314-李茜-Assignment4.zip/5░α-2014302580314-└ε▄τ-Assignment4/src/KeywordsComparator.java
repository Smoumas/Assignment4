import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class KeywordsComparator{
	private List<SearchResult> SearchResultList=new ArrayList<SearchResult>();
	private List<String> keywords=new ArrayList<String>();
	
	public KeywordsComparator(String input){	
		setKeywords(input);
		fetchKeywords(input);
		calTf();
	}
	
	public KeywordsComparator(){
	}
	
	public void fetchKeywords(String input){
		DataReader dr=new DataReader();
		try {
			List<ProfessorInfo> pil=dr.read();
			for(ProfessorInfo pi:pil){
				String info=pi.getName()+pi.getEmail()+
						pi.getField()+pi.getEducation();
//				System.out.println(info);
				for(String i:keywords){
//					System.out.println(i);
					Pattern p=Pattern.compile(i);
					Matcher m=p.matcher(info);
					if(m.find()){
//						System.out.println("oh yeah");
						SearchResultList.add(new SearchResult(pi));
						break;
					}//end if
				}//end for
			}//end for
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void calTf(){
		double tf=0.0;
		int sum=0;
		for(SearchResult sr:SearchResultList){
			ProfessorInfo pi=sr.getProfessorInfo();
//			String name=pi.getName();
//			String email=pi.getEmail();
//			String field=pi.getField();
//			String education=pi.getEducation();
			for(String s:keywords){
				String[] nameA=InfoSplit(pi.getName());
				String[] emailA=InfoSplit(pi.getEmail());
				String[] fieldA=InfoSplit(pi.getField());
				String[] educationA=InfoSplit(pi.getEducation());
				for(int i=0;i<nameA.length;i++){
					if(s==nameA[i]){
						tf+=4;
						sum+=4;
					}else sum+=1;
				}
				for(int i=0;i<emailA.length;i++){
					if(s==emailA[i]){
						tf+=3;
						sum+=3;		
					}else sum+=1;
				}
				for(int i=0;i<fieldA.length;i++){
					if(s==fieldA[i]){
						tf+=2;
						sum+=2;
					}else sum+=1;
				}
				for(int i=0;i<educationA.length;i++){
					if(s==educationA[i]){
						tf+=1;
						sum+=1;
					}else sum+=1;
				}
			}
		tf/=sum;
		sr.setTf(tf);
		}
	}

	public List<SearchResult> sort(){
		//ð��
		for(int i=0;i<SearchResultList.size();i++){
			for(int j=i;j<SearchResultList.size()-1;j++){
				if(compare(SearchResultList.get(j),SearchResultList.get(j+1))==1){
					SearchResult a=SearchResultList.get(j);
					SearchResultList.set(j, SearchResultList.get(j+1));
					SearchResultList.set(j, a);
				}//end if
			}//end for
		}//end for
		return SearchResultList;
	}
	
	private int compare(SearchResult s1,SearchResult s2){
		if(s1.getTf()>s2.getTf()){
			return 1;
		}
		return 0;
	}
	
	private String[] InfoSplit(String text){
		Pattern p=Pattern.compile(" |,|@");
		String[] string=p.split(text);
		return string;
	}
	
	private List<String> setKeywords(String input){
		Pattern p=Pattern.compile(" ");
		String[] string=p.split(input);
		for(int i=0;i<string.length;i++){
			keywords.add(string[i]);
		}
		return keywords;
	}
	
	public static void main(String[] args){
		KeywordsComparator kc=new KeywordsComparator("Computer");
		String output="";
		List<SearchResult> srList=kc.sort();
		for(SearchResult sr:srList){
			ProfessorInfo pi=sr.getProfessorInfo();
			output+="Name:"+pi.getName()+"\nEmail:"+pi.getEmail()+"\nField:"+
			pi.getField()+"\nEducation:"+pi.getEducation()+"\n\n";
		}
		System.out.println(output);
	}
}
 