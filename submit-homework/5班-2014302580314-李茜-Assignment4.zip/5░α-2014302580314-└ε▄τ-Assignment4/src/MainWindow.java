import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;


public class MainWindow {
	private JFrame SEFrame;
	private JTextField textField;
	private JTextArea textArea;
	private JButton button;
	private JScrollPane scroll;
	private KeywordsComparator kc=new KeywordsComparator();
	private List<SearchResult> srList=new ArrayList<SearchResult>();
	private String input="";
	
	public MainWindow(){
		SEFrameIni();
		
	}
	
	private void SEFrameIni(){
		
		textFieldIni();
		textAreaIni();
		buttonIni();
		scrollIni();
		SEFrame=new JFrame("ProfessorInfo Seacher");
		SEFrame.add(textArea);
		SEFrame.add(textField);
		SEFrame.add(button);
		SEFrame.add(scroll);
		SEFrame.setVisible(true);
		SEFrame.setSize(650,550);
		SEFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SEFrame.setResizable(false);
		
	}
	
	private void textFieldIni(){
		textField=new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setLayout(null);
		textField.setVisible(true);
		textField.setBounds(20, 20, 300, 50);
		textField.getDocument().addDocumentListener(new DocumentListener(){
			@Override
			public void insertUpdate(DocumentEvent e) {
				try {
					input = e.getDocument().getText(e.getDocument().getStartPosition()
							.getOffset(), e.getDocument().getLength());
				} catch (BadLocationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			@Override
			public void removeUpdate(DocumentEvent e) {
			}
			@Override
			public void changedUpdate(DocumentEvent e) {
			}
		});
	}
	
	private void textAreaIni(){
		textArea=new JTextArea();
		textArea.setEditable(false);
		textArea.setLayout(null);
		textArea.setBounds(20, 100, 600, 400);
		textArea.setBackground(Color.pink);
		textArea.setVisible(true);
		textArea.setLineWrap(true);
		textArea.setFont(new Font("Dialog",0,15));	
	}
	
	private void buttonIni(){
		button=new JButton("Search");
		button.setLayout(null);
		button.setBounds(400, 20, 200, 50);
		button.setBackground(Color.CYAN);
		button.setVisible(true);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				kc=new KeywordsComparator(input);
				srList=kc.sort();
				
				String output="";
				
				for(SearchResult sr:srList){
					ProfessorInfo pi=sr.getProfessorInfo();
					output+="Name:"+pi.getName()+"\nEmail:"+pi.getEmail()+"\nField:"+
					pi.getField()+"\nEducation:"+pi.getEducation()+"\n\n";
				}
				textArea.setText(output);	
//				System.out.println(output+"oh no");
			}
		});
	}
	
	private void scrollIni(){
		scroll=new JScrollPane();
		scroll.setBounds(20, 100, 600, 400);
		scroll.setViewportView(textArea);
	}

	public static void main(String[] args) {
		MainWindow mw=new MainWindow();
//		System.out.println("end");

	}

}
