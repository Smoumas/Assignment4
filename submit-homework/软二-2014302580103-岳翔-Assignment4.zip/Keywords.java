
public class Keywords {
	private static String keywords;
	private static String stopwords[]={"a","the","of","to","at","in","an","on","this","that"};
	
	public static String getKeywords() {
		return keywords;
	}

	public static void setKeywords(String keywords) {
		
		Keywords.keywords = keywords;
		stopwordsOperation();
	}
	
	private static void stopwordsOperation()
	{
		for(int i=0;i<stopwords.length;i++)
		{
			keywords=keywords.replace(stopwords[i]," ");
		}
	}
	
}
