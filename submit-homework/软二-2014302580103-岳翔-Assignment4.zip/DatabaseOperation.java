import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DatabaseOperation {

	private final String DBDRIVER = "com.mysql.jdbc.Driver";// ���ݿ�����
	private final String DBURL = "jdbc:mysql://127.0.0.1:3306/my_schema?";// ��ַ
	private final String DBUSER = "root";// �˻���
	private final String DBPASS = "123456";// ����

	private Connection connection;
	private PreparedStatement pstmt;
	private String sql;
	private ResultSet rs;// ��ѯ���

	private String keywords;// �ؼ���
	private static int size;

	private ArrayList<String> name;// ��������
	private ArrayList<String> educationBackground;// ��������
	private ArrayList<String> researchInterests; // �о�����
	private ArrayList<String> email;// �ʼ�
	private ArrayList<String> phone;// �绰

	public DatabaseOperation() throws Exception {
		
		//��ʼ��
		name=new ArrayList<String>();
		educationBackground=new ArrayList<String>();
		researchInterests=new ArrayList<String>();
		email=new ArrayList<String>();
		phone=new ArrayList<String>();
		
		keywords = Keywords.getKeywords();
		connection = null;
		pstmt = null;
		sql = "SELECT * FROM 2014302580103_professor_info WHERE name LIKE ? OR educationBackground LIKE ? OR researchInterests LIKE ? OR email LIKE ? OR phone LIKE ?";

		DB_Select();
	}

	public void DB_Connector() throws Exception {
		Class.forName(DBDRIVER);// ������������
		connection = DriverManager.getConnection(DBURL, DBUSER, DBPASS);// �������ݿ�
		pstmt = connection.prepareStatement(sql);
	}

	/**
	 * @
	 * @throws Exception
	 */
	public void DB_Select() throws Exception {
		DB_Connector();

		pstmt.setString(1, "%" + keywords + "%");
		pstmt.setString(2, "%" + keywords + "%");
		pstmt.setString(3, "%" + keywords + "%");
		pstmt.setString(4, "%" + keywords + "%");
		pstmt.setString(5, "%" + keywords + "%");

		//System.out.println(pstmt);
		rs = pstmt.executeQuery();

		while (rs.next()) {

			name.add(rs.getString(1));
		//	System.out.println(name.get(0));
			educationBackground.add(rs.getString(2));
			researchInterests.add(rs.getString(3));
			email.add(rs.getString(4));
			phone.add(rs.getString(5));
		}

		size = name.size();

		TeacherInfo.setInfo(name, educationBackground, researchInterests,
				email, phone);
		TeacherInfo.matcherInfo();
		TeacherInfo.setTFOrder();
	}

	
	public static int getArrayBounds() {
		return size;
	}

}
