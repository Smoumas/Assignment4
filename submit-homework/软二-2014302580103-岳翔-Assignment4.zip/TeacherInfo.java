import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TeacherInfo {
	private static String info[];
	private static int size;
	private static String text;
	private static int TFNum[];// �ؼ��ʳ��ֵĸ���
	private static int wordsNum[];// �ܴ���
	private static float TF[];
	private static int index[];
	private static float TFbuffer[];

	public static void setInfo(ArrayList<String> name,
			ArrayList<String> educationBackground,
			ArrayList<String> researchInterests, ArrayList<String> email,
			ArrayList<String> phone) {

		size = DatabaseOperation.getArrayBounds();
		info = new String[size];
		TFNum = new int[size];
		wordsNum = new int[size];
		TF = new float[size];
		TFbuffer = new float[size];
		index = new int[size];

		for (int i = 0; i < size; i++) {
			String nameStr = "Name:" + name.get(i) + "\n";
			String educationBackgroundStr = "EducationBackground:"
					+ educationBackground.get(i) + "\n";
			String researchInterestsStr = "ResearchInterests:"
					+ researchInterests.get(i) + "\n";
			String emailStr = "Email:" + email.get(i) + "\n";
			String phoneStr = "Phone:" + phone.get(i) + "\n";
			info[i] = nameStr + educationBackgroundStr + researchInterestsStr
					+ emailStr + phoneStr;
		}
	}

	public static void matcherInfo() {

		for (int j = 0; j < size; j++) {
			TFNum[j] = 0;
			String str = info[j];
			String str2 = str.replaceAll(" |,|\\?|!|\\.", " ");
			Pattern pattern = Pattern.compile(Keywords.getKeywords(),
					Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(str2);

			while (matcher.find()) {
				TFNum[j]++;
			}
			
			//System.out.println(TFNum[j]);
			wordsNum[j] = str2.split("\\s+").length;
			TFbuffer[j] = (float) TFNum[j] / wordsNum[j];
			//System.out.println(TFbuffer[j]);
		}
	}

	public static void setTFOrder() {

		for (int i = 0; i < TFbuffer.length; i++) {
			float max = 0;
			for (int j = 0; j < TFbuffer.length; j++) {
				if (max <= TFbuffer[j]) {
					max = TFbuffer[j];
					index[i] = j;
				}
			}
			TF[i] = max;
			TFbuffer[index[i]] = 0;
		}
	}

	public static String getInfo() {
		for (int i = 0; i < size; i++) {
			String str = "�ؼ��ʳ��ִ�����" + TFNum[index[i]] + "\n�ܴ�����"
					+ wordsNum[index[i]] + "\nTFֵ��" + TF[index[i]] + "\n\n\n";
			info[index[i]] += str;
			text += info[index[i]];
		}
		return text;
	}

}
