
public class Main2014302580103 {
	public static void main(String[] args) throws Exception
	{
		GUI GUI=new GUI();
	}
}
