import java.util.ArrayList;
import java.sql.*;
public class DataReader {   
    private static ArrayList<String> teacher = new ArrayList<>();      
    public static ArrayList<String> getTeacher() throws Exception {
    	Class.forName("com.mysql.jdbc.Driver");   
    	String URL = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
    	Connection conn = DriverManager.getConnection(URL, "root", "123456");
        Statement stmt = conn.createStatement();
        String sql = "select name, educationBackground , researchInterests , email , phone from 2014302580104_professor_info";
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
			String professor=rs.getString("name")+"\n" +rs.getString("educationBackground")+
					"\n"+rs.getString("researchInterests")+"\n"+rs.getString("email")+
					"\n"+rs.getString("phone");
			teacher.add(professor);
		}
        return teacher;
    }
}