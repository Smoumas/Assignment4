
public class Teacher {
	public class Professor {
	    public String name;
	    public String educationBackground;
	    public String researchInterests;
	    public String email;
	    public String phone;
	    
	    public Professor(String name,String educationBackground,
	    		String researchInterests,String email,String phone){
	    	this.name = name;
	    	this.educationBackground = educationBackground;
	    	this.researchInterests = researchInterests;
	    	this.email = email;
	    	this.phone = phone;
	    }
	}
}
