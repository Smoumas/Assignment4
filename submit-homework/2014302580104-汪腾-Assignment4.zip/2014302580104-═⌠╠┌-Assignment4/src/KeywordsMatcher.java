import java.util.ArrayList;
import java.util.regex.*;

public class KeywordsMatcher {
	private ArrayList<String> teacher=new ArrayList<>();
	private ArrayList<String> keyTeacher=new ArrayList<>();
	private double[] tf;
	
	public double[] getTf(){
		return tf;
	}
	public ArrayList<String> getTeacher(){
		return teacher;
	}
	public void calTf(String keywords) throws Exception {
		teacher=DataReader.getTeacher();
		Pattern pattern=Pattern.compile("\\w+");
		double numKeywords;
		tf=new double[teacher.size()];
		for(int i=0; i < teacher.size(); i++) {
			numKeywords=0.0;
			Matcher matcher=pattern.matcher(teacher.get(i));
			while (matcher.find())
				keyTeacher.add(matcher.group());
			for (String t: keyTeacher)
				if (t.equalsIgnoreCase(keywords))
					numKeywords++;
			tf[i] = numKeywords/keyTeacher.size();
		}
	}
}
