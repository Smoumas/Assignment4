import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Main2014302580104 extends JFrame{
	public static void main(String[] args) throws Exception {
		new Main2014302580104().search();
	}
	public KeywordsMatcher keywordsmatcher;
	public void search() throws Exception{
		Container container = getContentPane();
		setTitle("Teacher Searcher");
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setSize(400,300);
		container.setLayout(new BorderLayout());
		
		JPanel jpanel1 = new JPanel(new BorderLayout());
		JPanel jpanel2 = new JPanel();
		final JTextField jtextfield = new JTextField(28);
		final JTextArea jtextarea = new JTextArea(12,35);
		jtextarea.setLineWrap(true);//�����Զ�����
		JScrollPane jsrollpane = new JScrollPane(jtextarea);
		JButton jbutton = new JButton("Search");
		jpanel1.add(jtextfield,BorderLayout.WEST);
		jpanel1.add(jbutton,BorderLayout.EAST);
		jpanel2.add(jsrollpane);
		container.add(jpanel1,BorderLayout.NORTH);	
		container.add(jpanel2,BorderLayout.SOUTH);
		keywordsmatcher = new KeywordsMatcher();
		setVisible(true);
		jbutton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String temp;
				try {
					keywordsmatcher.calTf(jtextfield.getText());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				for(int i = 0;i < keywordsmatcher.getTf().length;i++)
					for(int j = 0;j < keywordsmatcher.getTf().length;j++)
						if(keywordsmatcher.getTf()[i] > keywordsmatcher.getTf()[j]){
							temp = keywordsmatcher.getTeacher().get(i);
							keywordsmatcher.getTeacher().add(i,keywordsmatcher.getTeacher().get(j));
							keywordsmatcher.getTeacher().add(j,temp);
						}
				for(int i = 0;i < keywordsmatcher.getTf().length;i++)
					jtextarea.append("\r\n"+keywordsmatcher.getTeacher().get(i));
			}
		});
	}
}

