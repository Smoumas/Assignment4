/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50709
Source Host           : localhost:3306
Source Database       : testjdbc

Target Server Type    : MYSQL
Target Server Version : 50709
File Encoding         : 65001

Date: 2015-11-13 19:22:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for teachersinformation
-- ----------------------------
DROP TABLE IF EXISTS `teachersinformation`;
CREATE TABLE `teachersinformation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Research` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teachersinformation
-- ----------------------------
INSERT INTO `teachersinformation` VALUES ('1', 'Ruiz, Carolina', '+1-508-831-5640', 'ruiz@wpi.edu', 'Data Mining Machine Learning Artificial Intelligence Genomics Clinical Medicine');
INSERT INTO `teachersinformation` VALUES ('2', 'Rich, Charles', '+1-508-831-5945', 'rich@wpi.edu', 'Artificial intelligence Human-robot interaction Intelligent user interfaces Serious games');
INSERT INTO `teachersinformation` VALUES ('3', 'Sidner, Candace L.', '+1-508-831-6637', 'sidner@wpi.edu', 'Natural Language Processing AI Intelligent User Interfaces Collaboration Human Robot Interaction');
INSERT INTO `teachersinformation` VALUES ('4', 'Brown, David', '+1-508-831-5618', 'dcb@wpi.edu', 'AI in Design Human Computer Interaction Artificial Intelligence Intelligent Interfaces');
INSERT INTO `teachersinformation` VALUES ('5', 'Dougherty, Daniel', '+1-508-831-5621', 'dd@wpi.edu', 'Logic Security Software');
INSERT INTO `teachersinformation` VALUES ('6', 'Guttman, Joshua', '+1-508-831-6054', 'guttman@wpi.edu', 'Information Security Theoretical Computer Science Logic Formal Methods Programming Languages');
INSERT INTO `teachersinformation` VALUES ('7', 'Ruiz, Carolina', '+1-508-831-5640', 'ruiz@wpi.edu', 'Data Mining Machine Learning Artificial Intelligence Genomics Clinical Medicine');
INSERT INTO `teachersinformation` VALUES ('8', 'Brown, David', '+1-508-831-5618', 'dcb@wpi.edu', 'AI in Design Human Computer Interaction Artificial Intelligence Intelligent Interfaces');
INSERT INTO `teachersinformation` VALUES ('9', 'Claypool, Mark', '+1-508-831-5409', 'claypool@wpi.edu', 'Multimedia Networking Congestion Control Network Games');
