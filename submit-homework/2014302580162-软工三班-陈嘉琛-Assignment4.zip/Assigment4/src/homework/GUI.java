package homework;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class GUI extends JFrame {

	private JPanel contentPane;
	private  JTextField textField;
	private final Action action = new SwingAction();
	private GetDatabase gt;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		gt = new GetDatabase();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		textField = new JTextField();
		contentPane.add(textField, BorderLayout.NORTH);
		textField.setColumns(10);
		
		textArea = new JTextArea();
		contentPane.add(textArea, BorderLayout.CENTER);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.setAction(action);
		contentPane.add(btnNewButton, BorderLayout.SOUTH);
	}
	
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "search");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			String m = textField.getText();
			for(int i=0;i<9;i++){
				
				if(m.equals(gt.getName().get(i))){
					//System.out.println(gt.getName().get(i));
					//System.out.println(gt.getPhone().get(i));
					//System.out.println(gt.getEmail().get(i));
					//System.out.println(gt.getResearch().get(i));
					
					textArea.append(gt.getName().get(i)+"\r\n"+gt.getPhone().get(i)+"\r\n"+gt.getEmail().get(i)+"\r\n"+gt.getResearch().get(i));
				}
				if(m.equals(gt.getPhone().get(i))){
					textArea.append(gt.getName().get(i)+"\r\n"+gt.getPhone().get(i)+"\r\n"+gt.getEmail().get(i)+"\r\n"+gt.getResearch().get(i));
				}
				if(m.equals(gt.getEmail().get(i))){
					textArea.append(gt.getName().get(i)+"\r\n"+gt.getPhone().get(i)+"\r\n"+gt.getEmail().get(i)+"\r\n"+gt.getResearch().get(i));
				}
				if(m.equals(gt.getResearch().get(i))){
					textArea.append(gt.getName().get(i)+"\r\n"+gt.getPhone().get(i)+"\r\n"+gt.getEmail().get(i)+"\r\n"+gt.getResearch().get(i));
				}
			}
			
		}
	}
}
