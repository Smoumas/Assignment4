package homework;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GetDatabase {
	public static List<String> name; 
	public List<String> phone ;
	public List<String> email ;
	public List<String> research;
	private static Connection conn;
	public GetDatabase(){
		name = new ArrayList<String>(); 
		phone = new ArrayList<String>();
		email = new ArrayList<String>();
		research = new ArrayList<String>();
		linkDatabase();
		name = this.getName();
		phone = this.getPhone();
		email = this.getEmail();
		research = this.getResearch();
	}
	private static void linkDatabase(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public static  List<String> getName(){
		for(int i=1;i<10;i++){
			String sqlStr = "select ID,Name,Phone,Email,Research from teachersinformation where ID=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sqlStr);
				ps.setObject(1, i);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
				name.add(rs.getString(2));
				}
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		return name;
	}
	public List<String> getPhone(){
		for(int i=1;i<10;i++){
			String sqlStr = "select ID,Name,Phone,Email,Research from teachersinformation where ID=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sqlStr);
				ps.setObject(1, i);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
				phone.add(rs.getString(3));
				}
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		return phone;
	}
	public List<String> getEmail(){
		for(int i=1;i<10;i++){
			String sqlStr = "select ID,Name,Phone,Email,Research from teachersinformation where ID=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sqlStr);
				ps.setObject(1, i);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
				email.add(rs.getString(4));
				}
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		return email;
	}	
	public List<String> getResearch(){
		for(int i=1;i<10;i++){
			String sqlStr = "select ID,Name,Phone,Email,Research from teachersinformation where ID=?";
			PreparedStatement ps;
			try {
				ps = conn.prepareStatement(sqlStr);
				ps.setObject(1, i);
				ResultSet rs = ps.executeQuery();
				while(rs.next()){
				research.add(rs.getString(5));
				}
				rs.close();
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		return research;
	}
	
}





