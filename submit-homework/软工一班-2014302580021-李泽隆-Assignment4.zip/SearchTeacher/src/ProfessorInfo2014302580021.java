
public class ProfessorInfo2014302580021 {
	private String name;
	private String tel;
	private String email;
	private String educationBackground;
	private String researchInterests;
	public ProfessorInfo2014302580021(String name,String tel,String email,String educationBackground,String researchInterest){
		setName(name);
		setTel(tel);
		setEmail(email);
		setEducationBackground(educationBackground);
		setResearchInterests(researchInterest);
	}
	public String getName() {
		return name;
	}
	public String getTel() {
		return tel;
	}
	public String getEmail() {
		return email;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	private void setName(String name) {
		this.name = name;
	}
	private void setTel(String tel) {
		this.tel = tel;
	}
	private void setEmail(String email) {
		this.email = email;
	}
	private void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	private void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	
	
	
}
