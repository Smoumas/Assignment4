import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI2014302580021 {
	JFrame frame;
	JButton button;
	JTextField input;
	JTextArea out;
	public GUI2014302580021(){
		
		
		//��������Ŀ�
		Font font = new Font("Default",Font.PLAIN,30);
		
		input=new JTextField(1);
		input.setEditable(true);
		input.setSize(360,60);
		input.setLocation(20,20);
		input.setFont(font);
		
		
		out=new JTextArea();
		out.setLineWrap(true);
		out.setEditable(false);
		JScrollPane sp=new JScrollPane(out);
		sp.setLocation(20,100);
		sp.setSize(440,430);
		
		button=new JButton("����");
		button.setLocation(400,20);
		button.setSize(60,60);
		
		frame=new JFrame("��������");
		frame.setSize(500, 600);
		frame.setLocation(500,200);
		frame.add(button);
		frame.add(sp);
		frame.add(input);
		frame.setLayout(null);
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		//������
		KeyWordMatcher2014302580021 matcher=new KeyWordMatcher2014302580021();
		button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
        		action(matcher);
        		
            }
        });
		input.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					action(matcher);
				}
			}
			
			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	public void action(KeyWordMatcher2014302580021 matcher){
		matcher.calTF(input.getText());
		matcher.sort();
		out.setText("��"+input.getText()+"�����������\n");
		input.setText("");
		for(SearchResult2014302580021 s:matcher.searchResultList){
			
			out.append("Name:\n"+s.getPi().getName()+"\n");
			out.append("Phone:\n"+s.getPi().getTel()+"\n");
			out.append("Email:\n"+s.getPi().getEmail()+"\n");
			out.append("Education background:\n"+s.getPi().getEducationBackground()+"\n");
			out.append("Research interest:\n"+s.getPi().getResearchInterests()+"\n");
			out.append("*************�����ķָ���************\n");
			
			
		}
		out.append("�������");
		out.setText(out.getText());//ʹ��������������
		out.setCaretPosition(0);//���ù������ǰ��
		
	}
	
	public static void main(String []args){
		new GUI2014302580021();
	}

}
