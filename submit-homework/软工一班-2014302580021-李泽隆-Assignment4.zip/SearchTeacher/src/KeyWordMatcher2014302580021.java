import java.awt.DisplayMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



public class KeyWordMatcher2014302580021 {
	ArrayList<SearchResult2014302580021> searchResultList;//���
	ArrayList<ProfessorInfo2014302580021> professorInfoList;//���ڵ���Ϣ
	String[]stopWords={"of","in","on","that"};
	public KeyWordMatcher2014302580021(){
	professorInfoList=new DataReader2014302580021().getList();//�ѽ��ڵ���Ϣȫ��������
	}


	private  String[] cutWord(String str){
		String[]s=str.split("\\W+");
		return s;
	}
	public void calTF(String keyWord)
	{
		searchResultList=new ArrayList<SearchResult2014302580021>();
		for(ProfessorInfo2014302580021 p:professorInfoList){
			double tf=0;
			tf+=tf(keyWord,p.getName());
			tf+=tf(keyWord,p.getEmail());
			tf+=tf(keyWord,p.getEducationBackground());
			tf+=tf(keyWord,p.getResearchInterests());
			tf+=tf(keyWord,p.getTel());
			if(tf!=0){
				searchResultList.add(new SearchResult2014302580021(p, tf));
			}
		}
		
		
	}

	
	private double tf(String keyWord,String List) {//�����Ǵ�һ�������м���tfֵ
		if(keyWord.equals(List)){
			return 1;
		}
		String[] keyWordList = cutWord(keyWord);// ��ȡ�ؼ���
		String[] nameList = cutWord(List);//�Ƕλ�
		int sameWord = 0;
		a:
		for (String s : keyWordList) {// �������еĹؼ���
			for (String stopWord : stopWords) {
				if (s.equals(stopWord)) {
					break a;
				}
			}
			for (String k : nameList) {// �Թؼ���Ϊ���������б�
				if (s.equals(k)) {
					sameWord++;
				}

			}
		}
		if(nameList.length==0){
			return 0;
		}
		double tf=(double)sameWord/nameList.length;
		return tf;
		
	}
	
	public void sort(){
		searchResultList.sort(new Comparator<SearchResult2014302580021>(){ 
			public int compare(SearchResult2014302580021 o1, SearchResult2014302580021 o2) {
				if(o1.getTf()<o2.getTf()){
					return 1;	
				}
				return -1;
			}
			});//�������෴��������������= =	
	}
}
