import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataReader2014302580021 {
	public static final String url="jdbc:mysql://127.0.0.1:3306/my_schema?characterEncoding=UTF-8";//����,ͬʱ��������Ϊutf8
	public static final String driver = "com.mysql.jdbc.Driver";//���ڼ�������  
	public static final String user = "root";  //�û���
	public static final String password = "123456";  //����
	public static final String tableName = "professor_info";
	private ArrayList<ProfessorInfo2014302580021> infoList; 
	
	
	
	public DataReader2014302580021()
	{
		infoList=new ArrayList<ProfessorInfo2014302580021>();
		Connection connection = null;
		Statement statement;
		ResultSet result;
		try {
			Class.forName(driver);//��������
			connection = DriverManager.getConnection(url, user, password);
			statement = connection.createStatement();//����
			result=statement.executeQuery("select * from "+tableName);//��ȡ�����
			while (result.next()) {
				String name=result.getString("name");
				String educationBackground=result.getString("educationBackground");
				String researchInterest=result.getString("researchInterests");
				String email=result.getString("email");
				String tel=result.getString("phone");
				infoList.add(new ProfessorInfo2014302580021(name, tel, email, educationBackground, researchInterest));	
				
			}

                
		} catch (ClassNotFoundException e) {				
			System.out.println("�������ݿ�����ʧ��");
			e.printStackTrace();
		} catch (SQLException e) {				
			System.out.println("�������ݿ�ʧ��");
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<ProfessorInfo2014302580021> getList(){
		return infoList;
	}

}