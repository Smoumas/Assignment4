
public class SearchResult2014302580021 {
	private ProfessorInfo2014302580021 pi;
	private double tf;
	public SearchResult2014302580021(ProfessorInfo2014302580021 pi,double tf){
		this.pi=pi;
		this.tf=tf;
	}
	public ProfessorInfo2014302580021 getPi() {
		return pi;
	}
	public void setPi(ProfessorInfo2014302580021 pi) {
		this.pi = pi;
	}
	public double getTf() {
		return tf;
	}
	public void setTf(double tf) {
		this.tf = tf;
	}

}
