import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JTextField;


public class UI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton search;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UI frame = new UI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UI() {
		setDataBase s = new setDataBase();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			}
		});
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextField textArea = new JTextField();
		textArea.setBounds(5, 13, 201, 32);
		contentPane.add(textArea);
		
		String input = null;
		search = new JButton("����");
		search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					s.match(input);
				} catch (InstantiationException | IllegalAccessException
						| ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
			}
		});
		search.setBounds(241, 13, 88, 32);
		contentPane.add(search);
		
		JTextField textPane = new JTextField();
		textPane.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 TFmatcher a = new TFmatcher();
				  a.splitWord();
				  a.countWordFreq();
				  a.sort();
				  a.printResult();
			}
		});
		textPane.setBounds(5, 58, 413, 182);
		contentPane.add(textPane);
	}
}
