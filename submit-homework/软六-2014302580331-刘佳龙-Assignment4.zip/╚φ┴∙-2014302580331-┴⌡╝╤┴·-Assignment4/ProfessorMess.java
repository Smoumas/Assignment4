//import java.io.File;
//import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
//import java.util.LinkedList;
public class ProfessorMess {
	
	public void getTableNameByCon(Connection con) {  
		   try {  
		   DatabaseMetaData meta = con.getMetaData();  
		   ResultSet rs = meta.getTables(null, null, null,  
		     new String[] { "TABLE" });  
		   while (rs.next()) {  
		     System.out.println( rs.getString(3));  
		     System.out.println( rs.getString(2));  
		   }  
		   con.close();  
		   } catch (Exception e) {  
		   try {  
		     con.close();  
		   } catch (SQLException e1) {  
		     // TODO Auto-generated catch block  
		     e1.printStackTrace();  
		   }  
		   // TODO Auto-generated catch block  
		   e.printStackTrace();  
		   }  
		}
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {   
		Class.forName("com.mysql.jdbc.Driver").newInstance();   
		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=qwemnb5885860");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Object request = null;
		try {
			ResultSet rs=stmt.executeQuery("select * from tb_Userinfo where usrName='"+((Object) request));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
        //����û��ָ�����ݿ�   
        String url = "jdbc:mysql://127.0.0.1:3306/";   
        String user = "root";   
        String pass = "";   
        try {   
  
            Class.forName("com.mysql.jdbc.Driver").newInstance();   
            Connection conn1 = DriverManager.getConnection(url, user, pass);   
            DatabaseMetaData metadata = conn1.getMetaData();   
            System.out.println();   
            System.out.println("���ݿ���ʹ�õı�����");   
            ResultSet rs1 = metadata.getTableTypes();   
            while (rs1.next()) {   
                System.out.println(rs1.getString(1));   
            }   
            rs1.close();   
               
            System.out.println();   
            
           
          //  ResultSet rs1 = metadata.getTables("ssi2bbs", null, null, null);   
            while (rs1.next()) {   
                System.out.println();   
                System.out.println(rs1.getString(1));   
                System.out.println(rs1.getString(3));   
                System.out.println(rs1.getString(4));   
            }   
            rs1.close();   

           
            ResultSet rs2 = metadata.getPrimaryKeys("mysql", null, "db");   
            while (rs2.next()) {   
                System.out.println(rs2.getString(4));   
            }   
            rs2.close();   
               
            System.out.println();   
            ResultSet rs3 = metadata.getIndexInfo("ssi2bbs", null, "user", false, true);   
            while (rs3.next()) {   
            	for(int i=1;i<=13;i++){
            		System.out.println(rs3.getString(i));//1~13
            	}
            }   
            rs3.close();   
        } catch (Exception e){   
            e.printStackTrace();   
        }   
    } 
}
