//import java.sql.DatabaseMetaData;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Connection;
//import java.sql.Statement;
//import java.util.LinkedList;

public class setDataBase{
	public void match(String s) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		ProfessorMess rs3 = new ProfessorMess();
		if (s.equals(rs3)) {
			System.out.println(rs3);
		}
	}
}