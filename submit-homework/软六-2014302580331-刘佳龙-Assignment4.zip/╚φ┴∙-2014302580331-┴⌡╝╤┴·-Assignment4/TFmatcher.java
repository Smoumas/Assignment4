import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

//import new TFmatcher(){}.Word;

public class TFmatcher {  //��������Article
	 String content; 
	 String[] rawWords;  //���浥�����ʼ���
	 String[] words;  //����������ʶ�Ӧ�Ĵ�Ƶ
	 int[] wordFreqs; //����
	 public TFmatcher() {
	  content = "Trusted Computer System (Trusted Computer System) of the U.S. Department ";
	 }

  
	public void splitWord(){   //�����¸��ݷָ������зִ�,��������浽rawWords������
	  final char SPACE = ' ';  //�ִʵ�ʱ�����еķ���ȫ���滻Ϊ�ո�
	  content = content.replace('\'', SPACE).replace(',', SPACE).replace('.', SPACE);
	  content = content.replace('(', SPACE).replace(')', SPACE).replace('-', SPACE);
	  rawWords = content.split("\\s+");  //���ǿո�����Ķ��㵥��
	 }

	 public void countWordFreq() {  //ͳ�Ƶ��ʸ���
	 Set<String> set = new TreeSet<String>();  //�����г��ֵ��ַ�������Ψһ��set��
	  for(String word: rawWords){
	   set.add(word);
	  }
  Iterator<String> ite = set.iterator();

  List<String> wordsList = new ArrayList<String>();  //���ٿռ亯��
  List<Integer> freqList = new ArrayList<Integer>();
  
  while(ite.hasNext()){
   String word = (String) ite.next();
   
   int count = 0;   //ͳ����ͬ�ַ����ĸ���
	   for(String str: rawWords){
	    if(str.equals(word)){
	     count++;
	    }
   }
   
	   wordsList.add(word);
	   freqList.add(count++);
  }
  

	  words = wordsList.toArray(new String[0]);  //�������鵱��
	  wordFreqs = new int[freqList.size()];
	  for(int i = 0; i < freqList.size(); i++){
	   wordFreqs[i] = freqList.get(i);
	  }
  
 }


 @SuppressWarnings("unchecked")
 	public void sort() {   //��������
  
class Word{    //����
   private String word;
   private int freq;
   
   public Word(String word, int freq){
	    this.word = word;
	    this.freq = freq;
   	}
}
  
  @SuppressWarnings("rawtypes")
class WordComparator implements Comparator{

	  public int compare(Object o1, Object o2) {
	    Word word1 = (Word) o1;
	    Word word2 = (Word) o2;
	    
	    if(word1.freq < word2.freq){
	     return 1;
	    }else if(word1.freq > word2.freq){
	     return -1;
	    }else{
	     
	     int len1 = word1.word.trim().length();
	     int len2 = word2.word.trim().length();
	     
	     String min = len1 > len2? word2.word: word1.word;
	     String max = len1 > len2? word1.word: word2.word;
	     
	     for(int i = 0; i < min.length(); i++){
		      if(min.charAt(i) < max.charAt(i)){
		       return 1;
		      }
	     }
	     
	     return 1;
	     
	    	}
	   	}
	   
	  }
	  
	  List<Word> wordList = new ArrayList<Word>();
	  
	  for(int i = 0; i < words.length; i++){
		  wordList.add(new Word(words[i], wordFreqs[i]));
	  }
	  
	  Collections.sort(wordList, new WordComparator());
	  
	  for(int i = 0; i < wordList.size(); i++){
		  Word wor = (Word) wordList.get(i);
	   
		  words[i] = wor.word;
		  wordFreqs[i] = wor.freq;
	  	}
	  
	 }
	
	 public void printResult() {  //�����������
		 System.out.println("Total " + words.length + " different words in the content!");
	
		 for(int i = 0; i < 3; i++){
			 System.out.println(wordFreqs[i] + "  " + words[i]);
		 }
	 }
}


