package com.jyz.assignment4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search {
	static ArrayList<String> listName = new ArrayList<String>();
	static ArrayList<String> listEma = new ArrayList<String>();
	static ArrayList<String> listInt = new ArrayList<String>();
	private ResultSet re;
	private int[] index;
	ArrayList<Integer> a=new ArrayList<>();
	
	public  void tf(ArrayList<Integer> a){
		// 需要记录下标的数组b
		index = new int[a.size()];
		// 初始化下标
		for (int i = 0; i < index.length; i++) {
		   index[i] = i;
		  }

		// 用冒泡法排序
		for (int i = 0; i < a.size(); i++) {
		   for (int j = i; j < a.size(); j++) {
		    if (a.get(i) < a.get(j)) {
		     int temp = a.get(i);
		     a.set(i, a.get(j));
		     a.set(j, temp);

		// 下标排序
		 int tempindex = index[i];
		     index[i] = index[j];
		     index[j] = tempindex;
		    }
		   }
		  }
		
	}
	public void getList(String text){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			Statement sta=con.createStatement();
			String sql = "select * from 2014302580333_professor_info where name like '%" +text+"%' or email like '%"+text+"%' or intro like '%"+text+"'";
			re = sta.executeQuery(sql);
			while (re.next()) {
				listName.add(re.getString("name"));
				listEma.add(re.getString("email"));
				listInt.add(re.getString("intro"));
				String string = re.getString("name")+" "+re.getString("email")+" "+re.getString("intro");
				Pattern pattern = Pattern.compile(".*("+text+").*");
				Matcher matcher = pattern.matcher(string);
				if (matcher.find()) {
					a.add(matcher.groupCount());
				}
				
			}
			
			for(int i=0;i<listName.size();i++){
						Main.ta.append(listName.get(i)+"\r\n");
						Main.ta.append(listEma.get(i)+"\r\n");
						Main.ta.append(listInt.get(i)+"\r\n");
						Main.ta.append("\r\n");
				
			}

			
		} catch (ClassNotFoundException e) {
			Main.ta.append(e.getMessage());
		} catch (SQLException e) {
			Main.ta.append(e.getMessage());
		}	
		
	}
	
}



