package com.jyz.assignment4;

import java.awt.Container;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class Main extends JFrame{
	public static JTextArea ta=new JTextArea();
	private JButton jb;
	private JTextField jt;
	private JScrollPane js;
	public Main(){
		//界面布局
		setTitle("Search Engine");
		Container c=getContentPane();
		c.setLayout(null);
		jt=new JTextField();
		jt.setBounds(5, 5, 745, 50);
		jb=new JButton("搜索");
		jb.setBounds(750, 5, 50, 50);
		ta.setLineWrap(true);
		ta.setBounds(5, 58, 790, 512);
		js = new JScrollPane(ta);
		js.setBounds(5, 58, 790, 512);
		
		
		
		//搜索操作
		jb.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ta.setText("");
						String text=jt.getText();
						jt.setText("");
						if(text.isEmpty()){
							ta.append("请输入关键字");
						}
						else{
							Search search=new Search();
							search.getList(text);
						}
						
						
						}
					});
		
		
		c.add(jt);
		c.add(jb);
		c.add(js);
		
		setBounds(0, 0, 800, 600);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args){
		new Main();
	}

}
