import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class GUI2014302580386 {
	
	JTextField jt = new JTextField();
	JTextArea ta = new JTextArea();
	
	public void CreatGUI(String title){
		JFrame jf = new JFrame();
		Container c = jf.getContentPane();
		jf.setBounds(200, 20, 400, 600);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		c.setLayout(null);
		
		
		jt.setBounds(20,20,220,60);
		jt.setVisible(true);
		c.add(jt);
		
		
		JButton b = new JButton();
		b.setBounds(280,20,100,60);
		b.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String keyword = jt.getText();
				String[] keywords=keyword.split("//s");
				ta.append("");
			}
		});
		c.add(b);
		
		
		JScrollPane sp = new JScrollPane(ta);
		sp.setVisible(true);
		sp.setBounds(20,120,360,460);
		c.add(sp);
		
	}
	
	public static void main(String args[]){
		 new GUI2014302580386().CreatGUI("search");
	}
}