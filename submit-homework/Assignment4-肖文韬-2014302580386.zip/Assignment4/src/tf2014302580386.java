import java.util.ArrayList;


public class tf2014302580386 {
	private double tf;
	
	ArrayList<teacher2014302580386> tempInfoList=database.read();
	
	
	
	public void calculatetf(){
		
		
	}

}
