
public class teacher2014302580386 {
	public String name;
	public String educationbackgounds;
	public String researchInterests;
	public String email;
	public String phone;
	teacher2014302580386(String n,String eb,String ri,String e,String p){
		name = n;
		educationbackgounds = eb;
		researchInterests = ri;
		email = e;
		phone = p;
	}

}
