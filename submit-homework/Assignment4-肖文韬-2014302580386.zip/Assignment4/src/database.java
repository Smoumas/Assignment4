
import java.sql.*;
import java.util.ArrayList;
public class database {
	static Connection con;
	static Statement sql;
	static ResultSet res;
	
	//���ӵ����ݿ�
	public Connection getConnection(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("���ݿ��������سɹ�");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/assignment3","root","1423");
			System.out.println("���ݿ����ӳɹ�");
		}catch(SQLException e){
			e.printStackTrace();
		}
		return con;
	}
	public static ArrayList<teacher2014302580386> read(){
		database c = new database();
		con = c.getConnection();
		ArrayList<teacher2014302580386> l=new ArrayList<teacher2014302580386>();
		try{
			sql = con.createStatement();
			res = sql.executeQuery("select*from 2014302580386_professor_info");
			
			while(res.next()){
				String s1 = res.getString(1);
				String s2 = res.getString(2);
				String s3 = res.getString(3);
				String s4 = res.getString(4);
				String s5 = res.getString(5);
				teacher2014302580386 t=new teacher2014302580386(s1,s2,s3,s4,s5);
				l.add(t);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return l;
	}
}