package se;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class KeywordsMatcher {
	//��ѯ���
	String sql = "select * from 2014302580196_professor_info";
	DataReader dr = new DataReader();
	
	ArrayList<String> keywords = new ArrayList<String>();
	ArrayList<String> searchResultList;
	String[] stopWords = {"of","and"};//�ǹؼ���
	
	public ArrayList<String> fetchKeywords(String text) {
		String[] strings = text.split(" ");//�Կո�ֽ�����õĹؼ���
		for(String str:strings) {//���ؼ��ִ���
			keywords.add(str);
		}
		
		//�޳��ǹؼ���
		Iterator<String> it = keywords.iterator();
		while(it.hasNext()) {
			String str = it.next();
			if(str.equals(stopWords[0])) {
				it.remove();
			}
			if(str.equals(stopWords[1])) {
				it.remove();
			}
		}
		return keywords;
	}
	
	public ArrayList<SearchResult> countTF() {
		ArrayList<SearchResult> result = new ArrayList<SearchResult>();
		SearchResult sr;
		for(ProfessorInfo pInfo:dr.read(sql)) {
			double tf = 0;
			
			//ƥ��ؼ��֣����Ҹ�����TFֵ
			for(String str:keywords) {
				//ȫ��ת��ΪСд����ƥ��
				if((pInfo.getName().toLowerCase()).equals(str.toLowerCase())) {
					tf += 2;
				}
				if((pInfo.getName().toLowerCase()).contains(str.toLowerCase())) {
					tf +=0.5;
				}
				if((pInfo.getEmail().toLowerCase()).equals(str.toLowerCase())) {
					tf += 2;
				}
				if((pInfo.getEmail().toLowerCase()).contains(str.toLowerCase())) {
					tf += 0.5;
				}
				if((pInfo.getPhone().toLowerCase()).equals(str.toLowerCase())) {
					tf += 2;
				}
				if((pInfo.getPhone().toLowerCase()).contains(str.toLowerCase())) {
					tf += 0.5;
				}
				//�жϱ����������Ƿ�����ؼ���
				int flag = 0;
				int index = 0;
				while(flag != -1) {
					flag = (pInfo.getEducationBackground().toLowerCase()).indexOf(str.toLowerCase(),index);
					if(flag != -1) {
						tf += 1;
						index = flag + 1;
					}
				}
				//�ж��о���Ȥ���Ƿ�����ؼ���
				int flag2 = 0;
				int index2 = 0;
				while(flag2 != -1) {
					flag2 = (pInfo.getResearchInterests().toLowerCase()).indexOf(str.toLowerCase(),index2);
					if(flag2 != -1) {
						tf += 1;
						index2 = flag2 + 1;
					}
				}
			}
			//��ƥ��������
			if(tf>0) {
				sr = new SearchResult(pInfo, tf);
				result.add(sr);
			}
		}
		return result;
	}
	//�Խ����������
	public ArrayList<SearchResult> sort(ArrayList<SearchResult> sr) {
		Collections.sort(sr);
		return sr;
	}
}
