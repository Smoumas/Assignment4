package se;

public class SearchResult implements Comparable<SearchResult>{
	
	private ProfessorInfo proInfo;
	private double tfValue;
	
	SearchResult(ProfessorInfo proInfo) {
		this.proInfo = proInfo;
	}
	SearchResult(ProfessorInfo proInfo,double tfValue) {
		this.proInfo = proInfo;
		this.tfValue = tfValue;
	}
	
	public ProfessorInfo getProInfo() {
		return proInfo;
	}
	public void setProInfo(ProfessorInfo proInfo) {
		this.proInfo = proInfo;
	}
	public double getTfValue() {
		return tfValue;
	}
	public void setTfValue(double tfValue) {
		this.tfValue = tfValue;
	}
	@Override
	public int compareTo(SearchResult o) {
		if(this.tfValue == o.tfValue) {
			return this.proInfo.compareTo(o.proInfo);
		}else {
			return -Double.valueOf(this.tfValue).compareTo(Double.valueOf(o.tfValue));
		}
	}
	@Override
	public String toString() {
		return  proInfo.toString();
	}
}
