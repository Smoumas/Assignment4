package se;

//ʵ��Comparable�ӿڷ�������
public class ProfessorInfo implements Comparable<ProfessorInfo>{
	
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String phone;
	private String email;
	
	public ProfessorInfo(String name,String educationBackground,
			String researchInterests,String email,String phone) {
		this.name = name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.email = email;
		this.phone = phone;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	public String getEmail() {
		return email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//��дcomparaTo�������Ա�����
	@Override
	public int compareTo(ProfessorInfo o) {
		if(this.name == o.name) {
			return this.email.compareTo(o.email);
		}
		else {
			return this.name.compareTo(o.name);
		}
	}

	//��дtoString�����Ա��ӡ
	@Override
	public String toString() {
		return "name��" + name + "\neducationBackground��"
				+ educationBackground + "\nresearchInterests��"
				+ researchInterests + "phone��" + phone + "\nemail��" + email+"\n\n";
	}

}
