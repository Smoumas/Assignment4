package se;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MainWindow {
	
	private JFrame myFrame;
	private static JTextArea myTextArea;
	private JTextField myText;
	private JScrollPane mySP;
	private JButton myBn;
	private static String text;
	
	public MainWindow() {
		
		myFrame = new JFrame("My Search Engine");
		myTextArea = new JTextArea();
		myText = new JTextField();
		mySP = new JScrollPane(myTextArea);
		myBn = new JButton("Search");
		text = "";
	}
	
	//��ʼ������
	private void initialize() {
		
		myText.setLocation(10, 10);
		myText.setSize(350, 30);
		myBn.setLocation(370, 10);
		myBn.setSize(110, 30);
		mySP.setLocation(10, 50);
		mySP.setSize(475,315);
		
		myFrame.setLayout(null);
		myFrame.setBounds(200,100,500,400);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		myFrame.setResizable(false);
		myFrame.add(mySP);
		myFrame.add(myBn);
		myFrame.add(myText);
		
		myFrame.setVisible(true);
		
		myEvent();
	}
	
	//�󶨰�ť�¼�
	private void myEvent() {
		myBn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				myTextArea.setText("");
				text = myText.getText();
			}
			
		});
	}
	
	public static void main(String[] args) {
		//���ú�����ʼ������  

		MainWindow m = new MainWindow();
		m.initialize();
		
		while(true) {
			KeywordsMatcher km = new KeywordsMatcher();
			String key = "";
			text ="";
			while(key == "") {
				key = text;
			}
			//��ȡ�������ؼ���
			km.fetchKeywords(key);
			//����TFֵ��ý������Ȼ��ŵ��ı���
			for(SearchResult sr:km.sort(km.countTF())) {
				myTextArea.append(sr.toString());
			}
		}
	}
}
