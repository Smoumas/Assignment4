package se;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class DataReader {
	
	//String url = "jdbc:mysql://localhost:3306/myfirst?user=root&password=mysql";
	String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	
	private Connection getConnection(String url) {
		String driver = "com.mysql.jdbc.Driver";
		Connection connection = null;
		
		try {
			Class.forName(driver);
			
			connection = (Connection) DriverManager.getConnection(url);
			
		} catch (ClassNotFoundException e) {
			System.err.println("װ�� JDBC/ODBC ��������ʧ�ܡ�" );  
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("�޷��������ݿ�" ); 
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public ArrayList<ProfessorInfo> read(String sql) {
		ArrayList<ProfessorInfo> myProInfo = new ArrayList<ProfessorInfo>();
		Statement statement;
		ResultSet resultSet;
		
		try {
			statement = (Statement) getConnection(url).createStatement();
			resultSet = statement.executeQuery(sql);
			
			while(resultSet.next()) {
				String name = resultSet.getString(1);
				String educationBackground = resultSet.getString(2);
				String researchInterests = resultSet.getString(3);
				String email = resultSet.getString(4);
				String phone = resultSet.getString(5);
				
				ProfessorInfo ProInfo = new ProfessorInfo(name,educationBackground, 
						researchInterests,email,phone);
				myProInfo.add(ProInfo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("�޷��������ݿ�" ); 
			e.printStackTrace();
		}
		
		return myProInfo;
	}
}
