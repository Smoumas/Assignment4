import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;




public class WebConnect
{
	private Document document1 = null;
	private Document document2 = null;
	private Document document3 = null;
	private Document document4 = null;
	private Document document5 = null;
	private Document document6 = null;
	private Document document7 = null;
	private Document document8 = null;
	private Document document9 = null;
	private Document document10 = null;	
	
	private String url1 = "http://cs.whu.edu.cn/plus/view.php?aid=1628";
	private String url2 = "http://cs.whu.edu.cn/plus/view.php?aid=1611";
	private String url3 = "http://cs.whu.edu.cn/plus/view.php?aid=1625";
	private String url4 = "http://cs.whu.edu.cn/plus/view.php?aid=1608";
	private String url5 = "http://cs.whu.edu.cn/plus/view.php?aid=1727";
	private String url6 = "http://cs.whu.edu.cn/plus/view.php?aid=1717";
	private String url7 = "http://cs.whu.edu.cn/plus/view.php?aid=1725";
	private String url8 = "http://cs.whu.edu.cn/plus/view.php?aid=1567";
	private String url9 = "http://cs.whu.edu.cn/plus/view.php?aid=1557";
	private String url10 = "http://cs.whu.edu.cn/plus/view.php?aid=1569";

	private String DRIVE = "com.mysql.jdbc.Driver";
	private String URL = "jdbc:mysql://127.0.0.1/my_schema?useUnicode=true&amp;characterEncoding=UTF-8";
	private String USER = "root";
	private String  PASSWORD="123456?";//2312useUnicode=true&characterEncoding=utf8
	private Connection connection = null;
	private java.sql.PreparedStatement ps;
	
	//���ݿ������
	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName(DRIVE);
		System.out.println("�ɹ���������");
		connection = DriverManager.getConnection(URL,USER,PASSWORD);
		Statement statement = connection.createStatement();
		connection.setAutoCommit(false);
		System.out.println("�ɹ��������ݿ�");
		return connection;
	}
	
	public WebConnect() throws IOException
	{
		//ʹ��Jsoup���ӵ���ҳ
		long begin = System.currentTimeMillis();
		document1 = Jsoup.connect(url1).get();
		document2 = Jsoup.connect(url2).get();
		document3 = Jsoup.connect(url3).get();
		document4 = Jsoup.connect(url4).get();
		document5 = Jsoup.connect(url5).get();
		document6 = Jsoup.connect(url6).get();
		document7 = Jsoup.connect(url7).get();
		document8 = Jsoup.connect(url8).get();
		document9 = Jsoup.connect(url9).get();
		document10 = Jsoup.connect(url10).get();
		//ͨ��ѡ����ѡ��������HTML����
		Element element1 = document1.select("ul.about_info.fn_left").first();
		Element element11 = document1.select("div.info_list_ct").first();
		//System.out.println(element1);
		//System.out.println(element11);
		Element element2 = document2.select("ul.about_info.fn_left").first();
		Element element12 = document2.select("div.info_list_ct").first();
		//System.out.println(element2);
		//System.out.println(element12);
		Element element3 = document3.select("ul.about_info.fn_left").first();
		Element element13 = document3.select("div.info_list_ct").first();
		//System.out.println(element3);
		//System.out.println(element13);
		Element element4 = document4.select("ul.about_info.fn_left").first();
		Element element14 = document4.select("div.info_list_ct").first();
		//System.out.println(element4);
		//System.out.println(element14);
		Element element5 = document5.select("ul.about_info.fn_left").first();
		Element element15 = document5.select("div.info_list_ct").first();
		//System.out.println(element5);
		//System.out.println(element15);
		Element element6 = document6.select("ul.about_info.fn_left").first();
		Element element16 = document6.select("div.info_list_ct").first();
		//System.out.println(element6);
		//System.out.println(element16);
		Element element7 = document7.select("ul.about_info.fn_left").first();
		Element element17 = document7.select("div.info_list_ct").first();
		//System.out.println(element7);
		//System.out.println(element17);
		Element element8 = document8.select("ul.about_info.fn_left").first();
		Element element18 = document8.select("div.info_list_ct").first();
		//System.out.println(element8);
		//System.out.println(element18);
		Element element9 = document9.select("ul.about_info.fn_left").first();
		Element element19 = document9.select("div.info_list_ct").first();
		//System.out.println(element9);
		//System.out.println(element19);
		Element element10 = document10.select("ul.about_info.fn_left").first();
		Element element20 = document10.select("div.info_list_ct").first();
		//System.out.println(element10);
		//System.out.println(element20);
		//��ѡ����������ݵ�HTML����ת��Ϊ�����ı�����
		String text1 = element1.text();      
		String str1 =element11.text();
		//System.out.println(text1);
		String text2 = element2.text(); 
		String str2 = element12.text();
		String text3 = element3.text();
		String str3 = element13.text();
		String text4 = element4.text();
		String str4 = element14.text();
		String text5 = element5.text();
		String str5=  element15.text();
		String text6 = element6.text();
		String str6 = element16.text();
		String text7 = element7.text();
		String str7 = element17.text();
		String text8 = element8.text();
		String str8 = element18.text();
		String text9 = element9.text();
		String str9 = element19.text();
		String text10 = element10.text();
		String str10 = element20.text();
		try{
			//���ú����������ݿⲢ�����ݿ��в�������
			connection = getConnection();		
			ps = connection.prepareStatement("insert into TeacherInfomation(Name,Sex,Title,Tel,Mail,Introduction) values(?,?,?,?,?,?)");
			setString set = new setString();
			String[] string1 =new String[]{text1,text2,text3,text4,text5,text6,text7,text8,text9,text10};
			String[] string2 = new String[]{str1,str2,str3,str4,str5,str6,str7,str8,str9,str10};
			for(int j = 0;j<string1.length;j++)
			{
				set.setName(ps,string1[j]);
				set.setSex(ps,string1[j]);
				set.setTitle(ps, string1[j]);
				set.setTel(ps, string1[j]);
				set.setMail(ps, string1[j]);
				set.setIntroduction(ps, string2[j]);
				System.out.println("�������ݳɹ�");
				ps.executeUpdate();
				
			}
			try{
				//��Gui���淽�����е���
				new Gui();
			}catch(Exception e)
			{
				System.out.println("�������");
				e.printStackTrace();
			}
		
		}catch(SQLException e)
		{
			System.out.println("MySQL��������");
			e.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		long end = System.currentTimeMillis() - begin;
		System.out.println("��ʱ��" + end + "����");

	}
	
}
