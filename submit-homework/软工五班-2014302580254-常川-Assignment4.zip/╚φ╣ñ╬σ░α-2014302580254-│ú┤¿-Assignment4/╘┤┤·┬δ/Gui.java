import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Gui 
{
	private JPanel panel;
	public JTextField field;
	private ResultSet res;
	private java.sql.PreparedStatement ps;
	private Connection connection = null;
	
	public Gui() throws ClassNotFoundException, SQLException, IOException
	{
		connection = new WebConnect().getConnection();
		try
		{
			//����Gui���沢��Gui������в���
			JFrame frame = new JFrame("Search Engine");	
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setBounds(250,250,600,400);
			frame.setVisible(true);
			frame.setResizable(false);
			
			panel = new JPanel();
			frame.add(panel);
			panel.setLayout(null);
			
			field = new JTextField(20);
			panel.add(field);
			field.setBounds(20,20,400,50);
			
			JButton button = new JButton("Search");
			panel.add(button);
			button.setBounds(450,20,100,50);
			JTextArea area = new JTextArea(6,7);
			panel.add(area);
			area.setLineWrap(true);
			area.setWrapStyleWord(true);
			JScrollPane scroll = new JScrollPane(area);
			panel.add(scroll);
			scroll.setBounds(0,80, 600, 300);
			//ͨ����ť�������ʵ������
			button.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent e)
				{
					//���ùؼ��ֶ����ݽ�������
					String keyword = field.getText();
					String[] key = keyword.split(" ");
					try {
						ps = connection.prepareStatement("select * from TeacherInfomation");
						res = ps.executeQuery();
						area.setText("");
						//�����ݿ���б���
						while(res.next())
						{
							String Name = res.getString("Name");
							String Sex = res.getString("Sex");
							String Title = res.getString("Title");
							String Tel = res.getString("Tel");
							String Mail = res.getString("Mail");
							String Introduction = res.getString("Introduction");
							try
							{
								//ͨ��forѭ����String��contains�����԰����ؼ��ֵ����ݽ������
								for(int i = 0;i < key.length;i++)
								{

									if(Name.contains(key[i].replaceAll(" ", "")))
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
								for(int i = 0;i < key.length;i++)
								{

									if(Sex.contains(key[i].replaceAll(" ", "")))
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
							
								for(int i = 0;i < key.length;i++)
								{

									if(Title.contains(key[i].replaceAll(" ", "")))
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
								for(int i = 0;i < key.length;i++)
								{

									if(Tel.contains(key[i].replaceAll(" ", ""))
											)
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
								for(int i = 0;i < key.length;i++)
								{

									if(Mail.contains(key[i].replaceAll(" ", "")))
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
								for(int i = 0;i < key.length;i++)
								{

									if(Introduction.contains(key[i].replaceAll(" ", "")))
									{
										area.append("Name: "+Name+"\r\n");
										area.append(" Sex: "+ Sex+"\r\n");
										area.append(" Title: "+Title+"\r\n");
										area.append(" Tel: "+Tel+"\r\n");
										area.append(" Mail: "+Mail+"\r\n");
										area.append(" Introduction: "+Introduction+"\r\n");
										area.append("\r\n"+"\r\n");
									}
									else
										break;
								}
								
							}catch(Exception e1)
							{
								area.append("�����������ݲ�����");	
								e1.printStackTrace();
							}
							
							
							
						
						}
						if(null == area.getText() || area.getText().equals("")) 
						{
							area.setText("�����������ݲ�����");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					finally{
						try {
							
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						try {
							
						} catch (Exception e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
				}
				}
			});	
		}catch(Exception e)
		{
			System.out.println("����ʧ��");
			e.printStackTrace();
		}
	}

}
