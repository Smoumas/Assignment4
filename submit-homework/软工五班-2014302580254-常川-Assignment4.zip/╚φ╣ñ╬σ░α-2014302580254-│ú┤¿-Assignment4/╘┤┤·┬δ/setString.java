import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class setString
{
	public void setName(java.sql.PreparedStatement ps,String name) throws SQLException
	{
	    String html3 ="(?<=������).*(?= ��ҳ)";
	    Pattern p3 = Pattern.compile(html3);
        Matcher m3 = p3.matcher(name);
    	while(m3.find())
    	{
    		ps.setString(1,m3.group());
    	}	
		
	}
	public void setSex(java.sql.PreparedStatement ps,String sex) throws SQLException
	{
	    String html3 ="(?<=�Ա�).*(?= ְ�ƣ�)";
	    Pattern p3 = Pattern.compile(html3);
        Matcher m3 = p3.matcher(sex);
    	while(m3.find())
    	{
    		ps.setString(2, m3.group());
    	}
		
	}
	public void setTitle(java.sql.PreparedStatement ps,String title) throws SQLException
	{
		   String html3 ="(?<=ְ�ƣ�).*(?= ѧ��ѧλ��)";
		    Pattern p3 = Pattern.compile(html3);
	        Matcher m3 = p3.matcher(title);
	    	while(m3.find())
	    	{
	    		ps.setString(3, m3.group());
	    	}
			
	}
	public void setTel(java.sql.PreparedStatement ps,String tel) throws SQLException
	{
		   String html3 ="[0-9]{11}";
		    Pattern p3 = Pattern.compile(html3);
	        Matcher m3 = p3.matcher(tel);
	    	while(m3.find())
	    	{
	    		ps.setString(4, m3.group());
	    	}
			
	}
	public void setMail(java.sql.PreparedStatement ps,String mail) throws SQLException
	{
		   String html3 ="\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
		    Pattern p3 = Pattern.compile(html3);
	        Matcher m3 = p3.matcher(mail);
	    	while(m3.find())
	    	{
	    		ps.setString(5, m3.group());
	    	}
			
	}
	public void setIntroduction(java.sql.PreparedStatement ps,String introduction) throws SQLException
	{
		ps.setString(6,introduction);
	}

}
