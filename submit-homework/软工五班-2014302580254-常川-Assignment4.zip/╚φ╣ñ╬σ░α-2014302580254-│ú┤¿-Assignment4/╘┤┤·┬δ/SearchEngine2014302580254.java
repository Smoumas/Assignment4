import java.io.IOException;
import java.sql.SQLException;


public class SearchEngine2014302580254 {
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException
	{
		new WebConnect();
	} 
}
