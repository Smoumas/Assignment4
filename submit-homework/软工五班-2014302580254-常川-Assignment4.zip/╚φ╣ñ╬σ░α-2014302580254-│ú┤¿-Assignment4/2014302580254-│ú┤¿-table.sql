-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: teacherinfo
-- ------------------------------------------------------
-- Server version	5.7.9
--
-- Table structure for table `teacherinfomation`
--

DROP TABLE IF EXISTS `teacherinfomation`;

CREATE TABLE `teacherinfomation` (
  `Name` varchar(100) NOT NULL,
  `Sex` varchar(100) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Tel` varchar(100) NOT NULL,
  `MaiL` varchar(100) NOT NULL,
  `Introduction` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Dump completed on 2015-11-19 22:20:43
