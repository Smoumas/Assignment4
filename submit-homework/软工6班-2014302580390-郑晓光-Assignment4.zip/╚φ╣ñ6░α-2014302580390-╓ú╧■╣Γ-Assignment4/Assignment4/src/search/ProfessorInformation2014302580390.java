package search;

public class ProfessorInformation2014302580390 {
	private String name;
    private String educationBackground;
    private String email;
    private String phone;
    private String researchInterests;
    private double tf=0;    //��Ƶ
    private double tn;    //����ʵĴ���

    
    //set�Լ�get
    public void setName(String n){
    	name=n;
    }
    public void setEducationBackground(String e){
    	educationBackground=e;
    }
    public void setEmail(String m){
    	email=m;
    }
    public void setPhone(String p){
    	phone=p;
    }
    public void setResearchInterests(String r){
    	researchInterests=r;
    }
    public String getName(){
    	return name;
    }
    public String getEducationBackground(){
    	return educationBackground;
    }
    public String getEmail(){
    	return email;
    }
    public String getPhone(){
    	return phone;
    }
    public String getResearchInterests(){
    	return researchInterests;
    }
    public boolean Match(String kw){
    	
    	if(name.indexOf(kw)!=-1||educationBackground.indexOf(kw)!=-1||email.indexOf(kw)!=-1||phone.indexOf(kw)!=-1||researchInterests.indexOf(kw)!=-1){
    		if(name.indexOf(kw)!=-1){
    			String[] nstr=name.split("\\s");    //�ÿո�������ַ�����ô���
    			tn=0;                                   //���ô���
    			for(int i=0;i<nstr.length;i++){         //�����ַ�������������
    				if(nstr[i].indexOf(kw)!=-1)
    					tn+=1.0;
    			}
    		    tf+=0.4*(tn/Double.valueOf(nstr.length).doubleValue());   //��Ȩ�س��Դ��������ܴ����ӵ���Ƶ��
        	}
        	if(educationBackground.indexOf(kw)!=-1){
        	    String[] estr=educationBackground.split("\\s");    
        		tn=0;
        		for(int i=0;i<estr.length;i++){
        			if(estr[i].indexOf(kw)!=-1)
        				tn+=1.0;
        		}
        	    tf+=0.2*(tn/Double.valueOf(estr.length).doubleValue());
            }
        	if(email.indexOf(kw)!=-1){
        		String[] mstr=email.split("\\s");    
        		tn=0;
        		for(int i=0;i<mstr.length;i++){
        			if(mstr[i].indexOf(kw)!=-1)
        				tn+=1.0;
        		}
        	    tf+=0.1*(tn/Double.valueOf(mstr.length).doubleValue());
        	}
        	if(phone.indexOf(kw)!=-1){
        		String[] pstr=phone.split("\\s");    
        		tn=0;
        		for(int i=0;i<pstr.length;i++){
        			if(pstr[i].indexOf(kw)!=-1)
        				tn+=1.0;
        		}
        	    tf+=0.1*(tn/Double.valueOf(pstr.length).doubleValue());
        	}
        	if(researchInterests.indexOf(kw)!=-1){
        		String[] rstr=researchInterests.split("\\s");    
        		tn=0;
        		for(int i=0;i<rstr.length;i++){
        			if(rstr[i].indexOf(kw)!=-1)
        				tn+=1.0;
        		}
        	    tf+=0.1*(tn/Double.valueOf(rstr.length).doubleValue());
        	}
    	    return true;
    	}
    	else
    		return false;
    	
    }
    
    public double getTF(){
    	return tf;
    }
    //�����������professorInformation��Ϣ�ĺ���
    public String getPFIF(){
    	return "\nName:"+getName()
    	        +"\n"+"EducationBackground:"+getEducationBackground()
    			+"\n"+"E-mail:"+getEmail()
    			+"\n"+"Tele:"+getPhone()
    			+"\n"+"ResearchInterests:"+getResearchInterests()
    			+"\n"+"TF:"+getTF()+"\n";
    }

}
