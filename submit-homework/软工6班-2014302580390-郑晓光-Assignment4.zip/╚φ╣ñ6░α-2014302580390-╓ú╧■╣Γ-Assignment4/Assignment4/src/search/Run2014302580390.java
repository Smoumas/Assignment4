package search;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Run2014302580390 {
	public Connection con;        //��������
	public Conn2014302580390 c=new Conn2014302580390();
	static ResultSet res;
	static PreparedStatement ps=null;
	private String str="SELECT * FROM 2014302580390_professor_info;";
	private String content=new String();
	public Run2014302580390(String word){
		try {
		    con=c.getConnection();                 //�������ݿ�

		    List<ProfessorInformation2014302580390> listGet=new ArrayList<>();
		    ps=con.prepareStatement(str);
		    res=ps.executeQuery();
		    while(res.next()){
		    	ProfessorInformation2014302580390 pfif=new ProfessorInformation2014302580390();
		    	pfif.setName(res.getString("name").toLowerCase());
		    	pfif.setEducationBackground(res.getString("educationBackground").toLowerCase());
    			pfif.setEmail(res.getString("email").toLowerCase());
    			pfif.setPhone(res.getString("phone").toLowerCase());
    			pfif.setResearchInterests(res.getString("researchInterests").toLowerCase());
    			
    			listGet.add(pfif);
		    }
		   
		    KeywordMatcher2014302580390 kwm=new KeywordMatcher2014302580390(word,listGet);
		    content="\n"+kwm.getSB();
		    ps.close();
		    res.close();
		    con.close();
		    
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}
    public String getContent(){
    	return content;
    }

}
