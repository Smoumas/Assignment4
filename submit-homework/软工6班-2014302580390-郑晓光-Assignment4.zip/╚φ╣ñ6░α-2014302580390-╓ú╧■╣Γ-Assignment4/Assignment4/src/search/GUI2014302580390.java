package search;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class GUI2014302580390 extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JTextArea jt=new JTextArea();
	JTextField jt2=new JTextField();
    public void runGUI(){
		setTitle("Search Engines");
		setLayout(null);
		setBounds(0,0,800,800);
		Container c=getContentPane();
		JPanel p1=new JPanel();
		p1.setBounds(40,40,700,200);
		p1.setLayout(new GridLayout(2,1,80,80));
		JButton b=new JButton("search");		
		p1.add(jt2);
        p1.add(b);
		JScrollPane p2=new JScrollPane(jt);
		p2.setBounds(40, 240, 700, 450);
		p2.setVisible(true);
		c.add(p1);
		c.add(p2);
		jt.setBackground(Color.yellow);
		b.addActionListener(new bAction());
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	//����¼������������keyword������Run2014302580390����
    class bAction implements ActionListener{
    	public void actionPerformed(ActionEvent e){
    		String content=jt2.getText();
		    Run2014302580390 run=new Run2014302580390(content);
		    jt.setText(run.getContent());
	    }
    }
	public static void main(String[] args) {
		GUI2014302580390 a=new GUI2014302580390();
		a.runGUI();
	}

}
