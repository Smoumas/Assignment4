package search;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conn2014302580390 {
	Connection con;
	public Connection getConnection(){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
			System.out.println("���ݿ���سɹ�");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			System.out.println("���ݿ����ӳɹ�");
		}catch(SQLException e){
			e.printStackTrace();
		}
		return con;
	}

}
