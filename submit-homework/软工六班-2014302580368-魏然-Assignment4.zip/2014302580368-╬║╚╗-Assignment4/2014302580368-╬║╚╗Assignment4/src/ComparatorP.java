import java.util.Comparator;


public class ComparatorP implements Comparator<Professor>{

	@Override
	public int compare(Professor p1, Professor p2) {
		// TODO Auto-generated method stub
		if(p1.getTF()>p2.getTF())
			return 1;
		else if(p1.getTF()<p2.getTF())
			return -1;
		
		
		return 0;
	}

}
