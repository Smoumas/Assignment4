import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DataRead {
	private static String sql="SELECT * FROM 2014302580368_professor_info"; 
	
	public static ArrayList<Professor> read(){
		ArrayList <Professor> professor =new ArrayList<Professor>();
		DBUtil util=new DBUtil();
		Connection conn=util.openConnection();
		System.out.println("�ɹ����ӵ����ݿ⣡");
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				Professor p=new Professor();
				p.setName(rs.getString(1));
				p.setIntro(rs.getString(2));
				p.setInterest(rs.getString(3));
				p.setEmail(rs.getString(4));
				p.setTel(rs.getString(5));
				professor.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		
		return professor;
	}
}
