import java.util.ArrayList;
import java.util.Collections;



public class KeyWordMatch {
	String[] keyString;
	ArrayList<Professor>professorRead =DataRead.read();
	public void getKeyWord(String text){
		keyString=text.split("\\s");
		
	}
	
	public void Match(ArrayList<Professor>profe){
		for(Professor p:profe){
			double tf=p.getTF();
			for(String key:keyString){
				//ƥ������
				String[]names=p.getName().split("\\s");
				for(String name:names)
				{
					if(name.equals(key))
						tf+=0.6;
					
				}
				
				//ƥ���������
				String[]backs=p.getIntro().split("\\s");
				for(String back:backs)
				{
					if(back.equals(key))
						tf+=0.4;
					
				}
				
				//ƥ���о�����
				String[]interests=p.getInterest().split("\\s");
				for(String interest:interests)
				{
					if(interest.equals(key))
						tf+=0.4;
				}
			}
			p.setTF(tf);
		}
		
	}
	
	
	//����
	public ArrayList<Professor>sort(){
		ComparatorP com=new ComparatorP();
		Collections.sort(professorRead,com);
		return professorRead;
	}
}
