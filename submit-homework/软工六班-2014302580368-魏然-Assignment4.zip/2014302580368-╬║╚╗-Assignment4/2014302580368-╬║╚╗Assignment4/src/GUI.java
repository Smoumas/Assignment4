import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;


public class GUI {
	private static JTextField input;
	private static JTextArea output;
	private String text;
	public KeyWordMatch kwm;
	public GUI(){
	 kwm=new KeyWordMatch();	
	 JFrame window=new JFrame("��������");
	 window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    // window.setSize(500, 500); 
     window.setBounds(600, 200, 500, 500);
     window.setLayout(null);
     input = new JTextField();
     window.add(input);
     input.setBounds(20, 20, 330, 35);
     
     
     JButton button = new JButton();
     window.add(button);
     button.setBounds(370, 20, 100, 35);
     button.setText("Search");
     button.setFocusPainted(false);
     button.setIcon(new ImageIcon(getClass().getClassLoader().getResource("icon.png")));
     output = new JTextArea();

     JScrollPane scrollPane = new JScrollPane(output);
     window.add(scrollPane);
     scrollPane.setBounds(20, 95, 450, 355);
     scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

     output.setEditable(false);
     output.setText(" ");
     window.setVisible(true);
     
     button.addActionListener(new ActionListener() {
        
		@Override
		public void actionPerformed(ActionEvent e) {
			
			// TODO Auto-generated method stub
			if (input.getText().equals(""))
            {
                output.setText("Content can't be null !");
                return;
            }
            else
            {
                text = input.getText();
            }

            kwm.getKeyWord(text);
			kwm.Match(kwm.professorRead);
            ArrayList<Professor>result=kwm.sort();
            
            output.setText("");
            double Alltf = 0;
            for (Professor professor : result)
            {
            	Alltf=Alltf+professor.getTF();
            	if(professor.getTF()>0){
            		String educationBackground=professor.getIntro();
    				String researchInterests=professor.getInterest();
    				String email=professor.getEmail();
    				String phone=professor.getTel();
    				String name=professor.getName();
    				String proInfo="Name:"+name+"\n"+"EducationBackground:"+educationBackground+"\n"+"ResearchInterests:"+researchInterests+"\n"
    						+"email:"+email+"\n"+"phone:"+phone+"\n\n\n";
    				output.append(proInfo);
    				professor.setTF(0);
            	}       	
            }
            if (Alltf ==0.0)
            {
                output.setText("Can't find the content !");
            }
           

		}
     });
	}
	
	public static void main(String[]args){
		new GUI();
	}
}
