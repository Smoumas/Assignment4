import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;



public class GUI extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4288742188660439409L;
	private JTextField textInput;
	private JTextArea textOutput;
	private JButton button;
	private JScrollPane scroll;
	private GetInformation info;
	private ArrayList<String> searchResult;
	
	public GUI()
	{
		info = new GetInformation();
		
		//��ͼ����
		this.setTitle("SEARCH");
		this.setBounds(20,20, 600, 400);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new BorderLayout(0,10));
		
		textInput = new JTextField();
		//textInput.setBounds(40, 10, 300, 30);
		textOutput = new JTextArea();
		textOutput.setEditable(false);
		textOutput.setLineWrap(true);
		//textOutput.setBounds(40, 60, 450, 250);
		button = new JButton("Search");
		//button.setBounds(400, 10, 100, 30);
		scroll = new JScrollPane(textOutput);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		//scroll.setBounds(450, 60, 20, 250);
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 2, 10, 0));
		panel.add(textInput);
		panel.add(button);

		this.add(panel, BorderLayout.NORTH);
		this.add(scroll, BorderLayout.CENTER);
		
		this.setVisible(true);
		
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO �Զ����ɵķ������
				textOutput.setText(null);
				String things = textInput.getText().toUpperCase().trim();
				searchResult = new ArrayList<String>(info.SortByTf(info.ProInfo, things));
				for (int i = 0; i < searchResult.size(); i++)
					textOutput.append(searchResult.get(i) + "\n\r");
			}
		});
	}
	
}
