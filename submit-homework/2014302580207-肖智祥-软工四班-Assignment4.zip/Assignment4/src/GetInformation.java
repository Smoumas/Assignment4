import java.sql.*;
import java.util.ArrayList;

public class GetInformation 
{
	final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	final String URL = "jdbc:mysql://127.0.0.1:3306/professor?user=root&password=815322";
	public ArrayList<String> ProInfo;
	private ArrayList<String> Result;
	private ArrayList<Integer> tf;
	
	public GetInformation()
	{
		Data();
	}
	
	public void Data()
	{//�������ݿ⣬�������
		try {
			ProInfo = new ArrayList<String>();
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(URL);
			System.out.println("Connected database successfully...");
			Statement stmt = conn.createStatement();
			String sql = "SELECT name, educationBackground, researchInterests, email, phone FROM professor_info";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				ProInfo.add(rs.getString("name")+"  "+rs.getString("educationBackground")+"  "
						+rs.getString("researchInterests")+"  "+rs.getString("email")+"  "+rs.getString("phone"));
			}
			rs.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> SortByTf(ArrayList<String> s, String str)
	{
		tf = new ArrayList<Integer>();
		ArrayList<String> temp = new ArrayList<String>(s);
		//�ҵ����ؼ��ֵ����ݣ�ɾ�������ؼ��ֵ���Ϣ
		for (int i = 0; i < temp.size(); i++)
		{
			String s1 = temp.get(i).toUpperCase();
			String s2[] = s1.split(str); 
			if (s2.length == 0)
				temp.remove(i);
			else tf.add(s2.length);
		}
		for (int i = 0; i < tf.size(); i++)
		{//ð������
			for (int j = 0; j < tf.size() - 1; j++)
			{
				if (tf.get(j) < tf.get(j + 1))
				{
					int ai = tf.get(j);
					tf.set(j, tf.get(j + 1));
					tf.set(j + 1, ai);
					String st = temp.get(j);
					temp.set(j, temp.get(j + 1));
					temp.set(j + 1, st);
				}
			}
		}
	Result = new ArrayList<String>(temp);	
	return Result;
	}
	
}
