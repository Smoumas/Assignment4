import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.TextField;
import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Window.Type;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.CardLayout;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.TextArea;

public class MainSee extends javax.swing.JFrame implements ActionListener {
	public String input = "";
	private static final String PrintStream = null;
	private JFrame frmSearcher;
	TextArea textArea = new TextArea();
	Connection conn;
	ArrayList a;
	final String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	Statement pstm;
	ResultSet rs;
	String keyword;
	
	PrintStream orignalOut;
	OutputStream jtextOut;
	/**
	 * Launch the application.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		MainSee window = new MainSee();
		window.frmSearcher.setVisible(true);
		System.out.println("���������ģ��磺����������ʿ���о������");
	}

	/**
	 * Create the application.
	 */
	public MainSee() {
		initialize();
		orignalOut = System.out;
		jtextOut = new OutputStream()
		    {
		       final int BUFFER_LENGTH = 2048;
		       byte buf[] = new byte[BUFFER_LENGTH];
		       int pos = 0;
		       public void write(int b) throws IOException
		       {
		         buf[pos ++] = (byte)b;
		         if (pos >= BUFFER_LENGTH)
		         flush();
		       }
		       public void flush() throws IOException
		       {
		         if (pos >= BUFFER_LENGTH)
		          textArea.append(new String(buf));
		         else
		          textArea.append(new String(buf, 0, pos));
		         pos = 0;
		       }
		    };
		    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		    
		    try  {
		      initialize();
		    }
		    catch(Exception e) {
		      e.printStackTrace();
		    }
		    System.setOut(new PrintStream(jtextOut, true));
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private   void initialize() {
		frmSearcher = new JFrame();
		frmSearcher.setTitle("Searcher");
		frmSearcher.setBounds(100, 100, 603, 454);
		frmSearcher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSearcher.getContentPane().setLayout(null);
		
		TextField textField = new TextField();
		textField.setBounds(32, 29, 430, 33);
		frmSearcher.getContentPane().add(textField);
		
		Button button = new Button("Search");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
				
				keyword = textField.getText();
				conn = null;
				a= new ArrayList();
				String url = "jdbc:mysql://localhost:3306/javademo?"+ "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				try {
					conn = DriverManager.getConnection(url);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				try {
					pstm = conn.createStatement();
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				String sql="select * from _professor_info";
				try {
					rs = pstm.executeQuery(sql);
				} catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				for (int n=1;n<100;n++){
					try {
						while(rs.next()){
							ProfessorInfo pi =new ProfessorInfo();
							pi.name = rs.getString(n);
							pi.email = rs.getString(n+1);
							pi.phone = rs.getString(n+2);
							pi.info = rs.getString(n+3);
							pi.all=pi.name+pi.email+pi.phone+pi.info;
							a.add(pi);
						}
					} catch (SQLException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				}
				for(int n1=1;n1<100;n1++){
					ProfessorInfo pi2=(ProfessorInfo) a.get(n1);
					if(pi2.all.contains(keyword)){
						pi2.setName();
						pi2.setEmail();
						pi2.setPhone();
						pi2.setInfo();
						System.out.println("****************************");
					}
				}
				textField.setText("");
			}
		});
		button.setBounds(476, 29, 87, 25);
		frmSearcher.getContentPane().add(button);
		
		
		textArea.setBounds(32, 93, 531, 291);
		frmSearcher.getContentPane().add(textArea);
	}
	
	protected void processWindowEvent(WindowEvent e) {
	    super.processWindowEvent(e);
	    if(e.getID() == WindowEvent.WINDOW_CLOSING) {
	      System.exit(0);
	    }
	  }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɵķ������
		
	}
}
