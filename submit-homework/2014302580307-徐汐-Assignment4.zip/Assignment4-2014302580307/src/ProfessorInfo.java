import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import com.mysql.jdbc.PreparedStatement;

public class ProfessorInfo {
	String name="123";
	String email;
	String phone;
	String info;
	String sql="select * from _professor_info";
	Connection conn;
	Statement pstm;
	String all;
	
	void setName(){
		System.out.println(name);
	}
	
	void setEmail(){
		System.out.println(email);
	}
	
	void setPhone(){
		System.out.println(phone);
	}
	
	void setInfo(){
		System.out.println(info);
	}
}
