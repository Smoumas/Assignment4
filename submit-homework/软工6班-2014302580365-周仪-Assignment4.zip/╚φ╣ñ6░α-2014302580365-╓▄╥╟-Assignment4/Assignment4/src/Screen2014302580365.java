
public class Screen2014302580365 {
	
	public void displayMessagelineTA(String message){
		SearchProfessorFrame2014302580365.textArea.append(message + "\n");
	}
}
