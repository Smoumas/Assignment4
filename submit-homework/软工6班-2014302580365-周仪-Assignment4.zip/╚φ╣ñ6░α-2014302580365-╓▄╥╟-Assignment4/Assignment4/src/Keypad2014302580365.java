
public class Keypad2014302580365 {
	private static String input;
	public Keypad2014302580365(){
		
	}
	
	public static String getInput(){
		return input;
	}
	
	public static void set(String input){
		Keypad2014302580365.input = input;
	}
}
