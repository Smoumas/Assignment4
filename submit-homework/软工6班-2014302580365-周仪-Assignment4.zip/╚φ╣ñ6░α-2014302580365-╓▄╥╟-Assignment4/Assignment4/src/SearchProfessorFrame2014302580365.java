import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import java.awt.TextField;
import java.sql.SQLException;


public class SearchProfessorFrame2014302580365 {

	private JFrame frmSearchprofessor;
	private static SearchProfessor2014302580365 sp = new SearchProfessor2014302580365();
	static TextField textField = new TextField();
	static TextArea textArea = new TextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchProfessorFrame2014302580365 window = new SearchProfessorFrame2014302580365();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SearchProfessorFrame2014302580365() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSearchprofessor = new JFrame();
		frmSearchprofessor.setTitle("SearchProfessor2014302580365");
		frmSearchprofessor.setBounds(100, 100, 563, 393);
		frmSearchprofessor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSearchprofessor.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Please input what you want to search:");
		lblNewLabel.setFont(new Font("Consolas", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 10, 315, 22);
		frmSearchprofessor.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("  ");
				if(textField.getText() != null){
					try {
						String all = textField.getText();
						Keypad2014302580365.set(all);
						sp.run();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		textField.setFont(new Font("Consolas", Font.BOLD, 15));
		
		//TextField textField = new TextField();
		textField.setBounds(10, 38, 382, 31);
		frmSearchprofessor.getContentPane().add(textField);
		btnNewButton.setFont(new Font("Consolas", Font.BOLD, 15));
		btnNewButton.setBounds(412, 38, 125, 31);
		frmSearchprofessor.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Search result:");
		lblNewLabel_1.setFont(new Font("Consolas", Font.BOLD, 15));
		lblNewLabel_1.setBounds(10, 70, 128, 22);
		frmSearchprofessor.getContentPane().add(lblNewLabel_1);
		textArea.setFont(new Font("Consolas", Font.BOLD, 15));
		
		//TextArea textArea = new TextArea();
		textArea.setBounds(10, 94, 527, 250);
		frmSearchprofessor.getContentPane().add(textArea);
		
		frmSearchprofessor.setVisible(true);
	}
}
