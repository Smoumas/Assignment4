/**
 * Created by Xueting Gao on 15/11/13.
 */
public class Faculty2014302580153 {
    String name;
    String email;
    String researchDirection;

    public Faculty2014302580153(String theName, String theEmail, String theResearchDirection) {
        name = theName;
        email = theEmail;
        researchDirection = theResearchDirection;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getResearchDirection() {
        return researchDirection;
    }
}