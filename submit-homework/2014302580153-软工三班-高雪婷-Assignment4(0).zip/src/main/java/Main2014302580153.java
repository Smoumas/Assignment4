/**
 * Created by Xueting Gao on 15/11/13.
 */
public class Main2014302580153 {


    public static void main(String[] args) {
        Spider2014302580153 spider = new Spider2014302580153();

        System.out.println("单线程爬虫开始");
        long time1 = System.currentTimeMillis();
        spider.parseFacultySingleThread();
        long time2 = System.currentTimeMillis();
        System.out.println("单线程爬虫结束");
        System.out.println("耗时:" + (time2 - time1) + "ms");


        System.out.println("多线程爬虫开始");
        long time3 = System.currentTimeMillis();
        spider.parseFacultyMultiThread();
        while (true) {
            if (Thread.activeCount() <= 3) {
                break;
            }
        }
        long time4 = System.currentTimeMillis();
        System.out.println("多线程爬虫结束");
        System.out.println("耗时:" + (time4 - time3) + "ms");

    }
}
