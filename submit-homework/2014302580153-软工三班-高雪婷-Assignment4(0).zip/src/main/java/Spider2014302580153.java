import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Xueting Gao on 15/11/13.
 */
public class Spider2014302580153 {
    private Document document;
    private Elements tableRowItems;

    public Spider2014302580153() {
        try {
            document = Jsoup.parse(new File("./src/main/resources/上海科技大学.html"), "UTF-8");
            if (document != null) {
                tableRowItems = document.getElementsByTag("tbody").first().getElementsByTag("tr");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void parseFacultySingleThread() {
        for (int i = 1; i < tableRowItems.size(); i++) {
            Element tempTableRow = this.tableRowItems.get(i);
            Faculty2014302580153 faculty = parseFaculty(tempTableRow);
            if (faculty != null) {
                FacultyDatabase2014302580153 db = new FacultyDatabase2014302580153();
                db.writeFacultyToDBInSingleThread(faculty);
            }
        }
    }

    public void parseFacultyMultiThread() {
        ExecutorService exeServ = Executors.newFixedThreadPool(3);
        for (int i = 1; i < tableRowItems.size(); i++) {
            MultiThreadSpiderRunnable runnable = new MultiThreadSpiderRunnable(i);
            exeServ.execute(runnable);
        }

        exeServ.shutdown();
    }

    private Faculty2014302580153 parseFaculty(Element tr) {
        Elements tableDetails = tr.getElementsByTag("td");
        String name = tableDetails.get(0).getElementsByTag("a").first().ownText();
        if (name.equals("王雪红")) {
            return null;
        }
        String researchInterests = tableDetails.get(2).ownText();
        String email = tableDetails.get(4).getElementsByTag("a").first().ownText();
        //网站信息有误，去掉重复的@符号
        String newEmail = email.replaceFirst("@", "");
        Faculty2014302580153 faculty = new Faculty2014302580153(name, newEmail, researchInterests);
        return  faculty;
    }



    public class MultiThreadSpiderRunnable implements Runnable {

        private int index;

        public MultiThreadSpiderRunnable(int number) {
            index = number;
        }

        public void run() {
            Element tempTableRow = tableRowItems.get(index);
            Faculty2014302580153 faculty = parseFaculty(tempTableRow);
            if (faculty != null) {
                FacultyDatabase2014302580153 db = new FacultyDatabase2014302580153();
                db.writeFacultyToDBInMultiThread(faculty);
            }
        }
    }


}
