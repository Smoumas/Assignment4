import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Xueting Gao on 15/11/13.
 */
public class FacultyDatabase2014302580153 {
    private static final String SINGLETHREADTABLE = "faculty_table_single_thread";
    private static final String MULTITHREADTABLE = "faculty_table_multi_thread";

    public void writeFacultyToDBInSingleThread(Faculty2014302580153 faculty) {
        writeFacultyToDB(SINGLETHREADTABLE, faculty);
    }

    public void writeFacultyToDBInMultiThread(Faculty2014302580153 faculty) {
        writeFacultyToDB(MULTITHREADTABLE, faculty);
    }

    private void writeFacultyToDB(String tableType, Faculty2014302580153 faculty) {
        String sql = "insert into " + tableType + "(name, email, research_direction) values('" + faculty.getName()
                + "','" + faculty.getEmail() + "','" + faculty.getResearchDirection() + "')";
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/GXT_Java_Schema?user=root&password=12345&useUnicode=true&characterEncoding=UTF8");
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
