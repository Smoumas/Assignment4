
public class SearchResult implements Comparable<SearchResult>{
	public double TF;
	public ProfessorInfo proInfo;
	public SearchResult(double tf,ProfessorInfo info){
		TF= tf;
		proInfo = info;
	}
	public int compareTo(SearchResult sr) {
		// TODO Auto-generated method stub
		double temp = this.TF - sr.TF;
		if(temp > 0){
			return 1;
		}else if(temp == 0){
			return 0;
			
		}else{
			return -1;
		}
				
	}
	public double getTF() {
		return TF;
	}
	public void setTF(double tF) {
		TF = tF;
	}
	public ProfessorInfo getProInfo() {
		return proInfo;
	}
	public void setProInfo(ProfessorInfo proInfo) {
		this.proInfo = proInfo;
	}
	

}
