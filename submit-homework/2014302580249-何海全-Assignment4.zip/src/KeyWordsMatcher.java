import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KeyWordsMatcher {
	private String[] stopList = {"on","an","a","the"};
	private ArrayList<SearchResult> searchResultsList = new ArrayList<SearchResult>();
	private String input;
	public KeyWordsMatcher(String text){
		input = text.toLowerCase();
	}
	public void clear(){
		searchResultsList.clear();
	}
	private String[] manipulateInput(String input){ 
		for(int i = 0; i < stopList.length;i++){
			input = input.replace(stopList[i], "");
		
		}			
		//ע�⣡��\\s������'һ'���հ��ַ�
		return input.split("\\s+");
	}
	//����TFֵ
	private void caculateTF(String input){
		double tfValue = 0.0;
		String[] keyWords = manipulateInput(input);
		System.out.println("�����������keywords����");
		System.out.println(keyWords.length);
		for(int i =0;i < keyWords.length; i ++){
			System.out.println(keyWords[i]);
		}
		DataReader rd = new DataReader();
		
		ArrayList<ProfessorInfo>  professorList = rd.read("SELECT * FROM professor_info");
		Pattern pattern;
		Matcher matcher;
		ProfessorInfo pro;
		String integratedInfo;
		SearchResult singleResult;
		Iterator<ProfessorInfo> it = professorList.iterator();
		while(it.hasNext()){
			pro = it.next();
			integratedInfo = pro.toString().toLowerCase();
			
			for(int i = 0; i < keyWords.length; i++){
				pattern = Pattern.compile(keyWords[i]);
				matcher = pattern.matcher(integratedInfo);
			    if(matcher.find()){
			    	tfValue += 0.5;
			    }
			}
			if(tfValue > 0){
			    System.out.println("���ǵ�TFֵ�� --> "+tfValue);
				System.out.println("������resultList��pro���� ");
				System.out.println(pro);
				singleResult = new SearchResult(tfValue,pro);
				searchResultsList.add(singleResult);
			}
		//
			
		// 
	
			tfValue = 0.0;
		}
		
	}
	//�Խ�����Ͻ�������
	private void sort(){
		//��С����
		Collections.sort(searchResultsList);
		Collections.reverse(searchResultsList);
	}
	public ArrayList<SearchResult> getResultsList(){
		caculateTF(input);
		sort();
		return searchResultsList;
	}
	
}
