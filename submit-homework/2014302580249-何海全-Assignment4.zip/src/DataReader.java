import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataReader {
	private String url = "jdbc:mysql://localhost/my_schema?useUnicode=true&characterEncoding=UTF-8&user=root&password=123456";
	//private String url = "jdbc:mysql://localhost/teachers2?useUnicode=true&characterEncoding=UTF-8&user=root&password=123456";
	private Connection getConnection(String url) {
		Connection connection = null;
		
		try {
			System.out.println("Connecting to a selected database...");
			connection = DriverManager.getConnection(url);
			System.out.println("Connected database successfully...");	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("���������ݿ�����ʱ��������,failed when trying to connect to db");
			e.printStackTrace();
		}
		return connection;
		
	}
	
	public ArrayList<ProfessorInfo> read(String sql){
		Connection connection = getConnection(url);
		ArrayList<ProfessorInfo> proArray = new ArrayList<ProfessorInfo>();
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(sql);
			String name = null;
	        String educationBackground = null;
	        String researchInterests = null;
	        String email = null;
	        String telNum = null;
	        Map<String,String> contactInfo = new HashMap<String,String>();
			while(resultSet.next()){
		         //Retrieve by column name
				  name = resultSet.getString("name");
		          educationBackground = resultSet.getString("educationBackground");
		          researchInterests = resultSet.getString("researchInterests");
		          email = resultSet.getString("email");
		          telNum = resultSet.getString("telNum");
		          contactInfo.put("email", email);
		          contactInfo.put("telNum", telNum);	
		          ProfessorInfo info = new ProfessorInfo(name,contactInfo,educationBackground,researchInterests);
		          proArray.add(info);
		      }
			resultSet.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return proArray;
		
		
	}
}
