import java.util.Map;

public class ProfessorInfo {
	private String name;
	private Map<String,String> contactInfo;
	private String educationBackground;
	private String researchInterests;
	public ProfessorInfo(String name,Map<String,String> contactInfo,String educationBackground,String researchInterests){
		this.name = name;
		this.contactInfo = contactInfo;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
	}
	private String getAllInfo(){
		String str =  name + educationBackground + researchInterests + contactInfo.get("email") + contactInfo.get("telNum");
		return str;
	}
	public String toString(){
		return getAllInfo();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, String> getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(Map<String, String> contactInfo) {
		this.contactInfo = contactInfo;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	
}
