import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;

public class Main2014302580249 {

	private JFrame frame;
	private JTextField textField;
	private JTextArea myTextArea;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main2014302580249 window = new Main2014302580249();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main2014302580249() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 430, 284);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(26, 24, 273, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		myTextArea = new JTextArea();
		//��display area����edit
		myTextArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(myTextArea);
		scrollPane.setBounds(25, 55, 368, 180);
		frame.getContentPane().add(scrollPane);
		
		JButton btnNewButton = new JButton("Search");
		ButtonHandler btnHandler = new ButtonHandler(textField,myTextArea);
		btnNewButton.addActionListener(btnHandler);
		btnNewButton.setBounds(312, 23, 81, 23);
		frame.getContentPane().add(btnNewButton);
	
	}
	private class ButtonHandler implements ActionListener{
		private JTextField textField; 
		private JTextArea displayArea;
		public ButtonHandler(JTextField field,JTextArea display){
			textField = field;
			displayArea = display;
		}
		public void actionPerformed(ActionEvent e) {
			String input = textField.getText();
			KeyWordsMatcher matcher = new KeyWordsMatcher(input);
			ArrayList<SearchResult> ResultsList = matcher.getResultsList();
			Iterator<SearchResult> it = ResultsList.iterator();
			ProfessorInfo pro;
			String telNum,email;
			String displayStr = null;
			
			while (it.hasNext()){
				pro = it.next().getProInfo();
				email = pro.getContactInfo().get("email");
				telNum = pro.getContactInfo().get("telNum");
				displayStr += "name: "+ pro.getName()+
						     "\nemail: " + email +
						     "\ntelNum: " + telNum +
						     "\neducationBackground: " + pro.getEducationBackground()+
						     "\nresearchInterests: " + pro.getResearchInterests() + "\n";
				displayStr += "---------------------------" + "\n";
				
				
			}
			displayArea.setText(displayStr);
			matcher.clear();
		}
		
	}
}

