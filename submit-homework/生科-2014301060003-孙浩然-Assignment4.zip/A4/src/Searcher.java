import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Searcher {
	private ArrayList<Professor> professors;
	private ArrayList<String> stopWords;
	private ResultComparator rc;
	
	public Searcher() {
		professors = new ArrayList<Professor>();
		rc = new ResultComparator();
		stopWords = new ArrayList<String>();
		stopWords.add("of");
		stopWords.add("the");
		stopWords.add("a");
		stopWords.add("an");
		stopWords.add("and");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		//read data form database
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			PreparedStatement ps = con.prepareStatement("SELECT * FROM proinfo;");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())professors.add(new Professor(
				rs.getString(1).toLowerCase(),
				rs.getString(5).toLowerCase(),
				rs.getString(4).toLowerCase(),
				rs.getString(2).toLowerCase(),
				rs.getString(3).toLowerCase()));
			
			rs.close();
			ps.close();
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public void search(String str) {
		ArrayList<Professor> results = new ArrayList<Professor>();
		ArrayList<String> keywords = new ArrayList<String>(Arrays.asList(str.split("\\s")));
		keywords.removeAll(stopWords);
		for (Professor professor : professors) {
			professor.match(keywords);
			if (professor.getTF() > 0) results.add(professor);
		}
		professors.get(0).match(keywords);
		
		//sorting
		Collections.sort(results,rc);
		for (Professor result : results) result.display();
	}
	
	class ResultComparator implements Comparator<Professor>
	{
		@Override
		public int compare(Professor r1, Professor r2)
		{
			if(r1.getTF() > r2.getTF()) return -1;
			else if(r1.getTF() < r2.getTF()) return 1;
			return 0;
		}	
	}
}


