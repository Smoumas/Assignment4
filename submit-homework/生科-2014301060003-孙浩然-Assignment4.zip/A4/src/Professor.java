import java.util.ArrayList;
import java.util.Arrays;

public class Professor {
	private String name;
	private String phone;
	private String email;
	private String educationBackground;
	private String researchInterests;
	private int tf;//term frequency

	public Professor(String name, String phone, String email, String eb, String ri) {
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.educationBackground = eb;
		this.researchInterests = ri;
	}
	
	public void match(ArrayList<String> keywords) {
		tf = 0;
		ArrayList<String> tempAL = new ArrayList<String>
			(Arrays.asList((name + " " + phone + " " + email + educationBackground + researchInterests).split(",")));
		StringBuffer tempSB = new StringBuffer();
		for (String str : tempAL) tempSB.append(str + " ");
		ArrayList<String> words = new ArrayList<String>(Arrays.asList(tempSB.toString().split("\\s")));
		for (String word : words) 
			for (String keyword : keywords) if (word.equals(keyword)) tf++;
	}
	
	public int getTF() {
		return tf;
	}
	
	public void display() {
		System.out.println("Name:  " + name);
		System.out.println("Phone:  " + phone);
		System.out.println("Email:  " + email);
		System.out.println("Education Background:" + educationBackground);
		System.out.println("Research Interests:  " + researchInterests);
		System.out.println("\n");
	}
}
