import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pan;
	private JButton btn;
	private JTextField tf;
	private JTextArea ta;
	private JScrollPane sp;
	private Searcher searcher;
	private PrintStream ps;

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		GUI gui = new GUI();
	}
	
	public GUI() {
		setTitle("Professor Searcher");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 350);
		pan = new JPanel();
		pan.setLayout(null);
		add(pan);
		
		//search button
		btn = new JButton("Search");
		btn.setBounds(580, 10, 75, 25);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ta.setText("");
				searcher.search(tf.getText());
			}
		});
		pan.add(btn);
		
		//search bar
		tf = new JTextField(20);
		tf.setBounds(10, 10, 550, 25);
		pan.add(tf);
		
		//result area
		ta = new JTextArea();
		ta.setEditable(false);
		sp = new JScrollPane(ta);
		sp.setBounds(10, 50, 960, 250);
		pan.add(sp);
		
		setVisible(true);
		
		ps = new PrintStream(System.out){
			public void println(String str) {
		        ta.append(str + "\n");
		        ta.setCaretPosition(ta.getText().length());
		    }
			
		    public void print(String str) {
		    	ta.append(str);
		    	ta.setCaretPosition(ta.getText().length());
		    }
		      
		    public void print(double x) {
		    	ta.append(String.valueOf(x));
		        ta.setCaretPosition(ta.getText().length());}
		};
		System.setOut(ps);
		
		searcher = new Searcher();
	}

}
