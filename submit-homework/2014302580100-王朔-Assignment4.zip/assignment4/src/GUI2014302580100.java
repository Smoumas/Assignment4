import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class GUI2014302580100 extends JFrame
{
	private JPanel panel;
	private JPanel panel1;
	private JPanel panel2;
	private static JTextArea textarea;
	private static JTextArea textarea2;
//	private SearchInformation searchInformation;
//	private GridLayout gridlayout;
	private JButton button;
//	ArrayList<String> list=new ArrayList<String>();
//	public SearchInformation getsearchInformation()
//	{
//		return searchInformation;
//	}
	
	public GUI2014302580100()
	{
		
		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		
		panel1=new JPanel();
		panel1.setLayout(new GridLayout(1, 2));
		
		button=new JButton("����");
		button.setSize(20, 20);
		setTextarea(new JTextArea());
		getTextarea().setSize(100, 30);
		panel1.add(getTextarea());
		panel1.add(button);
		
		add(panel1);
		
		panel2 = new JPanel();
		setTextarea2(new JTextArea());
		getTextarea2().setRows(100);
		getTextarea2().setColumns(20);
		JScrollPane js = new JScrollPane(getTextarea2());
		panel2.add(js);
		
		panel.add(panel1,"North");
		panel.add(panel2,"Center");
		add(panel);
		
		
		button.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						try {
							SearchInformation100 s = new SearchInformation100();
							s.searchInformation();
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}

				}
				);
	}

	public static JTextArea getTextarea() {
		return textarea;
	}

	public void setTextarea(JTextArea textarea) {
		this.textarea = textarea;
	}

	public static JTextArea getTextarea2() {
		return textarea2;
	}

	public void setTextarea2(JTextArea textarea2) {
		this.textarea2 = textarea2;
	}



	
		
}

	


