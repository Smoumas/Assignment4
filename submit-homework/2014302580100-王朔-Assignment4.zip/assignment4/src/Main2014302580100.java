import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.channels.WritableByteChannel;
import java.sql.SQLException;

import javax.swing.JFrame;

public class Main2014302580100 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		GUI2014302580100 gui2014302580100=new GUI2014302580100();
		gui2014302580100.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui2014302580100.setSize(300,300);
		gui2014302580100.setVisible(true);
//		SearchInformation s = new SearchInformation();
//		s.searchInformation();
//		
		
	}

}
