
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SearchInformation100 {
	static Connection conn;
	static Statement sql;
	static ResultSet res;
	
	static ArrayList<String> search=new ArrayList<String>();//�洢һ����Ϣ
	
	static ArrayList<String> arr=new ArrayList<String>();//�洢һ��δ�ӹ�����Ϣ
	static String [] s;//
	static int size=0;//������ַ������ֵĴ���
	static ArrayList<Integer> ig=new ArrayList<Integer>();//�Գ��ֵ�λ�ô洢
	static ArrayList<Double> db=new ArrayList<Double>();//tf���򣬴�tfֵ

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		String drivername="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		String username="root";
		String password="123456";
		try {
			Class.forName(drivername);
			conn=DriverManager.getConnection(url,username,password);
		} catch (SQLException|ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
		return conn;
		
	}

	public static void searchInformation() throws ClassNotFoundException, SQLException {
		ArrayList<String> names=new ArrayList<String>();
		ArrayList<String> educations=new ArrayList<String>();
		ArrayList<String> interest=new ArrayList<String>();
		ArrayList<String> emails=new ArrayList<String>();
		ArrayList<String> phones=new ArrayList<String>();
		String text=GUI2014302580100.getTextarea().getText();
		conn=getConnection();
		try {
			sql=conn.createStatement();
			res=sql.executeQuery("select * from professor_info");
			while(res.next())
			{
				String name=res.getString("name");
				String education=res.getString("educationBackground");
				String interests=res.getString("researchInterests");
				String email=res.getString("email");
				String phone=res.getString("phone");
				
				names.add(name);
				educations.add(education);
				interest.add(interests);
				emails.add(email);
				phones.add(phone);
				search.add("\nname:"+name+"\neducationBackground:"+education+"\nresearchInterests:"+interests+"\nemail:"+email+"\nphone:"+phone);
				arr.add(name+education+interests+email+phone+"");
//				search.add("\neducationBackground:"+education);
//				search.add("\nresearchInterests:"+interests);
//				search.add("\nemail:"+email);
//				search.add("\nphone"+phone);
//				
//				System.out.println("name:"+name);
//				System.out.println("educationBackground:"+education);
//				System.out.println("researchInterests:"+interests);
//				System.out.println("email:"+email);
			}
			int i=-1;
//			int num=0;
			CharSequence [] cs1=names.toArray(new CharSequence[names.size()]);
			for(int j=0;j<cs1.length;j++)
			{
				if(cs1[j].toString().indexOf(text)!=-1)
				{
					i=j;
//					s=cs1[j].toString().split(" ");
					size++;
					System.out.println(size);
//					num++;
					find(i);
				}
				
				
			}

			CharSequence [] cs2=educations.toArray(new CharSequence[names.size()]);
			for(int j=0;j<cs2.length;j++)
			{
				if(cs2[j].toString().indexOf(text)!=-1)
				{
					i=j;
					size++;
					find(i);
				}

			}

			CharSequence [] cs3=interest.toArray(new CharSequence[names.size()]);
			for(int j=0;j<cs3.length;j++)
			{
				if(cs3[j].toString().indexOf(text)!=-1)
				{
					i=j;
					size++;
					find(i);
				}

			}

			CharSequence [] cs4=emails.toArray(new CharSequence[names.size()]);
			for(int j=0;j<cs4.length;j++)
			{
				if(cs4[j].toString().indexOf(text)!=-1)
				{
					i=j;
					size++;
					find(i);
				}

			}

			CharSequence [] cs5=phones.toArray(new CharSequence[names.size()]);
			for(int j=0;j<cs5.length;j++)
			{
				if(cs5[j].toString().indexOf(text)!=-1)
				{
					i=j;
					size++;
					find(i);
				}

			}
//			}
//			Integer [] array=arr.toArray(new Integer[arr.size()]);
//			if(i!=-1)
//			{
//				CharSequence [] cs=search.toArray(new CharSequence[search.size()]);
//				for(int j=0;j<array.length;j++)
//				{
//					GUI.getTextarea2().setText(cs[array[j]].toString());
//				}
////				System.out.print(cs[i]);
////				 GUI.getTextarea2().setText(cs[i].toString());
//			}else
//			{
//				System.out.print("Can't find "+text);
//				GUI.getTextarea2().setText("Can't find "+text);
//			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		showResult();
	}

	private static void showResult() {
		// TODO Auto-generated method stub
		CharSequence [] cs=search.toArray(new CharSequence[search.size()]);
		Integer [] nig=ig.toArray(new Integer[ig.size()]);
		Double [] dou=db.toArray(new Double[db.size()]);
//		System.out.println(nig);
		for(int k=0;k<dou.length;k++)
		{
//			System.out.println(dou[k]);
			for(int j=k+1;j<ig.size();j++)
			{
				if(dou[k]>dou[j])
				{
					double d=dou[k];
					dou[k]=dou[j];
					dou[j]=d;
					int in=nig[k];
					nig[k]=nig[j];
					nig[j]=in;
				}
			}
		}
//		System.out.println(nig);
		for(int k=0;k<ig.size();k++)
		{
//			System.out.println(dou[k]);
			GUI2014302580100.getTextarea2().setText(GUI2014302580100.getTextarea2().getText()+cs[nig[k]].toString());
		}
		
	}

	private static void find(int i) {
		if(i!=-1)
		{
			CharSequence [] cs=search.toArray(new CharSequence[search.size()]);
			CharSequence [] ncs=arr.toArray(new CharSequence[arr.size()]);
			s=ncs[i].toString().split(" |,");
			int length=s.length;
			double sort=(size*1.0)/length;
			db.add(sort);
			ig.add(i);
		}else
		{
			System.out.print("Can't find "+GUI2014302580100.getTextarea().getText());
			GUI2014302580100.getTextarea2().setText("Can't find "+GUI2014302580100.getTextarea().getText());
		}
		
	}


}
