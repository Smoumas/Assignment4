import java.util.ArrayList;
import java.sql.*;


public class ReadFromDatebase {
	String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	public ArrayList<String> ProInfo;
	private ArrayList<Integer> tf;
	private ArrayList<String> temp;
	public ReadFromDatebase()
	{
		getdate();
	}
	public void getdate(){
		ProInfo = new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url);
			//System.out.println("Connected successfully...");
			Statement stat = conn.createStatement();
			String sql = "SELECT name, educationBackground, researchInterests, email, phone FROM professor_info";
			ResultSet res = stat.executeQuery(sql);
			while(res.next()){
				ProInfo.add(res.getString("name")+" "+res.getString("educationBackground")+" "
			    +res.getString("researchInterests")+" "+res.getString("email")+" "+res.getString("phone"));
			}
			res.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("connect to sql fail");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("connect to sql fail");
		}
	}
	public ArrayList<String> SortByTf(ArrayList<String> s, String str){
		tf = new ArrayList<Integer>();
		temp = new ArrayList<String>(s);
		int i = 0;
		while (i < temp.size()){
			String s1 = temp.get(i).toUpperCase();
			String s2[] = s1.split(str); 
			if (s2.length == 0)
				temp.remove(i);
			else tf.add(s2.length);
			i++;
		}
		for (i = 0; i < tf.size(); i++)
		{
			for (int j = 0; j < tf.size() - 1; j++)
			{
				BubbleSort(tf,temp,j); //ð��
			}
		}
		ArrayList<String> Result = new ArrayList<String>(temp);	
		return Result;
		}
	public void BubbleSort(ArrayList<Integer> tf,ArrayList<String> temp,int j){
		if (tf.get(j) < tf.get(j + 1))
		{
			int ai = tf.get(j);
			tf.set(j, tf.get(j + 1));
			tf.set(j + 1, ai);
			String st = temp.get(j);
			temp.set(j, temp.get(j + 1));
			temp.set(j + 1, st);
			BubbleSort(tf,temp,j-1);
			}
		else {return;}
		}
	}

