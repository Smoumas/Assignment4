import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;

public class GUI extends JFrame{
	private static JTextField input; //�����ı���
	private static JScrollPane information; 
	private static ReadFromDatebase info; 
	private static JTextArea area;  //������
	public GUI(){
		this.setTitle("Professor Seacher");
		this.setVisible(true);
		}
	public static void main(String[] args) throws IOException{
		init(new GUI(),600,450);
		}
	private static void init(JFrame frame, int width, int height) {
	// TODO Auto-generated method stub
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width,height);
		frame.setVisible(true);
		frame.getContentPane().setLayout(null);
		//�����ı���
		input = new JTextField();
		frame.getContentPane().add(input);
		input.setBounds(20, 20, 250, 25);
	    //����Search��ť
	    JButton search=new JButton("Search");
	    frame.getContentPane().add(search);
	    search.setBounds(300,20,80,25);
	    //����
	    information = new JScrollPane();
		frame.getContentPane().add(information);
		information.setBounds(20, 60, 500, 330);
		//���봹ֱ������
		area = new JTextArea();
		area.setEditable(false); //���ɱ༭
		area.setLineWrap(true);
		information.setVerticalScrollBarPolicy( JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		information.getViewport().add(area);
		info = new ReadFromDatebase();
		//����¼�����
		search.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				area.setText(null);
				String things = input.getText().toUpperCase().trim();
				ArrayList<String> searchResult = new ArrayList<String>(info.SortByTf(info.ProInfo, things));
				for (int i = 0; i < searchResult.size(); i++)
					area.append(searchResult.get(i) + "\n\r");
			}
		});
		}
	}
