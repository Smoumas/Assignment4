import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class javaGUI{
	 public static void main(String args[]){
         JFrame mw = new JFrame("Search Engine");
         mw.setSize(1200,800);
         mw.getContentPane().setBackground(Color.gray);
         mw.getContentPane().setVisible(true);
         JTextField SearchField = new JTextField();
         SearchField.setText("Input Text");
         SearchField.setEditable(true);
         SearchField.setBounds(800, 80, 600, 30);
         JButton button = new JButton("Go");
         button.setBounds(800, 80, 100, 30);
         mw.getContentPane().add(button);
         JTextArea textA = new JTextArea(20,30);
         JScrollPane jsp = new JScrollPane(textA);
         mw.getContentPane().add(jsp);
         mw.setVisible(true);
     }
}
