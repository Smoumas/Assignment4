
public class SearchResult {
private ProfessorInf pi;
private int tf=0;
public SearchResult(ProfessorInf pi,int tf){
	this.pi=pi;
	this.tf=tf;
}
public ProfessorInf getProfessorInf(){
	return pi;
}
public int gettf(){
	return tf;
}
public void settf(int tf){
	this.tf=tf;
}

}
