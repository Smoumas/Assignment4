import java.util.Comparator;

public class ComparatorImp implements Comparator<SearchResult>{
	public int compare(SearchResult s1,SearchResult s2) { 
		if( s1.gettf()>s2.gettf()){
			return -1;}
		else if(s1.gettf()<s2.gettf())
			{return 1;}
		else{
			return 0;
		}
	}
}
