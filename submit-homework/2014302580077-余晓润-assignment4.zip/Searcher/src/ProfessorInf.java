import java.util.Map;

public class ProfessorInf {
private String name;
private String email;
private String phone;
private String educationBackground;
private String researchInterets;
public String getEmail(){
	return email;
}
public String getPhone(){
	return phone;
}
public String getName(){
	return name;
}
public void setName(String name){
	this.name=name;
}
public void setEmail(String email){
	this.email=email;
}
public void setPhone(String phone){
	this.phone=phone;
}

public String getEducation(){
	return educationBackground;
}
public void setEducation(String educationBackground){
	this.educationBackground=educationBackground;
}
public String getResearch(){
	return researchInterets;
}
public void setResearch(String researchInterets){
	this.researchInterets=researchInterets;
}
public String toString(){
	return "\nname:"+name+"\neducationBackground:"+educationBackground+"\nreserchInterests"+researchInterets+"\nemail"+email+"\nphone:"+phone;
}
}
