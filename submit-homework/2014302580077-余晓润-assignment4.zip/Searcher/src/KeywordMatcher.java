import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KeywordMatcher {
private List<String> Keywords;
public ArrayList<SearchResult> sr;
private String[] Stopwords; 
public KeywordMatcher(){
	this.Stopwords=new String[]{"of","a","an","the","in","and","for"};
	Keywords=new ArrayList<String>();
	sr=new ArrayList<SearchResult>();
}
public void setKeywords(String text){
	String[] keywords=text.split("\\s+");
	for(int i=0;i<keywords.length;i++){
		boolean t=true;
		for(int j=0;j<Stopwords.length;j++){
			if(keywords[i]==Stopwords[j])t=false;
		}
		if(t){
			Keywords.add(keywords[i]);
		}
	}
}
public void calcTf(ArrayList<ProfessorInf> result){
	
	for(ProfessorInf inf:result){
		SearchResult s=new SearchResult(inf,0);
		  sr.add(s);}
	for(int i=0;i<sr.size();i++){
		for(int j=0;j<Keywords.size();j++){
			Pattern p1=Pattern.compile(Keywords.get(j),Pattern.CASE_INSENSITIVE);  
		 	  Matcher m1=p1.matcher(sr.get(i).getProfessorInf().toString());
		 	  int count=0;
		 	 while(m1.find()){count++;};
		 	 sr.get(i).settf(sr.get(i).gettf()+count);
		}
		
	}
}
public void sort(){
	Comparator compare= new ComparatorImp();
	Collections.sort(sr, compare);
}
}
