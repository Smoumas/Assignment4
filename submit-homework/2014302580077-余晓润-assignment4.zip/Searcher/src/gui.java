import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class gui extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	private DataReader dr;
	private ArrayList<ProfessorInf> result=new ArrayList();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui frame = new gui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public gui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		textField = new JTextField();
		textField.setBounds(23, 10, 206, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 59, 365, 174);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String text=textField.getText();
				textArea.setText("");
				text=text.replace("+", "\\+");
				 KeywordMatcher km;
				 km=new KeywordMatcher();
				km.setKeywords(text);
				km.calcTf(result);
				km.sort();
				 for(SearchResult s:km.sr){
					 if(s.gettf()!=0){
				    	textArea.append(s.getProfessorInf().toString());
					 }
				    }
			}
		});
		btnSearch.setBounds(289, 9, 93, 23);
		contentPane.add(btnSearch);
		
		dr=new DataReader();
		try {
			dr.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			result=dr.read();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
