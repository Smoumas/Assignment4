import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataReader {
private Connection conn;
public void getConnection(String url) throws ClassNotFoundException, SQLException{
	Class.forName("com.mysql.jdbc.Driver");
	 conn=DriverManager.getConnection(url);
}
public ArrayList<ProfessorInf> read() throws SQLException{
	ArrayList<ProfessorInf> result=new ArrayList();
	 Statement st=conn.createStatement(); 
	 ResultSet resultset=st.executeQuery("select * from professor_info ");  
	 while(resultset.next()){
		 ProfessorInf pi=new ProfessorInf();
		 pi.setName((String)(resultset.getObject("name")));
		 pi.setEmail((String)(resultset.getObject("email")));
		 pi.setPhone((String)(resultset.getObject("phone")));
		 pi.setEducation((String)(resultset.getObject("educationBackground")));
		 pi.setResearch((String)(resultset.getObject("researchInterests")));
		 result.add(pi);
	 }
	 return result;
}
}
