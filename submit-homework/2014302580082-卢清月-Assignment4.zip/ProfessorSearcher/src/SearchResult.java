
public class SearchResult {
	private ProfessorInformation pf;
	private int TF = 0;
	public void SearchResult(ProfessorInformation pf,int TF){
		
	}
		//��ȡp
	public void getP()
		  {
		    return;
		  }
	public void setPi(ProfessorInformation pf) {
	    this.pf= pf;//��Ϊ��ǰ
	  }
	//��ȡTF
	public void getTF()
	  {
	    return;
	  }
	
	public void setTF(int TF) {
	    this.TF= TF;//��Ϊ��ǰ
	  }
}
