import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class GUI2014302580082 extends JFrame {

	private String input = "";
	private JTextField textfield = new JTextField();
	private JTextArea textarea = new JTextArea();
	public  GUI2014302580082(){
		//���ô���
		this.setResizable(false);
		this.setTitle( "Professor Searcher" );
		this.setBounds(100,100,500,400);
		this.setBackground(Color.white);
		this.setVisible(true);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		//��ʼ�������
		textfield.setOpaque(true);
		textfield.setEditable(true);
		textfield.setBounds(10,10, 300, 25);
		add(textfield);
		
		//��ʼ���������
		textarea.setLineWrap(true);
		textarea.setOpaque(true);
		textarea.setEditable(false);
		textarea.setBounds(10, 40, 470, 300);
		JScrollPane panel = new JScrollPane(textarea);
		panel.setBounds(10, 40, 470, 300);
		add(panel);
		add(textarea);
		
		//�������������JScrollPane��
		JScrollPane scrollPane = new JScrollPane(textarea);
		scrollPane.setBounds(460, 40, 20, 300);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		add(scrollPane);
		
		//���������ð�ť
		JButton b=new JButton("Search");
		add(b);
		b.setBounds(320,10,80,25);
		
		//�԰�ť���Ӽ����¼�
 
		
		}	

		/*

      public String userInput() {
    	  
             String info = (this.input);
             input = "";
             return info; 

      }
      */
      public static void main(String[] args) {
    	  GUI2014302580082 mygui = new GUI2014302580082();
      }
}
