
import java.util.*;

public class KeywordsMatcher {

	private static final String p = null;
	private List<String> keywords;
	private ArrayList<SearchResult> searchResultList = new ArrayList();
	private DataReader= new DataReader();
	 private void fetchKeywords(){
		  
	  }
	//���˶������
	private String[] stopList= {",","the","a","an","of" ,"and"};
	private Comparator s;
	//��TF��������
	public void calTF(String input){
		int x = 0;
		String Input=null;
		String[] input1 = Input.split("\\s+");
	    int a = keywords.size();

		keywords=new ArrayList<String>();
		SearchResult SR=new SearchResult();
		searchResultList.add(SR);
		for(int i=0;i<searchResultList.size();i++){
			for(int j=0;j<a;j++){
				if (keywords.equals(input1)) {
					x++;
				}
			}
		}
	}
	public ArrayList<SearchResult> sort(){
		
		Collections.sort(searchResultList, s);
		return searchResultList;		
	}
}
