
public class ProfessorInformation {
	private String name;	
	private String email;
	private String phone;
	private String researchInterests;
	private String educationBackground;
	//��ȡ���������䣬�绰��
	public String getName(){
		return this.name;
	}
	public String getEmail(){
		return this.email;
	}
	public String getPhone(){
		return this.phone;
	}
	public String getReseachInterests(){
		return  this.researchInterests;
	}
	public String getEducationBackground(){
		return  this.educationBackground;
	}
	public String toString(){
   return "\nname:"+name+"Email:"+email+"\nPhone:"+phone+"\nResearchIntersts:"+researchInterests+"\nEducationBackground"+educationBackground;
	}
}
