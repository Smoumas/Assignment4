import java.sql.*;

import com.mysql.jdbc.Statement;
public class DataReader {
	 private String url ="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";

	    //�����ݿ������ʵ����
	    Connection sqlCon = DriverManager.getConnection(url,"Fernanda", "J8");
	            Connection Open() {
					return null;
				}
	    		//Ҫִ�е�sql���
	    		String sql="SELECT * FROM 2014302580082.professor_info";
	    		//����DataAdapterʵ��
	    		DataAdapter da=new DataAdapter(sql,sqlCon); 
	    		//����DataSetʵ��
	    		DataSet ds=new DataSet();
	    		//���
	    		da.Fill;
	    		Statement sta=(Statement) sqlCon.createStatement();
	    		ResultSet re=sta.executeQuery(sql);
                while(res.next()){
                	ProfessorInformation pi=new ProfessorInformation();
                	SQLData da1=new SqlDataAdapter("name",sqlCon);
                	SQLData da2=new SqlDataAdapter("email",sqlCon);
                	SQLData da3=new SqlDataAdapter("phone",sqlCon);
                	SQLData da4=new SqlDataAdapter("researchInterests",sqlCon);
                	SQLData da5=new SqlDataAdapter("educationBackground",sqlCon);
                  
                }
                Connection Close() {
					return null;
				}
}
