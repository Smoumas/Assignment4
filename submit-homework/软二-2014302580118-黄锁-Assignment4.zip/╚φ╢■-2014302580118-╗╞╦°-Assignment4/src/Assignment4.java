import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class Assignment4 extends JFrame{
	public Assignment4(){
	JPanel p1 =  new JPanel();
	JPanel p2 =  new JPanel(new BorderLayout());
	p2.add(new JTextField(" Input the information of Professors you want to search"),BorderLayout.WEST);
	JButton B = new JButton("Search");
	p2.add(B,BorderLayout.EAST);
	p1.add(p2,BorderLayout.NORTH);
	JTextArea T = new JTextArea();
	T.setText("Even when today, I can't use mysql, and I don't have the courage to do it ");
	T.setSize(300,180);
	add(p1);
	
	B.addActionListener(
			new ActionListener(){
				public void actionPerformed(ActionEvent e){
					p1.add(T,BorderLayout.SOUTH);
				}
			}
		);
	}
	
	public static void main(String[] args){
		Assignment4 frame = new Assignment4();
		frame.setTitle("Professor Search");
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
