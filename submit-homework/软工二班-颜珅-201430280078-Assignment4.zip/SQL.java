import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class SQL {
	
	

	public ResultSet getResultSet(String url) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("SELECT * FROM my_schema.professor_info");
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public String getString(ResultSet rs,int i){
		try {
			return rs.getString(i);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
}
