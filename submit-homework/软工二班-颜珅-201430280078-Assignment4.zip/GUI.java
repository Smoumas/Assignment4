import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Array;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


@SuppressWarnings("serial")
public class GUI extends JFrame{

	public static String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"+
			"user=root&password=123456";
	private JButton search=new JButton("����");
	//private JScrollPane btnPanel;
	
	public static JTextArea  input=new JTextArea(1,47);
	public static JTextArea  output=new JTextArea(20,54);
	public static JLabel label=new JLabel("������Ϣ��ѯ");
	public GUI(String title)
	    {
	        this();
	        setTitle(title);
	    }
public GUI(){
    setLayout(new FlowLayout(FlowLayout.LEADING));
    setResizable(false);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setSize(600, 480);
    input.setEditable(true);
    output.setEditable(false);
    add(label);
    add(input);
    add(search);
    add(output);
    output.append(List);
    search.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
			Search();
        }
    });
}
private void Search() {
	
	
}
public static void main(String[] args) {
	SQL sql=new SQL();
	ResultSet rs=sql.getResultSet(url);
	ArrayList<String> List = new ArrayList<String>();
	for(int i=0;i<10;i++){
		List.add(sql.getString(rs, i));
	}
	GUI gui=new GUI("search");
    gui.setVisible(true);


}
}

