-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: teacherinformation
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `_professor_info`
--

LOCK TABLES `_professor_info` WRITE;
/*!40000 ALTER TABLE `_professor_info` DISABLE KEYS */;
INSERT INTO `_professor_info` VALUES (1,'艾新平','xpai@whu.edu.cn','13908646871',' 电化学能源材料及技术'),(2,'蔡杰','null','027-87219274，87216311',' 高分子化学与物理'),(3,'蔡苹','applecaiping@163.com','',' 配位化学、生物无机化学'),(4,'蔡毅','yc131@whu.edu.cn','',''),(5,'曹余良','ylcao@whu.edu.cn','027-68754526',' 物理化学'),(6,'查全性','qxzha@whu.edu.cn','027-68762515',' 电化学能源科学与技术'),(7,'陈贝贝','bbchen@whu.edu.cn','027-87653132',''),(8,'陈红坤','null','',' 电力系统及其自动化'),(9,'陈胜利','slchen@whu.edu.cn','027-68754693',''),(10,'陈曦','null','',''),(11,'陈晓旭','null','',' 西方哲学'),(12,'陈兴国','xgchen@whu.edu.cn','027-68755655',' 有机化学'),(13,'陈云','null','',' 生物材料'),(14,'陈政','null','027-68756319；+44-115 9514171',' 电化学、材料化学、物理化学、化学工程'),(15,'程功臻','null','',' 无机化学、配位化学'),(16,'程翰','chm128256@163.com','68753990',' 高分子化学与物理'),(17,'程巳雪','null','68754061',' 生物医用高分子'),(18,'程永光','null','',' 水电站水力学，计算流体动力学'),(19,'楚锡华','null','',' 颗粒材料力学，计算固体力学'),(20,'崔然','cuiran@whu.edu.cn','027-68756759',' 分析化学、纳米生物医学分析'),(21,'邓鹤翔','hdeng@whu.edu.cn','',' 框架化学（Reticular Chemistry）绿色能源储存'),(22,'邓立志','null','',''),(23,'邓媛','null','',''),(24,'董金凤','jfdong@whu.edu.cn','027-63587628',' 化学 物理化学'),(25,'杜宇昊','null','',''),(26,'冯果','null','',''),(27,'冯俊','fengjun@whu.edu.cn','027-68753990',' 高分子化学与物理'),(28,'冯钰锜','yqfeng@whu.edu.cn','027-68755595',' 分析化学'),(29,'付磊','leifu@whu.edu.cn','leifu@whu.edu.cn',' 物理化学'),(30,'高戈','null','',''),(31,'高志农','whugzn@aliyun.com','13554333517',' 高分子化学与物理、应用化学'),(32,'龚淑玲','gongsl@whu.edu.cn','',' 高分子化学与物理，有机化学'),(33,'龚晓艳','null','',''),(34,'郭小峰','null','',''),(35,'何蔓','heman@whu.edu.cn','027-87653132',' 分析化学'),(36,'何治柯','zhkhe@whu.edu.cn','（027）68756557，61023006',' 分子光谱分析及纳米传感器'),(37,'贺枫','hefeng@whu.edu.cn','68754061',' 高分子化学与物理'),(38,'洪亮','hong@whu.edu.cn','',' 数据管理，社会网络，数据分析'),(39,'洪昕林','hongxl@whu.edu.cn','13871151716；027-68756619',' 环境与能源催化、胶体与界面化学'),(40,'侯安新','null','',''),(41,'侯华','houhua@whu.edu.cn','027-68756347','理论计算机化学'),(42,'侯艳','null','',''),(43,'胡斌','binhu@whu.edu.cn','027-68752162',' 原子光谱/质谱分析'),(44,'胡成国','cghu@whu.edu.cn','',' 生物电分析、光电化学传感器'),(45,'胡继明','jmhu@whu.edu.cn','027-68752439-8701',' 分析化学'),(46,'胡锴','null','',''),(47,'胡晓宏','xhhu88@126.com，xhhu88@whu.edu.cn','027-68754111',' 物理化学，电化学'),(48,'胡志坚','null','',' 电力系统运行与控制，新能源接入与分布式电力系统'),(49,'黄超','00008105@whu.edu.cn','18971659816',''),(50,'黄驰','chihuang@whu.edu.cn','18971088222',' 应用化学、材料化学'),(51,'黄浩','haohuang@whu.edu.cn','027-68776156',' 大数据管理和分析、数据挖掘、智能信息系统'),(52,'黄萌','null','13871102226',' 电力电子变换器，非线性分析，可靠性设计'),(53,'黄世文','swhuang@whu.edu.cn','86-27-68755317',' 高分子化学与物理'),(54,'黄卫华','whhuang@whu.edu.cn','027-68752149',' 有机化学'),(55,'姜中兴','ioc@whu.edu.cn','027-68754827',''),(56,'蒋风雷','fljiang@whu.edu.cn','027-68756667 (化西312)',' 物理化学、化学生物学'),(57,'蒋序林','xljiang@whu.edu.cn，xljiang118@hotmail.com','027-68755200,68754509',' 高分子化学与物理、生物医用高分子、高分子分离与表征'),(58,'金先波','xbjin@whu.edu.cn','018971394579，02768756319',''),(59,'柯福生','kefs@whu.edu.cn','',''),(60,'雷爱文','aiwenlei@whu.edu.cn','',' 金属有机化学'),(61,'李春葆','licb1964@126.com','18986211682',''),(62,'李峰','lifeng@whu.edu.cn','027-68754509',' 高分子化学与物理'),(63,'李桦','lihua@whu.edu.cn','027-68752439-8211',' 分析化学（毛细管电泳/液相色谱分离分析）'),(64,'李进平','lukeping@whu.edu.cn','13971650254',' 水电站水力学及过渡过程'),(65,'李倩倩','null','',''),(66,'李清安','qingan@whu.edu.cn','02768776156',' 编译技术、嵌入式系统和非易失性存储技术'),(67,'李仁杰','lirj@whu.edu.cn','',' 无机化学，配位化学'),(68,'李学丰','lixf_whu@163.com','15972227588',' 物理化学'),(69,'李早英','zyliwuc@whu.edu.cn','027-87219084',''),(70,'李振','lizhen@whu.edu.cn','027-68755363',' 有机、高分子光电功能材料'),(71,'廖立琼','liqiongliao@hotmail.com','027-87212246',' 高分子化学与物理'),(72,'林安','linanwd@126.com','13807166039',' 环境与材料'),(73,'林涛','tlin@whu.edu.cn','027-68774003',' 电气工程'),(74,'林毅','ylin@whu.edu.cn','027-68756759',' 表面分析化学、纳米生物技术'),(75,'刘成金','null','',''),(76,'刘传军','cjliu@whu.edu.cn','027-68754061',' 高分子化学与物理'),(77,'','null','',''),(78,'刘立建','liulj@whu.edu.cn','027-68756825',' 高分子化学'),(79,'刘镕','null','',''),(80,'刘胜华','null','',' 土地政策法规，土地利用'),(81,'刘数华','null','',''),(82,'刘晓庆','xiaoqingliu@whu.edu.cn','027-68754035',' 分析化学'),(83,'刘义','yiliuchem@whu.edu.cn','027-68756667;68753465',' ①生物热化学与热分析；②生命动态过程化学；③靶向药物化学；④纳米生物效应；⑤小分子与生物大分子相互作用'),(84,'刘英','liuying69@126.com','027-61314455',' 富勒烯与碳纳米材料'),(85,'刘欲文','ywliu@whu.edu.cn','027-68754693',' 物理化学，电化学'),(86,'刘芝兰','liuzl@whu.edu.cn','027-68755200',' 生物医用高分子，天然高分子'),(87,'刘志洪','zhhliu@whu.edu.cn','027-87217886',' 分析化学，生物分析'),(88,'刘智伟','zwliu@sina.com;liuzw@whu.edu.cn','-',' 分布式网络系统、智能电网的控制与优化、脉冲切换系统'),(89,'龙新平','null','',' 流体机械及工程，射流理论及应用'),(90,'吕昂','null','02787219274',' 天然高分子和高分子物理'),(91,'吕辉','huilv@whu.edu.cn','027-68755925',' 有机合成'),(92,'罗金耀','null','',''),(93,'罗立新','lxluo@whu.edu.cn','027-68772262',' 应用化学'),(94,'罗威','wluo@whu.edu.cn','027-68752366',''),(95,'罗运柏','ybai@whu.edu.cn','13807148090',' 应用化学'),(96,'孟宪梅','hopemengmei@126.com','18986098533',''),(97,'莫少波','null','',''),(98,'牛菲','null','',''),(99,'庞代文','dwpang@whu.edu.cn','027-68756759',' 生物医学分析化学、纳米生物技术'),(100,'彭天右','typeng@whu.edu.cn','027-68752237',' 无机固体化学，材料化学，纳米功能材料');
/*!40000 ALTER TABLE `_professor_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-18 18:33:07
