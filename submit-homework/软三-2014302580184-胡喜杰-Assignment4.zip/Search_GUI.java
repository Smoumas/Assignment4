import javax.swing.*;
import java.awt.event.*;

/**
 * Created by Administrator on 2015/11/12.
 */
public class Search_GUI {
    private JFrame jFrame;
    private JTextField jTextField;
    private JButton jButton;
    private JTextArea jTextArea;
    private JScrollPane jScrollPane;
    private String keywords;

    public Search_GUI() {
        setjFrame();
        setjTextField();
        setjButton();
        setjTextArea();
        keyPressed();
    }

    //初始化界面
    public void setjFrame() {
        jFrame = new JFrame("Search GUI");
        jFrame.setLayout(null);
        jFrame.setSize(450,500);
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    //设置文本输入框
    public void setjTextField() {
        jTextField = new JTextField();
        jTextField.setBounds(20,30,250,30);
        jFrame.add(jTextField);
    }

    //设置按钮
    public void setjButton() {
        jButton = new JButton("Search");
        jButton.setBounds(300,30,100,30);
        jFrame.add(jButton);

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jTextArea.setText("");  //将结果框清空
                keywords = jTextField.getText();
                keywords = keywords.trim();     //去掉前后缀
                SearchResult searchResult = new SearchResult(jTextArea,keywords);
                searchResult.getSearchResult();
            }
        });
    }

    //定义按下回车实现的功能
    public void keyPressed() {
        jTextField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                int target = e.getKeyCode();
                if(target == KeyEvent.VK_ENTER) {
                    jTextArea.setText("");  //将结果框清空
                    keywords = jTextField.getText();
                    keywords = keywords.trim();     //去掉前后缀
                    SearchResult searchResult = new SearchResult(jTextArea,keywords);
                    searchResult.getSearchResult();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
    }

    //设置输出框与滚动条
    public void setjTextArea() {
        jTextArea = new JTextArea();
        jTextArea.setEditable(false);
        jScrollPane = new JScrollPane(jTextArea);
        jScrollPane.setBounds(20,80,400,350);
        jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        //jFrame.add(jTextArea);
        jFrame.add(jScrollPane);
    }
}
