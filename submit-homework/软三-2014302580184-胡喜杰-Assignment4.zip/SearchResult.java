import javax.swing.*;
import java.sql.*;

/**
 * Created by Administrator on 2015/11/12.
 */
public class SearchResult {
    private ProfessorInfo[] professorInfos = new ProfessorInfo[50];
    private double[] tf = new double[50];
    private String name;
    private String educationBackground;
    private String researchInterests;
    private String email;
    private String phone;
    private String keywords;
    private JTextArea jTextArea;
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private int index = 0;
    private int resultCount = 0;

    public SearchResult(JTextArea jTextArea,String keywords) {
        this.jTextArea = jTextArea;
        this.keywords = keywords;
        for(int i=0;i<50;i++) {
            professorInfos[i] = new ProfessorInfo();
        }
    }

    public void linkTomysql() {
        //加载JDBC驱动程序
        try{
            Class.forName("com.mysql.jdbc.Driver"); //动态加载mysql驱动;
        }catch(ClassNotFoundException e) {
            System.out.println("找不到程序驱动类，加载驱动失败");
            e.printStackTrace();
        }

        //提供JDBC连接的URL
        String url = "jdbc:mysql://127.0.0.1:3306/my_schema?" +
                "user=root&password=123456&useUnicode=true&characterEncoding=GBK";
        //创建数据库连接
        try{
            connection = DriverManager.getConnection(url);
        }catch (Exception e){
            System.out.println("数据库连接失败");
            e.printStackTrace();
        }
    }

    public void getSearchResult() {
        linkTomysql();
        try{
            statement = connection.createStatement();

            for(resultSet=statement.executeQuery("select * from professor_info where name like \'%"+keywords+"%\'");resultSet.next();) {
                selectByKeywords(resultSet);
            }
            for(resultSet=statement.executeQuery("select * from professor_info where educationBackground like \'%"+keywords+"%\'");resultSet.next();) {
                selectByKeywords(resultSet);
            }
            for(resultSet=statement.executeQuery("select * from professor_info where researchInterests like \'%"+keywords+"%\'");resultSet.next();) {
                selectByKeywords(resultSet);
            }
            for(resultSet=statement.executeQuery("select * from professor_info where email like \'%"+keywords+"%\'");resultSet.next();) {
                selectByKeywords(resultSet);
            }
            for(resultSet=statement.executeQuery("select * from professor_info where phone like \'%"+keywords+"%\'");resultSet.next();) {
                selectByKeywords(resultSet);
            }
            sortByTF();
            showResult();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                statement.close();
                connection.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    //通过关键词获取教授数据
    public void selectByKeywords(ResultSet res) {
        try{
            name = res.getString(1);
            educationBackground = res.getString(2);
            researchInterests = res.getString(3);
            email = res.getString(4);
            phone = res.getString(5);
            index = resultCount;

            int i = 0;
            do {
                //如果在数组中元素还没赋值，向数组中增加数据
                if (professorInfos[i].getName().equals("")) {
                    professorInfos[i].setName(name);
                    professorInfos[i].setEducationBackground(educationBackground);
                    professorInfos[i].setResearchInterests(researchInterests);
                    professorInfos[i].setEmail(email);
                    professorInfos[i].setPhone(phone);
                    tf[i] += (double) keywords.length() / (double) (name.length() + educationBackground.length() +
                            researchInterests.length() + email.length() + phone.length());
                    professorInfos[i].setTf(tf[i]);
                    resultCount++;
                    break;
                }
                //如果在数组中匹配到搜索到的数据，更新TF
                else if (!professorInfos[i].getName().equals("") && professorInfos[i].getName().equals(name)) {
                    tf[i] += (double) keywords.length() / (double) (name.length() + educationBackground.length() +
                            researchInterests.length() + email.length() + phone.length());
                    professorInfos[i].setTf(tf[i]);
                    break;
                }
                i++;
            }while (i<=index);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //根据TF值对搜索结果进行排序
    public void sortByTF() {
        for(int i=1;i<resultCount;i++) {
            for(int j=0;j<resultCount-i;j++) {
                if(tf[j]<tf[j+1]) {
                    ProfessorInfo temp = new ProfessorInfo();
                    temp = professorInfos[j];
                    professorInfos[j] = professorInfos[j+1];
                    professorInfos[j+1] = temp;
                }
            }
        }
    }

    //将排序后的搜索结果输出
    public void showResult() {
        for(int i=0;i<resultCount;i++) {
            professorInfos[i].showToScreen(jTextArea);
        }
        jTextArea.append("共有"+resultCount+"条搜索结果"+System.lineSeparator());
    }
}
