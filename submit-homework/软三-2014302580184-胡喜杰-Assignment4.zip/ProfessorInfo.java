import javax.swing.*;

public class ProfessorInfo {
    private String name;
    private String educationBackground;
    private String researchInterests;
    private String email;
    private String phone;
    private double tf = 0;

    public ProfessorInfo() {
        name = "";
        educationBackground = "";
        researchInterests = "";
        email = "";
        phone = "";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setEducationBackground(String educationBackground) {
        this.educationBackground = educationBackground;
    }

    public String getEducationBackground() {
        return educationBackground;
    }

    public void setResearchInterests(String researchInterests) {
        this.researchInterests = researchInterests;
    }

    public String getResearchInterests() {
        return researchInterests;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setTf(double tf) {
        this.tf = tf;
    }

    public double getTf() {
        return tf;
    }

    //将教授的信息输出到界面
    public void showToScreen(JTextArea jTextArea) {
        jTextArea.append(name+System.lineSeparator());
        jTextArea.append(educationBackground+System.lineSeparator());
        jTextArea.append(researchInterests+System.lineSeparator());
        jTextArea.append(email+System.lineSeparator());
        jTextArea.append(phone+System.lineSeparator());
        jTextArea.append(System.lineSeparator());
        jTextArea.append(System.lineSeparator());
    }
}
