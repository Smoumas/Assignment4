/**
 * 作业：根据以前存进数据库的，完成一个搜索引擎。
 * 要求使用 TF 值对搜索结果进行排序。
 * 搜索引擎程序要有相应图形界面。
 *
 * 学号：2014302580184
 * 姓名：胡喜杰
 * 时间：2015.11.12 -
 */
public class Assignment4_2014302580184 {
    public static void main(String[] args) {
        new Search_GUI();
    }
}
