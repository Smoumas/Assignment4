import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class KeywordsMatcher2014302580120 {
	private String[] keywords;
	DataReader2014302580120 dataReader = new DataReader2014302580120();
	private ArrayList<ProfessorInfo2014302580120> data = dataReader.getProfessorInfo();
	
	private Map<String, Double> result = new HashMap<String, Double>();
	
	private int total = 0;
	private int count = 0;
	
	/*
	 * ���캯��
	 */
	public KeywordsMatcher2014302580120(String[] keywords) {
		this.keywords = keywords;
		Result();
		showResult();
	}
	
	/*
	 * ����TFֵ
	 */
	public void Result() {
		double TF = 0.0;
		String [] names, edus, interests, emails, phones;
		for (ProfessorInfo2014302580120 p:data) {
			
			names = p.getName().split(" ");
			edus = p.getEducationBackground().split(" |,");
			interests = p.getResearchInterests().split(",| |\\.");
			emails = p.getEmail().split("@");
			phones = p.getPhone().split("-");
			
			counter(names);
			counter(edus);
			counter(interests);
			counter(emails);
			counter(phones);
			
			TF = count * 1.0 / total;
			if (TF!=0) result.put(String.valueOf(data.indexOf(p)), TF); //TFֵ��Ϊ0�ż�����������У��Żᱻ���
			
			//һ�μ����ֵ��գ��ټ�����һ��
			count = 0;
			total = 0;
			TF = 0.0;
		}

	}
	
	/*
	 * �ǹؼ����ڸ���ģ����ֵ��ܴ�����ģ�����
	 */
	private void counter(String[] str) {
		for(String s:str){
			for(String keyword:keywords){
				if(s.toLowerCase().contains(keyword.toLowerCase())){
					count++;
				}
			}
			total++;
		}
	}
	
	
	/*
	 * ����������ѯ���
	 */
	public void showResult() {
		/*
		 * ��TFֵ����
		 */
		ValueComparator2014302580120 vc = new ValueComparator2014302580120(result);
		TreeMap<String, Double> sorted_result = new TreeMap<String, Double>(vc);
		sorted_result.putAll(result);
		/*
		 * ���
		 */
		if (sorted_result.size()!=0) {
			for (String num : sorted_result.keySet()) {
			ProfessorInfo2014302580120 pInfo = data.get(Integer.parseInt(num));
			System.out.println(pInfo.getName() + '\n' + 
							   pInfo.getEducationBackground() +
							   pInfo.getResearchInterests() +
							   pInfo.getEmail() + '\n' +
							   pInfo.getPhone() + '\n');			
			}
		}else {
			System.out.println("��Ŷ��û�в�ѯ�������Ϣ");
		}
		
	}

}
