import java.util.Map;
/*
 * ÿ��������ϸ��Ϣ
 */
public class ProfessorInfo2014302580120 {
	private String name;
	private Map<String, String> info;
	private String email;
	private String phone;
	private String educationBackground;
	private String researchInterests;
	
	/*
	 * ���캯��
	 */
	public ProfessorInfo2014302580120(Map<String, String> info) {
		this.info = info;
	}
	
	//��������
	public String getName() {
		name = info.get("name");
		return name;
	}
	
	//����
	public String getEmail() {
		email = info.get("email");
		return email;
	}
	
	//�绰
	public String getPhone() {
		phone = info.get("phone");
		return phone;
	}
	
	//��������
	public String getEducationBackground() {
		educationBackground = info.get("educationBackground");
		return educationBackground;
	}
	
	//�о���Ȥ����
	public String getResearchInterests() {
		researchInterests = info.get("researchInterests");
		return researchInterests;
	}

}
