import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataReader2014302580120 {
	private ArrayList<ProfessorInfo2014302580120> professorInfo = new ArrayList<ProfessorInfo2014302580120>();
	
	public ArrayList<ProfessorInfo2014302580120> getProfessorInfo() {
		return professorInfo;
	}
	
	public DataReader2014302580120(){
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		Connection con = null;
		try {
			/*
			 * �������ݿ�
			 */
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url);
			Statement state	= con.createStatement();
		
			String sql = "select * from 2014302580120_professor_info";
			ResultSet result = state.executeQuery(sql);
	
			/*
			 * ��ȡ������Ϣ���洢
			 */
			while (result.next()) {
				Map<String, String> info = new HashMap<String, String>();
				info.put("name", result.getString(1));
				info.put("educationBackground", result.getString(2));
				info.put("researchInterests", result.getString(3));
				info.put("email", result.getString(4));
				info.put("phone", result.getString(5));
			
				professorInfo.add(new ProfessorInfo2014302580120(info));
			}
			con.close(); //�ر�����
		
		}catch(SQLException | ClassNotFoundException e){
			e.printStackTrace();
		}
		
	}

}
