import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

@SuppressWarnings("serial")
public class GUI2014302580120 extends JFrame {

	public JTextArea inputArea = new JTextArea();
	public JTextArea resultArea = new JTextArea();
	private JScrollPane scrollPane = new JScrollPane(resultArea);
	private JButton btn = new JButton("Search");
	
	public String result;
	protected String[] keywords;
	
	public GUI2014302580120() {
		super("Professor Searcher");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 705, 500);
		setLayout(null);
		
		resultArea.setEditable(false);
	    resultArea.setFont(new Font("Serif", Font.PLAIN, 14));
	    inputArea.setFont(new Font("Serif", Font.PLAIN, 14));
	    
	    add(inputArea);
	    inputArea.setBounds(20, 20, 250, 20);
	    add(btn);
	    btn.setBounds(290, 20, 80, 20);
	    
	    /*
	     * ���ؽ�������
	     */
	    add(scrollPane);
	    scrollPane.setBounds(20, 60, 650, 402);
	    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		/*
		 * ���Ӱ�ť�����¼�
		 */
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resultArea.setText("");
				keywords = inputArea.getText().trim().split(" ");
				new KeywordsMatcher2014302580120(keywords);
			}
			
		});
		
		/*
		 * TextArea���
		 */
		PrintStream printStream = new PrintStream(System.out) {
			public void println(String x) {
				resultArea.append(x + "\n");
			}
			public void print(String x) {
				resultArea.append(x);
			}
		};
		System.setOut(printStream);

	}

}