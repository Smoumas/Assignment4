import java.util.Comparator;
import java.util.Map;

public class ValueComparator2014302580120 implements Comparator<String> {
	
	/*
	 * map��value����
	 */
	Map<String, Double> map;
	public ValueComparator2014302580120(Map<String, Double> map) {  
	    this.map = map;
	}
	public int compare(String a, String b) {
		// TODO �Զ����ɵķ������
		if (map.get(a) >= map.get(b)) {
			return -1;
		}else {
			return 1;
		}
	}

}
