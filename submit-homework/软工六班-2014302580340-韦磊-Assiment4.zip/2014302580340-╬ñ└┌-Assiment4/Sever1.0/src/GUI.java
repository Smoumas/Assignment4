import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.List;
class GUI extends Frame implements ActionListener{
static TextField t1 = new TextField(40);
static TextField t2 = new TextField(100);
Button b1 = new Button("����");
public GUI(){
	setLayout(new FlowLayout(FlowLayout.LEFT));
	add(t1);
	add(b1);
	add(t2);
		
}
public static void main(String args[]){
	GUI mainFrance = new GUI();
	mainFrance.setSize(400,300);
	mainFrance.setTitle("welcome to my sever1.0");
	mainFrance.setVisible(true);
	try{
		Connection conn=null;
		Class.forName("com.mysql.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/wpi������Ϣ����","root","19960413");
		System.out.println("yes");
		Statement stmt=conn.createStatement();
		String selectSql="SELECT*FROM professor_info";
		ResultSet selectResult=stmt.executeQuery(selectSql);
		while(selectResult.next())
		{
			String name=selectResult.getString("name");
			String educationBackground=selectResult.getString("educationBackground");
			String researchInterests=selectResult.getString("researchInterests");
			String email=selectResult.getString("email");
			String phone=selectResult.getString("phone");
			System.out.print("\r\n\r\n");
			System.out.print("name:"+name+"educationBackground:"+educationBackground+"researchInterests:"+researchInterests+"email:"+email+"phone:"+phone);
			t1.setText("    ");
			t2.setText("name:"+name+"educationBackground:"+educationBackground+"researchInterests:"+researchInterests+"email:"+email+"phone:"+phone);
		}
	   
	    
	}catch(Exception e){
		System.out.println("MYSQL ERROR"+e.getMessage());
		}

}
@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}
public class WordCount {
    private String word;
    
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }
}
public class WordCountService {
    
    /**
     * �����������ɵ�����
     * @param text
     * @return
     */
    private CharTreeNode geneCharTree(String text){
        CharTreeNode root = new CharTreeNode();
        CharTreeNode p = root;
        char c = ' ';
        for(int i = 0; i < text.length(); ++i){
            c = text.charAt(i);
            if(c >= 'A' && c <= 'Z')
                c = (char)(c + 'a' - 'A');
            if(c >= 'a' && c <= 'z'){
                if(p.children[c-'a'] == null)
                    p.children[c-'a'] = new CharTreeNode();
                p = p.children[c-'a'];
            }
            else{
                p.cnt ++;
                p = root;
            }
        }
        if(c >= 'a' && c <= 'z')
            p.cnt ++;
        return root;
    }
    
    /**
     * ʹ�����������������������������Ӧ���ʷ���������
     * @param result
     * @param p
     * @param buffer
     * @param length
     */
    private void getWordCountFromCharTree(List result,CharTreeNode p, char[] buffer, int length){
        for(int i = 0; i < 26; ++i){
            if(p.children[i] != null){
                buffer[length] = (char)(i + 'a');
                if(p.children[i].cnt > 0){
                    WordCount wc = new WordCount();
                    wc.setCount(p.children[i].cnt);
                    wc.setWord(String.valueOf(buffer, 0, length+1));
                    result.add(wc);
                }
                getWordCountFromCharTree(result,p.children[i],buffer,length+1);
            }
        }
    }
    
    private void getWordCountFromCharTree(List result,CharTreeNode p){
        getWordCountFromCharTree(result,p,new char[100],0);
    }
    
    /**
     * �õ���Ƶ�������㷨,���ⲿ����
     * @param article
     * @return
     */
    public List getWordCount(String article){
        CharTreeNode root = geneCharTree(article);
        List result = new ArrayList();//�˴�Ҳ����LinkedList����,�Ա��������������ݵ��µ�������ʧ
        getWordCountFromCharTree(result,root);
        Collections.sort(result, new Comparator(){
            public int compare(Object o1, Object o2) {
                WordCount wc1 = (WordCount)o1;
                WordCount wc2 = (WordCount)o2;
                return wc2.getCount() - wc1.getCount();
            }
        });
        return result;
    }
}

/**
 * ���������Ķ���
 * @author FlameLiu
 *
 */
class CharTreeNode{
    int cnt = 0;
    CharTreeNode[] children = new CharTreeNode[26];
}


}

