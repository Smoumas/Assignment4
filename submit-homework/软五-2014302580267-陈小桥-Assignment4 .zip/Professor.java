import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * get all the information of professors and encapsulate them 
 * @author cxq
 * 
 */
public class Professor {
	//variables about database
	private String url="jdbc:mysql://localhost:3306/Teacher?useUnicode=true&characterEncoding=utf-8";
	private String user="root";
	private String password="19950707";
	private ResultSet rs;//the result of select statement
	//a collection of professorObjects
	private List<ProfessorObject> professors=new ArrayList<ProfessorObject>();
	
	public List<ProfessorObject> getProfessors(){
		return professors;
	}
	
	//load the database
	public void load(String sql){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, user, password);
			Statement st=conn.createStatement();
			rs=st.executeQuery(sql);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			System.out.println("Fail to conect to the database!");
			e.printStackTrace();
		}
		
	}
	
	//constructor to add information into professorObjects and add them into the list
	public Professor(String sql){
		//"SELECT * FROM 2014302580267_professor_info;"
		try{
		load(sql);
		while(rs.next()){
			ProfessorObject pro=new ProfessorObject(rs.getString("name"),rs.getString("educationBackground"),rs.getString("researchInterests"),rs.getString("email"),rs.getString("phone"));
			professors.add(pro);
		}
		}catch(SQLException s){
			s.printStackTrace();
		}
	}
	
	
}
