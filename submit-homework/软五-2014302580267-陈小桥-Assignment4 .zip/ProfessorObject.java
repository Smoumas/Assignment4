/**
 * 
 * Encapsulate every professor informations in table professor_info
 * @author cxq
 *
 */

public class ProfessorObject{
	//six attributes of every professor
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;
	private double TF;
	
	//constructor to set six attributes
	public ProfessorObject(String name,String educationBackground,String researchInterests,String email,String phone){
		setName(name);
		setEducationBackground(educationBackground);
		setResearchInterests(researchInterests);
		setEmail(email);
		setPhone(phone);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public double getTF() {
		return TF;
	}
	public void setTF(double TF) {
		this.TF = TF;
	}
	
	
	//put all the attributes into a string array by splitting by blank space 
	public String[] getAllString(){
		return (getName()+getEducationBackground()+getResearchInterests()+getEmail()+getPhone()).split(" ");	
	}
	//put the name into a string array by splitting by blank space 
	public String[] getNameString(){
		return getName().split(" ");
	}
	//put the EducationBackground into a string array by splitting by blank space 
	public String[] getEducationBackgroundString(){
		return getEducationBackground().split(" ");
	}
	//put the ResearchInterests into a string array by splitting by blank space 
	public String[] getResearchInterestsString(){
		return getResearchInterests().split(" ");
	}
	//put the email into a string array by splitting by blank space 
	public String[] getEmailString(){
		return getEmail().split(" ");
	}
	//put the phone into a string array by splitting by blank space 
	public String[] getPhoneString(){
		return getPhone().split(" ");
	}
	//get the size of the long string of all the attributes
	public int getSize(){
		return getAllString().length;
	}
	
}








