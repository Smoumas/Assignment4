import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
/**
 * the GUI
 * @author cxq
 *
 */

public class Search extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	//some components
	private JFrame frame;
	private JPanel contentPane;
	private JButton button;
	private JTextField text;
	private JTextArea area;
	private JScrollPane scroll;
	
	//the list of result
	private List<ProfessorObject> result=new ArrayList<ProfessorObject>();
	//an object of serchResult
	private SearchResult searchResult=new SearchResult("SELECT * FROM 2014302580267_professor_info;");

	//the constructor
	public Search() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 500, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setSize(500,500);
		setContentPane(contentPane);
		
		set();
		
		contentPane.add(button);
		contentPane.add(text);
		contentPane.add(area);
		contentPane.add(scroll);
		scroll.setViewportView(area);
	     
		frame=new JFrame("ATM");
		frame.setSize(contentPane.getWidth()+30,contentPane.getHeight()+30);
		Container container=frame.getContentPane();
		container.add(contentPane);
		frame.setLayout(null);
		contentPane.setLayout(null);
		frame.setVisible(true);
		contentPane.setVisible(true);
		frame.setResizable(false);
	}

	//set the components
	public void set(){
		button=new JButton("search");
		button.setBounds(370,20,110,50);
		text=new JTextField();
		text.setBounds(20, 20, 350, 50);
		text.setVisible(true);
		area=new JTextArea();
		area.setBounds(20,90,480,390);
		area.setEditable(false);
		area.setLineWrap(true);
		scroll = new JScrollPane();
		scroll.setBounds(20,90,480,390);
		
		//set action listener on the button
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
					//first clear the text area
				    area.setText("");
				
					if(text.getText().isEmpty()){
						area.append("Please input keywords...");
					}
					else//when the text field is not empty
					{	
						//set the words input as the keywords in searchResult
						String key=text.getText();
						searchResult.setKeywords(key);
						//the process of searching
						searchResult.run();
						//get the search result in list of result
						result=searchResult.getSearchResult();
					
						//output the result in the text area
						for(ProfessorObject p:result){
							area.append(p.getName()+":"+"/n"+"Education background:"+p.getEducationBackground()+"\n"+"Research Interests:"+p.getResearchInterests()+"\n"+"E-mail:"+p.getEmail()+"\n"+"Phone:"+p.getPhone()+"\n");
							area.append("����������������������������������������������������������������������������"+"\n");
							
							//clear the TF in every objects
							p.setTF(0.0);
						}
						//clear the result
						result.clear();
					}
			}	
		});
	}
	
	//the main function
	public static void main(String[]args){
		@SuppressWarnings("unused")
		Search search=new Search();
	}
}





