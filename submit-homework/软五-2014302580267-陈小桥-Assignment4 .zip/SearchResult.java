
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
/**
 * 
 * to get the search results based on keywords input in GUI
 * @author cxq
 *
 */

public class SearchResult {
	//the keywords need to deal with
	private List<String> keywords=new ArrayList<String>();
	//to store the search result as several professorObjects in the list
	private List<ProfessorObject> searchResult=new ArrayList<ProfessorObject>();
	//the stop words need to delete
	String[]stopList=new String[]{"a","an","the","and","but","this","that","these","those","he","she","it","his","her","its","him","me","I","my","am","is","are","they","their","them","we","our","us"}; 
	//a professor object
	private Professor pro;
	
	//initial pro with statement sql
	public SearchResult(String sql){
		this.pro=new Professor(sql);
	}
	
	//deal with keywords by splitting by blank space and deleting stop words
	public void dealKeywords(String iniKeywords){
		//split by blank space
		int i=0;
		while(i<iniKeywords.split(" ").length){
			String s=iniKeywords.split(" ")[i];
			keywords.add(s);
			i++;
		}
		
		//delete stop words
		for(String stop:stopList){
			for(String keyword:keywords){
				if(stop.equalsIgnoreCase(keyword))
					keywords.remove(keyword);
			}
		} 
	}
	
	
	//calculate TF of every professorObjects and set the value of attribute TF as the value figured out
	public void calTF(){
		for(ProfessorObject p:pro.getProfessors()){
			//the number of words in the object's all attributes
			double size=(double)p.getSize();
			//the counter to count the number of words equals to keywords
			double count=0;
			
			//the weight of name is 2
			for(String s:p.getNameString()){
				for(String keyword:keywords){
					if(s.equalsIgnoreCase(keyword)){
						count+=2;
					}
				}
			}
			//the weight of educationBackground is 0.5
			for(String s:p.getEducationBackgroundString()){
				for(String keyword:keywords){
					if(s.equalsIgnoreCase(keyword))
						count+=0.5;
				}
			}
			//the weight of researchInterests is 0.5
			for(String s:p.getResearchInterestsString()){
				for(String keyword:keywords){
					if(s.equalsIgnoreCase(keyword))
						count+=0.5;
				}
			}
			//the weight of email is 1
			for(String s:p.getEmailString()){
				for(String keyword:keywords){
					if(s.equalsIgnoreCase(keyword))
						count++;
				}
			}
			//the weight of phone is 1
			for(String s:p.getPhoneString()){
				for(String keyword:keywords){
					if(s.equalsIgnoreCase(keyword))
						count++;
				}
			}
	
			p.setTF(count/size);
			
		}
	}
	
	//select objects with TF more than 0 and add it into the list of searchResult
	public void select(){
		for(ProfessorObject p:pro.getProfessors()){
			if(p.getTF()>0)
				searchResult.add(p);
		}
	}
	
	//the class of comparator
	public class TFComparator implements Comparator<ProfessorObject>{
		//compare function to make it sort in inverted order
		public int compare(ProfessorObject o1, ProfessorObject o2) {
			// TODO �Զ����ɵķ������
			if(o1.getTF()>o2.getTF())return -1;
			else if(o1.getTF()<o2.getTF())return 1;
			return 0;
		}
	}

	//sort function of collections
	public void sort(){
		Collections.sort(searchResult,new TFComparator());
	}

	public List<String> getKeywords(){
		return keywords;
	}
	
	public List<ProfessorObject> getSearchResult() {
		return searchResult;
	}

	public void setSearchResult(List<ProfessorObject> searchResult) {
		this.searchResult = searchResult;
	}
	
	public void setKeywords(String s) {
		dealKeywords(s);
	}
	
	public void run(){
		calTF();
		select();
		sort();
	}
	 
	
}

	






