/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580323_professor_info` (
	`name` varchar (405),
	`educationBackground` varchar (9000),
	`researchInterests` varchar (9000),
	`email` varchar (405),
	`phone` varchar (405)
); 
