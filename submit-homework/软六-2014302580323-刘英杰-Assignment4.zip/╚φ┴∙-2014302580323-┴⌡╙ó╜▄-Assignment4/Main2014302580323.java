package baidu;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;


public class Main2014302580323 {
	private static JTextField text=new JTextField();
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		JFrame app=new JFrame("baidu");
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container container=app.getContentPane();
		container.setLayout(new BorderLayout(0,10));
		app.setLocation(500,200);
		app.setSize(200,200);
		JButton sea=new JButton("search");
		final JTextArea jTextArea=new JTextArea();
		JScrollPane jScrollPane=new JScrollPane(jTextArea);
		jTextArea.setLineWrap(true);
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection=(Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?useUnicode=true&characterEncoding=gb2312","root","123456");
		final Statement statement=(Statement) connection.createStatement();
		sea.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ResultSet result;
				try {
					jTextArea.setText(" ");
					result = statement.executeQuery("select * from 2014302580323_professor_info");
					while (result.next()) {
					String infomayion=result.getString(1)+result.getString(2)+result.getString(3)+result.getString(4)+result.getString(5);
					if(infomayion.toUpperCase().contains(text.getText().toUpperCase()))
					{
						jTextArea.append(result.getString(1)+"\n"+result.getString(2)+"\n"+result.getString(3)+"\n"+result.getString(4)+"\n"+result.getString(5)+"\n\n");
					}
					}
					
					} catch (Exception e1) {
					
					}
				
				
			}
		});
		JPanel jnor=new JPanel();
		JPanel jsou=new JPanel();
		jnor.setLayout(new GridLayout(1, 2,10,0) );
		jnor.add(text);
		jnor.add(sea);
		jsou.setLayout(new BorderLayout());
		jsou.add(jScrollPane,BorderLayout.CENTER);
		container.add(jnor,BorderLayout.NORTH);
		container.add(jsou,BorderLayout.CENTER);
		app.setVisible(true);
		
		
	}
}
