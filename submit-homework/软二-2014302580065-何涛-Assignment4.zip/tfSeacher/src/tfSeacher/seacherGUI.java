package tfSeacher;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
//import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
//������ı�����
 class pStream extends PrintStream{
  private JTextArea jtext;
  private StringBuffer stringbuffer=new StringBuffer();
  public pStream(OutputStream out,JTextArea jtext){
	super(out);
	this.jtext=jtext;
  }
//�������Ϣ�GUI���
  public void write(byte[] buf,int off,int len){
	final String message=new String(buf,off,len);
	SwingUtilities.invokeLater(new Runnable(){
		public void run(){
			stringbuffer.append(message);
			jtext.setText(stringbuffer.toString());
		}
	});
  }
}
public class seacherGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private tfseach t=new tfseach();
	//����������ť
	private JButton keyseach=new JButton("����");
	private JTextArea jTextArea=new JTextArea(10,15);
	public int number=0;
	public String currentcontent="aaabcd";
	public seacherGUI(){
		jTextArea.setBackground(Color.green);
		jTextArea.setLineWrap(true);
		jTextArea.setWrapStyleWord(true);
		jTextArea.setEditable(false);
		//�ض��嵽ͨ���ı��������������������
		System.setOut(new pStream(System.out,jTextArea));	
		//�Ѱ�ť�ӵ�panel1
		JPanel panelONE2=new JPanel();
		panelONE2.add(keyseach);
		JPanel panelONE=new JPanel();
		JPanel panel3 =new JPanel();
		jTextArea.setSize(200,200 );
		panel3.add(jTextArea);
		add(new JScrollPane(jTextArea),BorderLayout.CENTER);
		//�����������ӵ�frame
		add(panel3,BorderLayout.NORTH);
		//add(panel4,BorderLayout.SOUTH);
		//���Ӽ�����
		ButtonListener listener=new ButtonListener();
		keyseach.addActionListener(listener);
	}
	class ButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			//int number=0;
			e.getSource();
			if(e.getSource()==keyseach){
				
			}
			
		}
	}
	public static void main( String[] args ){
		   //����TFseacher����
			seacherGUI test=new seacherGUI();
			test.setTitle("seacherGUI");
			test.pack();
			test.setLocationRelativeTo(null);
			test.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			test.setVisible(true);
			test.setBackground(Color.green);
			test.tfseach();
	   }
}
