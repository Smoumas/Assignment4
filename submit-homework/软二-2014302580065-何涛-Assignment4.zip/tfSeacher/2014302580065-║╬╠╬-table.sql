-- MySQL dump 13.09  Distrib 3.4.8, for Win32 (AMD64)
--
-- Host: localhost    Database: my_schema
-- ------------------------------------------------------
-- Server version	3.4.8-log

 SET NAMES utf8 ;
 SET @OLD_TIME_ZONE=@@TIME_ZONE ;
 SET TIME_ZONE='+00:00' ;
 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 ;
 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 ;

--
-- Table structure for table `2014302580065_professor_info`
--
CREATE TABLE `2014302580065_professor_info` (
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `researchInterests` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- Dump completed on 2015-11-20 13:27:22