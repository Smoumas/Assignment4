package Assignment4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;      //�������ݼ�¼������
public class MySQL2014302580020 {
	private Statement statement;
	private String url="jdbc:mysql://localhost:3306/my_schema?characterEncoding=UTF-8";
	private String username="root";
	private String password="123456";
	private Connection con; 
	ResultSet resultset;
	private String sql;
	  public MySQL2014302580020() {
		  sql = "select * from professor_info ";//��ö�ȡ����
		  try {
			Class.forName("com.mysql.jdbc.Driver" );
			//System.out.println("���ݿ���سɹ�");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//System.out.println("���ݿ����ʧ��");
			e.printStackTrace();
		}
		  try {
			con = DriverManager.getConnection( url,username, password );
			statement = con.createStatement();
			//System.out.println("���ݿ����ӳɹ�");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//System.out.println("���ݿ�����ʧ��");
			e.printStackTrace();
		}  	
	  }
	  //��õ�i����������
	  public String getname(int i){
		  String name=null;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();
	                name = resultset.getString(1); 
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return name;
	  }
	  //��õ�i������Ľ�������
	  public String geteducationbackground(int i){
		  String educationbackground=null;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();
	                educationbackground = resultset.getString(2); 
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return educationbackground;
	  }
	  //��õ�i��������о�����
	  public String getreseachinterests(int i){
		  String reseachinterests=null;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();
	                reseachinterests = resultset.getString(3); 
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return reseachinterests;
	  }
	  //��õ�i�������email
	  public String getemail(int i){
		  String email=null;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();
	                email = resultset.getString(4); 
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return email;
	  }
	  //��õ�i������ĵ绰
	  public String getphone(int i){
		  String phone=null;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();
	            phone = resultset.getString(5); 
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return phone;
	  }
	  //��ȡ����i����������е����ݣ�
	  public String AllMessage(int i){
		  String name=null;
		  String educationbackground=null;
		  String reseachinterests=null;
		  String email=null;
		  String phone=null;
	        try  
	        {  
	            resultset = statement.executeQuery(sql);  
	            for(int j=0;j<i;j++)
	            	resultset.next();//�ò������ڻ������ݿ��е�i����ʦ��Ϣ����λ��
	                //���²������ڱ�����ʦ����������Ϣ
	                name = resultset.getString(1); 
	                educationbackground = resultset.getString(2); 
	                reseachinterests=resultset.getString(3);
	                email=resultset.getString(4);
	                phone=resultset.getString(5);
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
	        return (name+' '+educationbackground+' '+reseachinterests+' '+email+' '+phone);  
	  }
	  //���һ���ж�����ʦ
	  public int getnumber(){
		  int number=0;
		  try  
	        {  
	            resultset = statement.executeQuery(sql);  
	           while(resultset.next())
	            number++;
	                
	        }
	        catch (SQLException e)  
	        {  
	            e.printStackTrace();  
	        }
		  return number;
	  }
	  //�رղ��˳����ݿ�
	  public void closeSql() 
		{
			try {
				if(con!=null){
					con.close();
					statement.close();
					//System.out.println("���ݿ�رճɹ�");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//System.out.println("���ݿ�ر�ʧ��");
			}
		}
}

