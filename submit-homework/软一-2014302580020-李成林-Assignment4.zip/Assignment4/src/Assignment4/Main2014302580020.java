package Assignment4;
import javax.swing.*;
public class Main2014302580020 {
	public static void main(String [] args){
		GUI2014302580020 p=new GUI2014302580020();
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���ó�����˳�
		p.setSize(530, 660);
		p.setVisible(true);
	}
}
