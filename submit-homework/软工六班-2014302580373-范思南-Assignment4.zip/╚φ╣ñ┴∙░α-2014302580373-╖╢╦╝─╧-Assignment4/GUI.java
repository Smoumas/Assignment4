import java.awt.Frame;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class GUI extends JFrame
{
	private static JTextArea in_text = new JTextArea();
	private static JTextArea out_text = new JTextArea();
	private static JScrollPane scrollPane = new JScrollPane(out_text);
	private static JButton button = new JButton("Search");
	private static String infoAll;
	
	public static void createGUI(JFrame frame,int width,int height)
	{
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width,height);
		frame.setVisible(true);
		frame.setExtendedState(Frame.MAXIMIZED_BOTH);
		frame.setExtendedState(Frame.NORMAL);
		JPanel panel = new JPanel();
		panel.setLayout(null);

		in_text.setBounds(10, 26, 240, 20);
		in_text.setBorder(BorderFactory.createBevelBorder(1));
		button.setBounds(270, 26, 100, 20);
		button.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				try 
				{
					Class.forName("com.mysql.jdbc.Driver");
					String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
					Connection conn = DriverManager.getConnection(url);
					Statement stmt = conn.createStatement();
					
					String order = "select name, educationBackground, researchInterests, email, phone "
							+ "from 2014302580373_professor_info "
							+ "where name like \"%"+in_text.getText()+"%\""
							+ " or educationBackground like \"%"+in_text.getText()+"%\""
							+ " or researchInterests like \"%"+in_text.getText()+"%\""
							+ " or email like \"%"+in_text.getText()+"%\""
							+ " or phone like \"%"+in_text.getText()+"%\"";
					ResultSet rs = stmt.executeQuery(order);
					while(rs.next())
					{
						infoAll += "Name: "+rs.getString(1)+"\n"
								+"EducationBackground: "+rs.getString(2)+"\n"
								+"ResearchInterests: "+rs.getString(3)+"\n"
								+"Email: "+rs.getString(4)+"\n"
								+"Phone: "+rs.getString(5)+"\n\n\n";
						out_text.setText(infoAll);
					}
					
					rs.close();
					stmt.close();
					conn.close();
				}
				catch (ClassNotFoundException | SQLException ex) 
				{
					// TODO �Զ����ɵ� catch ��
					ex.printStackTrace();
				}
			}
		});
		out_text.setLineWrap(true);
		scrollPane.setBounds(10, 80, 365, 260);

		panel.add(in_text);
		panel.add(button);
		panel.add(scrollPane);
		frame.add(panel);
	}
	
	public static void main(String[] args) 
	{
		createGUI(new JFrame("Searcher"), 400, 400);
	}
}
