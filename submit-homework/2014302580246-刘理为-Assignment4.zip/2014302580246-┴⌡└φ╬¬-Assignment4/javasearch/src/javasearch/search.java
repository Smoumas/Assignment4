package javasearch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class search {
	static Vector<information> all_information=new Vector<information>();
	public static void main(String[] args) throws SQLException, ClassNotFoundException{
		String driver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://127.0.0.1:3306/my_achema?user=root&password=123456";
		String user="root";
		String password="123456";
		Class.forName(driver);
		Connection conn=DriverManager.getConnection(url, user, password);
		Statement st=conn.createStatement();
		String selectSql="SELECT * FROM llw.professor_info";
		ResultSet selectRes = st.executeQuery(selectSql);
		while(selectRes.next()){
			information i= new information();
			i.name=selectRes.getString("name");
			i.educationBackground=selectRes.getString("educationBackground");
			i.email=selectRes.getString("email");
			i.phone=selectRes.getString("phone");all_information.add(i);
		}
		//System.out.println(search("Bob"));
		EventQueue.invokeLater(new Runnable(){
			public void run()
			{
				JFrame frame=new TextComponentFrame();
				frame.setTitle("search");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
		
	}
	public static String search(String str){
		String str1="";
		for(information i:all_information){
			i.count=getCount(i,str);
		}
		for(int d=50;d>=0;d--){
			for(information i:all_information){
				str1+="name:"+i.name+"\n"+"educationBackground:"+i.educationBackground+"\n"+"email:"+i.email+"\n"+"phone:"+i.phone+"\n";
			}
		}
		return str1;
	
	}
	public static int getCount(information i,String str){
		int count=0;
		String all_str=i.name+i.educationBackground+i.researchInterests+i.email+i.phone+i.count;
		Pattern pattern=Pattern.compile(str);
		Matcher matcher=pattern.matcher(all_str);
		while(matcher.find()){
			count++;
		}
		return count;
	}
	public static class TextComponentFrame extends JFrame
	{
		
		public static final int TEXTAREA_ROWS=8;
		public static final int TEXTAREA_COLUMNS=20;
		public TextComponentFrame()
		{
			final JTextField textField=new JTextField();
		    JButton searchButton=new JButton("����");
		    JPanel northPanel = new JPanel();
		    northPanel=new JPanel();
		    northPanel.setLayout(new GridLayout(1,1));
		    northPanel.add(textField);
		    northPanel.add(searchButton);
		    add(northPanel,BorderLayout.NORTH); 
		    final JTextArea textArea=new JTextArea(TEXTAREA_ROWS,TEXTAREA_COLUMNS);
		    JScrollPane scrollPane=new JScrollPane(textArea);
		    add(scrollPane,BorderLayout.CENTER);
		    searchButton.addActionListener(new ActionListener()
		    {
		    	public void actionPerformed(ActionEvent event){
		    		String a=textField.getText();
		    		textArea.setText(search(a));
		    	}
		    });
		   pack();
		   
		}
		
		
	}
static class information{
	public String name;
	public String educationBackground;
	public String researchInterests;
	public String email;
	public String phone;
	public int count;
}
}